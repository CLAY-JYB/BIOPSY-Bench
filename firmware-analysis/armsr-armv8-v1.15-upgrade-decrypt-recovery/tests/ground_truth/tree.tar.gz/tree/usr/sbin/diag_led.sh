#!/bin/sh
# board LED sweep for manufacturing QA
LED=/sys/class/leds/board8:status/brightness
[ -e "$LED" ] || exit 0
while true; do echo 255 > "$LED"; sleep 1; echo 0 > "$LED"; sleep 1; done
