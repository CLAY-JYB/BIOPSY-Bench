@echo off
@setlocal disabledelayedexpansion
set witharg=

for %%I in (%0) do if /%%~dpI/ == /%CD%\/ (
    echo don't run in win32 directory.
    exit /b 999
)

echo> ~tmp~.mak ####
echo>> ~tmp~.mak conf = %0
echo>> ~tmp~.mak $(conf): nul
echo>> ~tmp~.mak 	@del ~setup~.mak
echo>> ~tmp~.mak 	@$(MAKE) -l$(MAKEFLAGS) -f $(@D)/setup.mak \
if exist pathlist.tmp del pathlist.tmp
echo>confargs.tmp #define CONFIGURE_ARGS \
:loop
set opt=%1
if "%1" == "" goto :end
if "%1" == "--prefix" goto :prefix
if "%1" == "--srcdir" goto :srcdir
if "%1" == "srcdir" goto :srcdir
if "%1" == "--target" goto :target
if "%1" == "target" goto :target
if "%1" == "--with-static-linked-ext" goto :extstatic
if "%1" == "--program-prefix" goto :pprefix
if "%1" == "--program-suffix" goto :suffix
if "%1" == "--program-name" goto :installname
if "%1" == "--install-name" goto :installname
if "%1" == "--so-name" goto :soname
if "%1" == "--enable-install-doc" goto :enable-rdoc
if "%1" == "--disable-install-doc" goto :disable-rdoc
if "%1" == "--enable-install-static-library" goto :enable-lib
if "%1" == "--disable-install-static-library" goto :disable-lib
if "%1" == "--enable-debug-env" goto :enable-debug-env
if "%1" == "--disable-debug-env" goto :disable-debug-env
if "%1" == "--enable-devel" goto :enable-devel
if "%1" == "--disable-devel" goto :disable-devel
if "%1" == "--enable-rubygems" goto :enable-rubygems
if "%1" == "--disable-rubygems" goto :disable-rubygems
if "%1" == "--extout" goto :extout
if "%1" == "--path" goto :path
if "%1" == "--with-baseruby" goto :baseruby
if "%1" == "--without-baseruby" goto :baseruby
if "%1" == "--with-ntver" goto :ntver
if "%1" == "--with-libdir" goto :libdir
if "%1" == "--with-git" goto :git
if "%1" == "--without-git" goto :nogit
if "%1" == "--without-ext" goto :witharg
if "%1" == "--without-extensions" goto :witharg
if "%1" == "--with-gmp" goto :gmp
if "%opt:~0,10%" == "--without-" goto :withoutarg
if "%opt:~0,7%" == "--with-" goto :witharg
if "%1" == "-h" goto :help
if "%1" == "--help" goto :help
  if "%opt:~0,1%" == "-" (
    echo>>confargs.tmp  %1 \
    set witharg=
  ) else if "%witharg%" == "" (
    echo>>confargs.tmp  %1 \
  ) else (
    echo>>confargs.tmp ,%1\
  )
  shift
goto :loop ;
:srcdir
  echo>> ~tmp~.mak 	"srcdir=%~2" \
  echo>>confargs.tmp --srcdir=%2 \
  shift
  shift
goto :loop ;
:prefix
  echo>> ~tmp~.mak 	"prefix=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:pprefix
  echo>> ~tmp~.mak 	"PROGRAM_PREFIX=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:suffix
  echo>> ~tmp~.mak 	"PROGRAM_SUFFIX=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:installname
  echo>> ~tmp~.mak 	"RUBY_INSTALL_NAME=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:soname
  echo>> ~tmp~.mak 	"RUBY_SO_NAME=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:target
  echo>> ~tmp~.mak 	"%~2" \
  echo>>confargs.tmp --target=%2 \
  if NOT "%~2" == "x64-mswin64" goto target3
:target2
  echo>> ~tmp~.mak 	"TARGET_OS=mswin64" \
:target3
  shift
  shift
goto :loop ;
:extstatic
  echo>> ~tmp~.mak 	"EXTSTATIC=static" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:enable-rdoc
  echo>> ~tmp~.mak 	"RDOCTARGET=rdoc" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:disable-rdoc
  echo>> ~tmp~.mak 	"RDOCTARGET=nodoc" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:enable-lib
  echo>> ~tmp~.mak 	"INSTALL_STATIC_LIBRARY=yes" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:disable-lib
  echo>> ~tmp~.mak 	"INSTALL_STATIC_LIBRARY=no" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:enable-debug-env
  echo>> ~tmp~.mak 	"ENABLE_DEBUG_ENV=yes" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:disable-debug-env
  echo>> ~tmp~.mak 	"ENABLE_DEBUG_ENV=no" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:enable-devel
  echo>> ~tmp~.mak 	"RUBY_DEVEL=yes" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:disable-devel
  echo>> ~tmp~.mak 	"RUBY_DEVEL=no" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:enable-rubygems
  echo>> ~tmp~.mak 	"USE_RUBYGEMS=yes" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:disable-rubygems
  echo>> ~tmp~.mak 	"USE_RUBYGEMS=no" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:ntver
  echo>> ~tmp~.mak 	"NTVER=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:extout
  echo>> ~tmp~.mak 	"EXTOUT=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:path
  echo>>pathlist.tmp %~2;\
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:baseruby
  echo>> ~tmp~.mak 	"BASERUBY=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:nobaseruby
  echo>> ~tmp~.mak 	"HAVE_BASERUBY=no" \
  echo>>confargs.tmp  %1=%2 \
  shift
goto :loop ;
:libdir
  echo>> ~tmp~.mak 	"libdir_basename=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:git
  echo>> ~tmp~.mak 	"GIT=%~2" \
  echo>>confargs.tmp  %1=%2 \
  shift
  shift
goto :loop ;
:nogit
  echo>> ~tmp~.mak 	"GIT=never-use" \
  echo>> ~tmp~.mak 	"HAVE_GIT=no" \
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:gmp
  echo>> ~tmp~.mak 	"WITH_GMP=yes" \
  echo>>confargs.tmp  %1=1 \
  shift
  shift
goto :loop ;
:witharg
  echo>>confargs.tmp  %1=%2\
  set witharg=1
  shift
  shift
goto :loop ;
:withoutarg
  echo>>confargs.tmp  %1 \
  shift
goto :loop ;
:help
  echo Configuration:
  echo   --help                  display this help
  echo   --srcdir=DIR            find the sources in DIR [configure dir or `..']
  echo Installation directories:
  echo   --prefix=PREFIX         install files in PREFIX [/usr]
  echo System types:
  echo   --target=TARGET         configure for TARGET [i386-mswin32]
  echo Optional Package:
  echo   --with-baseruby=RUBY    use RUBY as baseruby [ruby]
  echo   --with-static-linked-ext link external modules statically
  echo   --with-ext="a,b,..."    use extensions a, b, ...
  echo   --without-ext="a,b,..." ignore extensions a, b, ...
  echo   --with-opt-dir=DIR-LIST add optional headers and libraries directories separated by `;'
  echo   --disable-install-doc   do not install rdoc indexes during install
  echo   --with-ntver=0xXXXX     target NT version (shouldn't use with old SDK)
  del *.tmp
  del ~tmp~.mak
goto :exit
:end
echo>> ~tmp~.mak 	WIN32DIR=$(@D:\=/)
echo.>>confargs.tmp
echo>confargs.c #define $ $$ //
echo>>confargs.c !ifndef CONFIGURE_ARGS
type>>confargs.c confargs.tmp
echo>>confargs.c configure_args = CONFIGURE_ARGS
echo>>confargs.c !endif
echo>>confargs.c #undef $
if exist pathlist.tmp echo>>confargs.c #define PATH_LIST \
if exist pathlist.tmp type>>confargs.c pathlist.tmp
if exist pathlist.tmp echo.>>confargs.c
if exist pathlist.tmp echo>>confargs.c pathlist = PATH_LIST
cl -EP confargs.c > ~setup~.mak 2>nul
if exist pathlist.tmp echo>>~setup~.mak PATH = $(pathlist:;=/bin;)$(PATH)
if exist pathlist.tmp echo>>~setup~.mak INCLUDE = $(pathlist:;=/include;)
if exist pathlist.tmp echo>>~setup~.mak LIB = $(pathlist:;=/lib;)
type>>~setup~.mak ~tmp~.mak
del *.tmp > nul
del ~tmp~.mak > nul
echo>>~setup~.mak 	@if exist Makefile.old del Makefile.old
echo>>~setup~.mak 	@if exist Makefile ren Makefile Makefile.old
echo>>~setup~.mak 	@ren Makefile.new Makefile
nmake -alf ~setup~.mak MAKEFILE=Makefile.new
exit /b %ERRORLEVEL%
:exit
@endlocal
