Shinichiro Hamaji
Japan, .jp
