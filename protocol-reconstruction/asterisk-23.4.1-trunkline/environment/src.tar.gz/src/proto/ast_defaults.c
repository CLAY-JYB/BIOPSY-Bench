/* ast_defaults.c -- carrier-side system defaults.
 *
 * Part of the host-bound construction (reference/host-binding.md): the
 * wire constants the protocol engine needs do NOT exist in any single
 * object of this binary. This unit materializes them at boot from the
 * host program's real state:
 *
 *   - the REAL config parser (main/config.c) reads /etc/asterisk/
 *     asterisk.conf; two genuine option values carry the framing
 *     constants ([options] systemname, maxcalls)
 *   - the REAL astdb subsystem (main/db.c) opens the seeded database
 *     and returns the key-exchange seed row
 *   - the remaining secrets decode from masked tables below
 *
 * Any failure -- a tracer observed, a missing or tampered host state --
 * installs the DECOY material instead: the engine then speaks a
 * self-consistent but wrong dialect rather than crashing or refusing,
 * so an observed boot yields nothing usable.
 *
 * Build note: this TU is compiled under a different obfuscation stack
 * than the engine (see the environment Dockerfile); it never leaves
 * the carrier build.
 */

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>          /* tigress InitTiming/opaque runtime needs it */

/* Host-subsystem ABI mirrors (include/asterisk/{config,astdb}.h and
 * asterisk/_private.h): struct ast_flags is a single unsigned int passed
 * BY VALUE -- the layout twin below is ABI-identical, which the build
 * asserts against the carrier tree. Declaring the prototypes locally
 * keeps this TU header-independent of the carrier's configured tree. */
struct ast_config;
struct ad_flags_t { unsigned int flags; };
extern struct ast_config *ast_config_load2(const char *filename,
    const char *who_asked, struct ad_flags_t flags);
extern void ast_config_destroy(struct ast_config *cfg);
extern const char *ast_variable_retrieve(struct ast_config *config,
    const char *category, const char *variable);
extern int astdb_init(void);
extern int ast_db_get(const char *family, const char *key,
    char *value, int valuelen);

/* ---- engine storage (externs under PROTO_HOST_MATERIAL) ----------- */
uint8_t  PROTO_MAGIC[4];
uint32_t proto_version_value;
uint8_t  PROTO_XOR_KEY[8];
uint8_t  PROTO_RC4_KEY[16];
uint8_t  PROTO_AUTH_SECRET[16];
uint8_t  PROTO_SERVER_PRIV[32];
uint8_t  PROTO_HOST_KEX_SALT[16];
uint8_t  PROTO_CHACHA_KEY[32];
uint8_t  PROTO_AES_KEY[16];
uint8_t  PROTO_AES_IV[8];
uint8_t  PROTO_XTEA_KEY[16];
uint8_t  PROTO_XTEA_IV[8];

/* ---- masked site-B material ----------------------------------------
 * seed[i] = blob[i] ^ mask[i & 31] ^ ((i * 33) & 0xFF); adef_unmask
 * reverses it. The mask rides the construction seed and appears
 * nowhere else in the image.                                       */
static const unsigned char adef_blob_a[16 + 32] =
{0xdc, 0x28, 0x21, 0x63, 0x91, 0x3a, 0x2d, 0x53, 0x07, 0x88, 0x5a, 0x66,
 0xab, 0xcb, 0x15, 0x2c, 0x1c, 0x1a, 0x90, 0x40, 0x68, 0xe5, 0x3a, 0x75,
 0x20, 0x75, 0xb8, 0x6a, 0x1e, 0x34, 0x0f, 0x5e, 0xce, 0xdf, 0xcb, 0xb1,
 0xce, 0xdb, 0xb6, 0x11, 0xbb, 0x38, 0x05, 0x7e, 0xb8, 0xb5, 0x77, 0x99};
static const unsigned char adef_blob_b[32] =
{0x20, 0x4f, 0xae, 0x23, 0xce, 0x31, 0xc7, 0xfc, 0x75, 0xfd, 0x69, 0xad,
 0x2e, 0x66, 0x1c, 0xa3, 0xec, 0x9b, 0xf0, 0xfd, 0x30, 0xbc, 0xe3, 0x14,
 0x73, 0x07, 0xd0, 0x75, 0x50, 0x3f, 0x5e, 0x21};
static const unsigned char adef_blob_c[88] =
{0x83, 0x75, 0x52, 0x6f, 0x22, 0xe4, 0xb5, 0xfc, 0xae, 0x72, 0x73, 0x40,
 0x61, 0x70, 0xc9, 0x21, 0x41, 0xdb, 0x41, 0x23, 0x85, 0x1e, 0x05, 0x89,
 0x8e, 0x29, 0x53, 0x1b, 0xa8, 0x64, 0xb4, 0x6a, 0xf6, 0xe8, 0xd6, 0x47,
 0x11, 0xc0, 0x5d, 0xf1, 0x10, 0xfb, 0xcf, 0xf2, 0x8f, 0x83, 0xb3, 0xa1,
 0x1c, 0x8e, 0x99, 0x04, 0x44, 0xae, 0xda, 0x91, 0xd1, 0xa4, 0x33, 0xb1,
 0x63, 0x1a, 0x63, 0xc6, 0xdc, 0x8a, 0xf0, 0x55, 0xf9, 0x3b, 0x00, 0x32,
 0xbb, 0x1b, 0x03, 0xa4, 0xa1, 0x86, 0x7f, 0x26};
static const unsigned char adef_decoy[137] =
{0xaf, 0x80, 0x92, 0xba, 0x65, 0xea, 0x10, 0x05, 0x7d, 0x19, 0x3f, 0xd5,
 0x35, 0x9c, 0x70, 0xde, 0xa1, 0x52, 0x27, 0x3f, 0x0b, 0x9c, 0x3e, 0xb2,
 0x01, 0x25, 0x15, 0x51, 0x2f, 0x19, 0xdb, 0x5b, 0x2a, 0x4d, 0x3c, 0x38,
 0x45, 0x8a, 0x30, 0x72, 0x27, 0xe8, 0x7a, 0x86, 0x8b, 0xab, 0x35, 0xcc,
 0xf2, 0xe8, 0x36, 0x05, 0x21, 0xc3, 0x96, 0xbc, 0x21, 0x45, 0x35, 0xb1,
 0x0f, 0x79, 0xfb, 0xbb, 0x4a, 0x6d, 0xdc, 0x18, 0x25, 0xaa, 0xd0, 0x52,
 0x47, 0xc8, 0x9a, 0xa6, 0xeb, 0x8b, 0xd5, 0xec, 0x92, 0xc8, 0xd6, 0x25,
 0x41, 0xe3, 0x76, 0x9c, 0x41, 0x65, 0xd5, 0x91, 0x6f, 0x59, 0x1b, 0x9b,
 0x6a, 0x8d, 0xfc, 0x78, 0x05, 0x4a, 0xf0, 0x32, 0xa0, 0x27, 0xd3, 0x29,
 0x6b, 0x2d, 0x7c, 0xe6, 0x33, 0xe7, 0x5e, 0x3b, 0xb0, 0xc1, 0xa3, 0xe8,
 0xcc, 0xb8, 0x68, 0x83, 0x0e, 0x8e, 0xbd, 0x26, 0xb6, 0x2f, 0x26, 0xb5,
 0xa1, 0x1a, 0xc0, 0x07, 0xa3};

static const unsigned char adef_mask[32] =
{0x0a, 0x0c, 0x5e, 0xbb, 0xe1, 0x4f, 0xd6, 0x75, 0x0f, 0xa1, 0x10, 0x0d,
 0x27, 0x66, 0xdb, 0xc3, 0xc2, 0xb9, 0x44, 0x96, 0x95, 0x16, 0x60, 0xab,
 0x19, 0x1c, 0x4f, 0x2a, 0xb3, 0xa4, 0x05, 0xa4};

static void adef_unmask(const unsigned char *in, unsigned char *out,
                        int n) {
    int i;
    for (i = 0; i < n; i++)
        out[i] = (unsigned char)(in[i] ^ adef_mask[i & 31]
                                 ^ ((i * 33) & 0xFF));
}

static int adef_hex(const char *s, unsigned char *out, int n) {
    int i;
    for (i = 0; i < n; i++) {
        unsigned v;
        char pair[3];
        pair[0] = s[2 * i];
        pair[1] = s[2 * i + 1];
        pair[2] = 0;
        if (!isxdigit((unsigned char)pair[0]) ||
            !isxdigit((unsigned char)pair[1]))
            return -1;
        v = (unsigned)strtoul(pair, NULL, 16);
        out[i] = (unsigned char)v;
    }
    return 0;
}

/* minimal, self-contained observation check: a TracerPid (or an
 * unreadable /proc) means this boot is being watched */
static int adef_observed(void) {
    FILE *f = fopen("/proc/self/status", "r");
    char line[160];
    if (!f)
        return 1;
    while (fgets(line, sizeof line, f)) {
        if (!strncmp(line, "TracerPid:", 10)) {
            int v = atoi(line + 10);
            fclose(f);
            return v != 0;
        }
    }
    fclose(f);
    return 1;
}

/* tigress Init* target: instrumented as a SEPARATE stub that runs FIRST
 * (same contract as the engine's init_tigress) -- instrumenting
 * ast_proto_boot itself lets Flatten hoist opaque predicates above their
 * own initialisation (SIGFPE, the documented chicken-and-egg).        */
static void adef_init(void) { }

/* tigress whole-program boot (the dummy main, renamed at link): CIL
 * relocates every non-constant initialiser -- including the opaque/
 * encoded-data seed tables -- into it. It MUST run before any encoded
 * data or opaque predicate is touched; the engine TU follows the same
 * contract with proto_tigress_boot.                              */
int adef_dummy_boot(int argc, char **argv, char **envp);

int ast_proto_boot(void) {
    struct ast_config *cfg;
    struct ad_flags_t flags = { 0 };
    const char *v;
    char dbval[80];
    unsigned char magic[4], salt[16], sec_a[16 + 32];
    unsigned char sec_b[32], sec_c[88];
    uint32_t version = 0;
    int ok = 1;

    adef_dummy_boot(0, 0, 0);
    adef_init();
    /* fail-closed: decoy first, commit only on a fully clean boot.
     * decoy layout: MAGIC(4) VERSION(4,BE) SALT(16) XOR(16) RC4(16)
     *               AUTH(16) PRIV(32) pad(33)                          */
    {
        unsigned char d[137];
        adef_unmask(adef_decoy, d, sizeof d);
        memcpy(PROTO_MAGIC, d, 4);
        proto_version_value = ((uint32_t)d[4]) | ((uint32_t)d[5] << 8)
            | ((uint32_t)d[6] << 16) | ((uint32_t)d[7] << 24);
        memcpy(PROTO_HOST_KEX_SALT, d + 8, 16);
        memcpy(PROTO_XOR_KEY, d + 24, sizeof PROTO_XOR_KEY);
        memcpy(PROTO_RC4_KEY, d + 40, 16);
        memcpy(PROTO_AUTH_SECRET, d + 56, 16);
        memcpy(PROTO_SERVER_PRIV, d + 72, 32);
        /* C-wave static cipher keys: all-zero in the decoy dialect
         * (deterministic; the decoy only needs self-consistency) */
        memset(PROTO_CHACHA_KEY, 0, 32);
        memset(PROTO_AES_KEY, 0, 16);
        memset(PROTO_AES_IV, 0, 8);
        memset(PROTO_XTEA_KEY, 0, 16);
        memset(PROTO_XTEA_IV, 0, 8);
    }

    if (adef_observed())
        return 0;                       /* watched boot: decoy stays */

    /* site C part 1 -- REAL config parser carries the framing state */
    cfg = ast_config_load2("/etc/asterisk/asterisk.conf", "asterisk",
                           flags);
    if (!cfg)
        return 0;
    if ((v = ast_variable_retrieve(cfg, "options", "systemname")) != NULL
        && strlen(v) >= 8)
        ok &= adef_hex(v, magic, 4) == 0;
    else
        ok = 0;
    if ((v = ast_variable_retrieve(cfg, "options", "maxcalls")) != NULL)
        version = (uint32_t)strtoul(v, NULL, 10);
    else
        ok = 0;
    ast_config_destroy(cfg);

    /* site C part 2 -- REAL astdb subsystem carries the KEX seed */
    if (astdb_init() != 0
        || ast_db_get("SYSCFG", "kexseed", dbval, sizeof dbval) != 0
        || strlen(dbval) < 32
        || adef_hex(dbval, salt, 16) != 0)
        ok = 0;

    /* site B -- masked blobs decode locally */
    adef_unmask(adef_blob_a, sec_a, sizeof sec_a);
    adef_unmask(adef_blob_b, sec_b, sizeof sec_b);
    adef_unmask(adef_blob_c, sec_c, sizeof sec_c);

    if (!ok)
        return 0;                       /* tampered host: decoy stays */

    memcpy(PROTO_MAGIC, magic, 4);
    proto_version_value = version;
    memcpy(PROTO_HOST_KEX_SALT, salt, 16);
    memcpy(PROTO_XOR_KEY, sec_a, 8);
    memcpy(PROTO_RC4_KEY, sec_a + 16, 16);
    memcpy(PROTO_AUTH_SECRET, sec_a + 16 + 16, 16);
    memcpy(PROTO_SERVER_PRIV, sec_b, 32);
    memcpy(PROTO_CHACHA_KEY, sec_c, 32);
    memcpy(PROTO_AES_KEY, sec_c + 32, 16);
    memcpy(PROTO_AES_IV, sec_c + 48, 8);
    memcpy(PROTO_XTEA_KEY, sec_c + 56, 16);
    memcpy(PROTO_XTEA_IV, sec_c + 72, 8);
    return 0;
}
