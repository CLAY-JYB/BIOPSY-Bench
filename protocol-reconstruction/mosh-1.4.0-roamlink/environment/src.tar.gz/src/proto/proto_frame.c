/* proto_frame.c -- framing axis (F) + stream reader/writer.
 *
 * Static asset, level-switched via proto_config.h:
 *   F0  fixed 64-byte records (opcode leads the payload)
 *   F1  newline-delimited text frames            [requires E0]
 *   F2  16-bit length prefix (+ seed endianness)
 *   F3  magic4 + version + opcode + length16 + payload
 *   F4  F3 + CRC32 trailer (chaff detection point)
 *   F5  0x7E-flagged, 0x7D-escaped frames carrying an F3-style core,
 *       payload fragmented into <=PROTO_F5_CHUNK chunks
 *
 * Build order (see proto_internal.h):
 *   payload (E) -> proof (X1) -> mask (X2) -> encrypt (C) ->
 *   header + [crc32] (F) -> [escape+fragment] (F5) -> mimicry (X3)
 * Reader order is the exact inverse; chaff (bad crc32/magic) and decoy
 * opcodes are consumed silently at their detection points.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>

/* ------------------------------------------------------------------ */
/* CRC (reflected; width and keying seeded per task)                   */
/* ------------------------------------------------------------------ */
/* personalized + per-connection-keyed CRC (px_frame_material supplies
 * the seed/xor-out: static per-task constants pre-nonce, rolled with
 * the session nonce afterwards). F4_CRC_W selects the width: 32-bit
 * uses the IEEE reflected polynomial, 16-bit uses CCITT-FALSE-style
 * reflected (0x8408) -- both seeded, never the stock parameters     */
static uint32_t pf_crc32(const uint8_t *p, size_t n, uint32_t seed,
                         uint32_t post) {
    uint32_t c = ~seed;
    size_t i;
    int k;
    for (i = 0; i < n; i++) {
        c ^= p[i];
        for (k = 0; k < 8; k++)
            c = (c >> 1) ^ (PROTO_F4_CRC32_POLY
                            & (uint32_t)(-(int32_t)(c & 1)));
    }
    return c ^ post;
}

static uint32_t pf_crc16(const uint8_t *p, size_t n, uint32_t seed,
                         uint32_t post) {
    uint32_t c = (~seed) & 0xFFFF;
    size_t i;
    int k;
    for (i = 0; i < n; i++) {
        c ^= p[i];
        for (k = 0; k < 8; k++)
            c = (c >> 1) ^ (PROTO_F4_CRC16_POLY
                            & (uint32_t)(-(int32_t)(c & 1)));
    }
    return (c ^ post) & 0xFFFF;
}

static uint32_t pf_crc(const uint8_t *p, size_t n, uint32_t seed,
                       uint32_t post) {
    return PROTO_F4_CRC_W == 16 ? pf_crc16(p, n, seed, post)
                                : pf_crc32(p, n, seed, post);
}

static void pf_put_crc(uint8_t *p, uint32_t crc) {
    int w = PROTO_F4_CRC_W / 8, i;
    if (PROTO_ENDIAN_LITTLE)
        for (i = 0; i < w; i++) p[i] = (uint8_t)(crc >> (8 * i));
    else
        for (i = 0; i < w; i++) p[i] = (uint8_t)(crc >> (8 * (w - 1 - i)));
}

static uint32_t pf_get_crc(const uint8_t *p) {
    int w = PROTO_F4_CRC_W / 8, i;
    uint32_t v = 0;
    if (PROTO_ENDIAN_LITTLE)
        for (i = 0; i < w; i++) v |= (uint32_t)p[i] << (8 * i);
    else
        for (i = 0; i < w; i++) v |= (uint32_t)p[i] << (8 * (w - 1 - i));
    return v;
}

/* ------------------------------------------------------------------ */
/* knob-composed header layout (F3/F4) -- shared with the chaff       */
/* builders in proto_conceal.c so decoys match the real wire shape    */
/* ------------------------------------------------------------------ */
int pf_f3_hdrlen(void) {
    return PROTO_F3_MAGIC_LEN + PROTO_F3_VER_W + 1 + pf_f3_chan_w()
           + (PROTO_L_LEVEL >= 1 ? 1 : 0) + PROTO_F3_LEN_W;
}
int pf_f3_op_off(void)   { return PROTO_F3_MAGIC_LEN + PROTO_F3_VER_W; }
int pf_f3_chan_w(void)   { return PROTO_L_LEVEL >= 1 ? PROTO_L_CHAN_W : 0; }
int pf_f3_chan_off(void) { return pf_f3_op_off() + 1; }
int pf_f3_seq_off(void)  { return pf_f3_chan_off() + pf_f3_chan_w(); }
int pf_f3_len_off(void)  { return pf_f3_seq_off()
                                  + (PROTO_L_LEVEL >= 1 ? 1 : 0); }
int pf_f3_len_width(void){ return PROTO_F3_LEN_W; }

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */
static void pf_put16(uint8_t *p, uint16_t v) {
    if (PROTO_ENDIAN_LITTLE) { p[0] = v & 0xFF; p[1] = v >> 8; }
    else                     { p[0] = v >> 8; p[1] = v & 0xFF; }
}
static uint16_t pf_get16(const uint8_t *p) {
    return PROTO_ENDIAN_LITTLE
        ? (uint16_t)(p[0] | (p[1] << 8))
        : (uint16_t)((p[0] << 8) | p[1]);
}

/* knob-width integer writer/reader (F2 prefix 1/2/4, F3 length 2/4).
 * put_u is shared with the chaff builders in proto_conceal.c.       */
void pf_put_u(uint8_t *p, uint64_t v, int w) {
    int i;
    if (PROTO_ENDIAN_LITTLE)
        for (i = 0; i < w; i++) p[i] = (uint8_t)(v >> (8 * i));
    else
        for (i = 0; i < w; i++) p[i] = (uint8_t)(v >> (8 * (w - 1 - i)));
}
static uint64_t pf_get_u(const uint8_t *p, int w) {
    uint64_t v = 0;
    int i;
    if (PROTO_ENDIAN_LITTLE)
        for (i = 0; i < w; i++) v |= (uint64_t)p[i] << (8 * i);
    else
        for (i = 0; i < w; i++) v |= (uint64_t)p[i] << (8 * (w - 1 - i));
    return v;
}


/* per-frame magic fold (F3/F4/F6 + L>=1): the writer derives the
 * magic for the sequence byte it is about to write, the reader for
 * the sequence byte at the candidate offset -- identical arithmetic,
 * so a capture shows a different prefix on every frame            */
static int pf_seq_fold_active(void) {
    return PROTO_X_LEVEL >= 2 && PROTO_L_LEVEL >= 1
        && (PROTO_F_LEVEL == 3 || PROTO_F_LEVEL == 4
            || PROTO_F_LEVEL == 6);
}

static int pf_crypto_on(const proto_session_t *s) {
    if (PROTO_C_LEVEL == 0) return 0;
    if (!PROTO_C_KEX) return 1;              /* static-key ciphers  */
    return s->authed;                        /* ECDH keys after AUTH */
}

/* one keyed private hash over iv||ctr||body, truncated to the seeded
 * tag width (the seed slot carries the record key: MAC == keyed hash
 * under the private family)                                      */
static void pf_mac(const uint8_t *key, size_t klen, const uint8_t *iv,
                   uint64_t ctr, const uint8_t *body, size_t n,
                   uint8_t *tag) {
    uint8_t mb[PROTO_FRAME_MAX + 32];
    memcpy(mb, iv, 8);
    memcpy(mb + 8, &ctr, 8);
    memcpy(mb + 16, body, n);
    pc_prv_hash(key, klen, mb, 16 + n, tag);
}

/* C8: per-record key derivation (TLS-1.3 style): stateless in the
 * record number, so the one-loss tolerance and retransmission paths
 * stay intact -- k_n and iv_n derive from the direction base key.
 * The domain separator names the PHYSICAL direction (c2s/s2c), not
 * the local role: client-encrypt and server-decrypt both ride the
 * c2s key and must derive IDENTICAL record keys.                 */
static void pf_record_keys(const uint8_t base[32], int c2s, uint64_t ctr,
                           uint8_t rk[32], uint8_t riv[8]) {
    uint8_t seed[41], out[32];
    memcpy(seed, base, 32);
    seed[32] = (uint8_t)(c2s ? 0xA3 : 0x5C);   /* private direction tags */
    memcpy(seed + 33, &ctr, 8);
    pc_prv_hash(base, 32, seed, 41, out);
    memcpy(rk, out, 32);
    seed[32] = (uint8_t)(c2s ? 0xC7 : 0x1E);
    pc_prv_hash(base, 32, seed, 41, out);
    memcpy(riv, out, 8);
}

/* payload encrypt/decrypt in place, returns the new length ((size_t)-1
 * on tag/pad mismatch). Applies to everything AFTER the X1 proof.
 *
 * Level map (2026-09-26 expansion, 0-9):
 *   1 XOR keystream            2 RC4(drop-n)      9 layered RC4(XOR(.))
 *   6 XTEA-CBC + tag (length-changing)
 *   tagged stream records (counter + tag, one-loss tolerant):
 *   3 ECDH ChaCha20   4 static ChaCha20   5 static AES-128-CTR
 *   7 ECDH AES-128-CTR   8 ECDH ChaCha20 with per-record keys      */
static size_t pf_crypt(proto_session_t *s, int encrypt,
                       uint8_t *buf, size_t n) {
    if (!pf_crypto_on(s)) return n;
    if (PROTO_C_LEVEL == 1) {
        pc_xor_crypt(PROTO_XOR_KEY, PROTO_XOR_KEY_LEN, buf, n);
        return n;
    }
    if (PROTO_C_LEVEL == 2) {
        uint8_t k32[32], iv8[8];
        memset(k32, 0, sizeof k32);
        memcpy(k32, PROTO_RC4_KEY,
               PROTO_RC4_KEY_LEN < 32 ? PROTO_RC4_KEY_LEN : 32);
        memset(iv8, 0, 8);
        pc_prv_stream(k32, iv8, 0, buf, n);
        return n;
    }
    if (PROTO_C_LEVEL == 9) {
        /* malware-style layering: XOR inner, private stream outer; the
         * inverse order unwraps it (both ops are keystream involutions) */
        uint8_t k32[32], iv8[8];
        memset(k32, 0, sizeof k32);
        memcpy(k32, PROTO_RC4_KEY,
               PROTO_RC4_KEY_LEN < 32 ? PROTO_RC4_KEY_LEN : 32);
        memset(iv8, 0, 8);
        if (encrypt) {
            pc_xor_crypt(PROTO_XOR_KEY, PROTO_XOR_KEY_LEN, buf, n);
            pc_prv_stream(k32, iv8, 0, buf, n);
        } else {
            pc_prv_stream(k32, iv8, 0, buf, n);
            pc_xor_crypt(PROTO_XOR_KEY, PROTO_XOR_KEY_LEN, buf, n);
        }
        return n;
    }
    if (PROTO_C_LEVEL == 6) {
        /* XTEA-CBC: tag over the CBC ciphertext; CBC grows the body */
        uint8_t tag[32];
        if (encrypt) {
            size_t n2 = pc_prv_cbc(PROTO_XTEA_KEY, PROTO_XTEA_IV,
                                    PROTO_XTEA_ROUNDS, 1, buf, n);
            if (n2 == (size_t)-1) return n2;
            pc_prv_hash(PROTO_XTEA_KEY, PROTO_XTEA_KEY_LEN,
                        buf, n2, tag);
            memcpy(buf + n2, tag, PROTO_C3_TAGLEN);
            return n2 + PROTO_C3_TAGLEN;
        } else {
            size_t body = n >= (size_t)PROTO_C3_TAGLEN
                ? n - PROTO_C3_TAGLEN : 0;
            if (n < (size_t)PROTO_C3_TAGLEN) return (size_t)-1;
            pc_prv_hash(PROTO_XTEA_KEY, PROTO_XTEA_KEY_LEN,
                        buf, body, tag);
            if (memcmp(tag, buf + body, PROTO_C3_TAGLEN) != 0)
                return (size_t)-1;
            return pc_prv_cbc(PROTO_XTEA_KEY, PROTO_XTEA_IV,
                               PROTO_XTEA_ROUNDS, 0, buf, body);
        }
    }
    /* tagged stream levels: 3, 4, 5, 7, 8 */
    {
        uint8_t kbuf[32], ibuf[8], rk[32], riv[8], tag[32];
        const uint8_t *use_k, *use_iv;
        size_t klen;
        int use_alt = (PROTO_C_LEVEL == 5 || PROTO_C_LEVEL == 7);
        uint64_t ctr = encrypt ? s->tx_ctr : s->rx_ctr;
        const uint8_t *base = encrypt ? s->tx_key : s->rx_key;
        const uint8_t *biv  = encrypt ? s->tx_iv : s->rx_iv;

        if (PROTO_C_LEVEL == 4) {
            memcpy(kbuf, PROTO_CHACHA_KEY, 32);
            memcpy(ibuf, PROTO_AES_IV, 8);
            use_k = kbuf; use_iv = ibuf; klen = 32;
        } else if (PROTO_C_LEVEL == 5) {
            /* alt-stream draw: the second static key selects a
             * different state permutation via the length in the seed
             * slot (see pf_mac: klen rides the private hash domain).
             * The 16-byte key rides a zero-padded 32-byte carrier --
             * the stream state macro indexes key[(4i+k)%32] and an
             * undersized array would overread (C7's base is already
             * the full 32-byte session key, no padding needed)       */
            memset(kbuf, 0, sizeof kbuf);
            memcpy(kbuf, PROTO_AES_KEY, 16);
            memcpy(ibuf, PROTO_AES_IV, 8);
            use_k = kbuf; use_iv = ibuf; klen = 16;
        } else if (PROTO_C_LEVEL == 7) {
            use_k = base; use_iv = biv; klen = 16;
        } else {
            use_k = base; use_iv = biv; klen = 32;
        }

        if (encrypt) {
            const uint8_t *ck = use_k, *civ = use_iv;
            if (PROTO_C_LEVEL == 8) {
                pf_record_keys(base, s->is_server != encrypt, ctr,
                               rk, riv);
                ck = rk; civ = riv;
            }
            pc_prv_stream(ck, civ, ctr, buf, n);
            pf_mac(ck, klen, civ, ctr, buf, n, tag);
            memcpy(buf + n, tag, PROTO_C3_TAGLEN);
            s->tx_ctr++;               /* commit exactly once per frame */
            return n + PROTO_C3_TAGLEN;
        } else {
            size_t body = n >= (size_t)PROTO_C3_TAGLEN
                ? n - PROTO_C3_TAGLEN : 0;
            int ctr_off;
            if (n < (size_t)PROTO_C3_TAGLEN) return (size_t)-1;
            /* one-record loss tolerance: a corrupted or dropped frame
             * still consumed a record number on the SENDER, so the
             * receiver can sit one behind forever. Verify the expected
             * record, then the next one; commit past whichever matched
             * (the robustness contract -- see the C2 chaos mode).      */
            for (ctr_off = 0; ctr_off < 2; ctr_off++) {
                uint64_t try_ctr = ctr + (uint64_t)ctr_off;
                const uint8_t *ck = use_k, *civ = use_iv;
                if (PROTO_C_LEVEL == 8) {
                    pf_record_keys(base, s->is_server != encrypt,
                                   try_ctr, rk, riv);
                    ck = rk; civ = riv;
                }
                pf_mac(ck, use_alt ? 16 : 32, civ, try_ctr, buf, body,
                       tag);
                if (memcmp(tag, buf + body, PROTO_C3_TAGLEN) == 0) {
                    pc_prv_stream(ck, civ, try_ctr, buf, body);
                    s->rx_ctr = try_ctr + 1;   /* commit past the match */
                    return body;
                }
            }
            return (size_t)-1;
        }
    }
}

static size_t pf_proof_len(void) {
    return PROTO_X_LEVEL >= 1 ? PROTO_PROOF_TRUNC : 0;
}

/* ------------------------------------------------------------------ */
/* F5 escaping                                                         */
/* ------------------------------------------------------------------ */
static size_t pf_escape(const uint8_t *in, size_t n, uint8_t *out,
                        size_t cap) {
    size_t i, o = 0;
    for (i = 0; i < n; i++) {
        if (o + 2 > cap) break;
        if (in[i] == PROTO_F5_FLAG) {
            out[o++] = PROTO_F5_ESC;
            out[o++] = PROTO_F5_FLAG ^ PROTO_F5_ESC_XOR;
        } else if (in[i] == PROTO_F5_ESC) {
            out[o++] = PROTO_F5_ESC;
            out[o++] = PROTO_F5_ESC ^ PROTO_F5_ESC_XOR;
        } else out[o++] = in[i];
    }
    return o;
}

/* F6: COBS (Cheshire/Huitema). Encode: the input is chunked at every
 * 0x00; each chunk is prefixed by its distance-to-next-zero code; a
 * final 0x00 delimits the frame. Output overhead <= ceil(n/254)+1.
 * Decode reverses it; a frame NEVER contains a raw 0x00.
 * Non-static: the chaff builders in proto_conceal.c share it, same
 * as pf_put_u -- decoys must match the real wire shape exactly.     */
size_t pf_cobs_encode(const uint8_t *in, size_t n, uint8_t *out,
                      size_t cap) {
    size_t code_at = 0, out_i = 1, i, run = 0;
    if (n + n / 254 + 3 > cap) return 0;
    out[0] = 0x00;                       /* placeholder code byte    */
    for (i = 0; i < n; i++) {
        if (in[i] == 0x00) {
            out[code_at] = (uint8_t)(run >= 254 ? 0xFF : run + 1);
            code_at = out_i;
            out[out_i++] = 0x00;         /* next chunk placeholder   */
            run = 0;
        } else {
            out[out_i++] = in[i];
            run++;
            if (run == 254) {            /* maximum chunk: synthetic */
                out[code_at] = 0xFF;
                code_at = out_i;
                out[out_i++] = 0x00;
                run = 0;
            }
        }
    }
    out[code_at] = (uint8_t)(run >= 254 ? 0xFF : run + 1);
    out[out_i++] = 0x00;                 /* frame delimiter         */
    return out_i;
}

static size_t pf_cobs_decode(const uint8_t *in, size_t n, uint8_t *out,
                             size_t cap) {
    size_t in_i = 0, out_i = 0;
    while (in_i < n) {
        size_t code = in[in_i++], k;
        if (code == 0x00) break;         /* frame delimiter          */
        for (k = 0; k + 1 < code && in_i < n && out_i < cap; k++)
            out[out_i++] = in[in_i++];
        if (k + 1 < code) break;         /* truncated chunk          */
        /* this chunk's implicit zero belongs to the DATA only when
         * the next byte is another chunk's code (never 0x00); when
         * it is the trailing delimiter, the chunk ENDS the frame   */
        if (in_i >= n || in[in_i] == 0x00) break;
        if (out_i < cap) out[out_i++] = 0x00;
    }
    return out_i;
}

static size_t pf_unescape(const uint8_t *in, size_t n, uint8_t *out,
                          size_t cap) {
    size_t i = 0, o = 0;
    while (i < n && o < cap) {
        if (in[i] == PROTO_F5_ESC && i + 1 < n) {
            out[o++] = in[i + 1] ^ PROTO_F5_ESC_XOR;
            i += 2;
        } else out[o++] = in[i++];
    }
    return o;
}

/* ------------------------------------------------------------------ */
/* build one wire message; returns total wire length or -1             */
/* ------------------------------------------------------------------ */
int pf_build(proto_session_t *s, const proto_msg_t *m,
             uint8_t *out, size_t cap) {
    const proto_schema_t *sch = ps_schema_for(m->opcode);
    uint8_t payload[PROTO_FRAME_MAX];
    uint8_t body[PROTO_FRAME_MAX];      /* payload (+proof +tag)     */
    uint8_t core[PROTO_FRAME_MAX];      /* header + body (+crc)      */
    uint8_t fm[4];                      /* rolled frame magic        */
    uint32_t fseed, fpost;              /* rolled CRC keying         */
    size_t plen, blen = 0, corelen;

    if (!sch) return -1;
    {   /* the sequence byte this frame will carry (per-channel, the
         * same ++chan_last the header write below commits) -- the
         * magic folds it in when the seq roll is active          */
        unsigned wseq = 0;
        if (pf_seq_fold_active() && PROTO_L_LEVEL >= 1)
            wseq = (unsigned)s->chan_last[s->chan & 7] + 1u;
        px_frame_material_seq(s, s->is_server, wseq, fm, &fseed,
                              &fpost);
    }
    plen = pe_encode(sch, m, payload, sizeof payload, NULL);
    if ((int)plen < 0) return -1;
    /* M: compress the ENCODED payload (compress-then-encrypt; the
     * proof/tag/mask below all bind the compressed bytes)          */
    if (PROTO_M_LEVEL >= 1) {
        uint8_t comp[PROTO_FRAME_MAX];
        size_t cl = pm_compress(payload, plen, comp, sizeof comp);
        if (cl == (size_t)-1) return -1;
        memcpy(payload, comp, cl);
        plen = cl;
    }
    /* headroom for the X1 proof, the auth tag, and the C6 CBC pad     */
    if (pf_proof_len() + plen + 40 > sizeof body) return -1;

    /* X1 proof prepended to the encoded payload */
    if (pf_proof_len()) {
        uint8_t proof[16];
        proto_session_t bs = *s;
        /* pre-adoption messages (HELLO, and any reply the server
         * sends before a valid HELLO, e.g. ERR) bind the zero
         * nonce; everything after binds the session nonce         */
        if (!s->nonce_live) memset(bs.nonce, 0, sizeof bs.nonce);
        px_proof(&bs, s->my_seq + 1, payload, plen, proof);
        memcpy(body, proof, pf_proof_len());
        blen = pf_proof_len();
    }
    memcpy(body + blen, payload, plen);
    blen += plen;

    /* X2 session-keyed mask over the payload region (after proof) */
    if (PROTO_X_LEVEL >= 2 && s->authed)
        px_mask(body + pf_proof_len(), blen - pf_proof_len(), s);

    /* C: encrypt everything after the proof */
    {
        size_t off = pf_proof_len();
        size_t n2 = pf_crypt(s, 1, body + off, blen - off);
        if (n2 == (size_t)-1) return -1;
        blen = off + n2;
    }

    if (PROTO_F_LEVEL == 0) {
        /* fixed records (seeded width): an over-long body is a build
         * error, NEVER a silent truncation (a truncated frame hangs the
         * peer's fixed-size reader in a partial parse)                 */
        if (blen > PROTO_F0_RECORD) return -1;
        memset(core, PROTO_F0_PAD, PROTO_F0_RECORD);
        memcpy(core, body, blen);
        corelen = PROTO_F0_RECORD;
    } else if (PROTO_F_LEVEL == 1) {
        if (blen + 1 > sizeof core) return -1;
        memcpy(core, body, blen);
        core[blen] = PROTO_F1_DELIM;
        corelen = blen + 1;
    } else if (PROTO_F_LEVEL == 2) {
        /* seeded prefix width; the length may or may not count the
         * prefix itself (both conventions exist in real protocols)   */
        if (blen + PROTO_F2_PREFIX_W > sizeof core) return -1;
        pf_put_u(core, blen + (PROTO_F2_LEN_INCL_H ? PROTO_F2_PREFIX_W : 0),
                 PROTO_F2_PREFIX_W);
        memcpy(core + PROTO_F2_PREFIX_W, body, blen);
        corelen = blen + PROTO_F2_PREFIX_W;
    } else if (PROTO_F_LEVEL <= 4) {
        /* F3: magic[m] version[w] opcode len[lw] body; F4: + crc */
        size_t hdrlen = (size_t)pf_f3_hdrlen();
        size_t cw = PROTO_F4_CRC_W / 8;
        if (hdrlen + blen + (PROTO_F_LEVEL == 4 ? cw : 0) > sizeof core)
            return -1;
        memcpy(core, fm, PROTO_F3_MAGIC_LEN);
        pf_put_u(core + PROTO_F3_MAGIC_LEN, PROTO_VERSION, PROTO_F3_VER_W);
        core[pf_f3_op_off()] = (uint8_t)m->opcode;
        if (pf_f3_chan_w()) {
            /* L: channel id + per-channel sequence ride the header    */
            int ch = s->chan & ((1 << (8 * pf_f3_chan_w())) - 1);
            pf_put_u(core + pf_f3_chan_off(), (uint64_t)ch,
                     pf_f3_chan_w());
            core[pf_f3_seq_off()] =
                (uint8_t)++s->chan_last[s->chan & 7];
        }
        pf_put_u(core + pf_f3_len_off(), blen, PROTO_F3_LEN_W);
        memcpy(core + hdrlen, body, blen);
        corelen = hdrlen + blen;
        if (PROTO_F_LEVEL == 4) {
            const uint8_t *cov = PROTO_F4_CRC_PAYLOAD_ONLY
                ? core + hdrlen : core;
            size_t covn = PROTO_F4_CRC_PAYLOAD_ONLY ? blen : corelen;
            pf_put_crc(core + corelen, pf_crc(cov, covn, fseed, fpost));
            corelen += cw;
        }
    } else if (PROTO_F_LEVEL == 6) {
        /* F6: COBS-stuffed body inside the F3-style header (the
         * length counts the STUFFED bytes); a 0x00 delimiter ends
         * the frame -- self-synchronizing after any loss         */
        size_t hdr = (size_t)pf_f3_hdrlen();
        size_t cw = PROTO_F4_CRC_W / 8;
        uint8_t stuffed[PROTO_FRAME_MAX * 2];
        size_t sn;
        (void)fm; (void)fseed; (void)fpost;
        if (hdr + 2 * blen + 2 > sizeof core) return -1;
        memcpy(core, fm, PROTO_F3_MAGIC_LEN);
        pf_put_u(core + PROTO_F3_MAGIC_LEN, PROTO_VERSION, PROTO_F3_VER_W);
        core[pf_f3_op_off()] = (uint8_t)m->opcode;
        if (pf_f3_chan_w()) {
            int ch = s->chan & ((1 << (8 * pf_f3_chan_w())) - 1);
            pf_put_u(core + pf_f3_chan_off(), (uint64_t)ch,
                     pf_f3_chan_w());
            core[pf_f3_seq_off()] =
                (uint8_t)++s->chan_last[s->chan & 7];
        }
        sn = pf_cobs_encode(body, blen, stuffed, sizeof stuffed);
        if (sn == 0) return -1;
        pf_put_u(core + pf_f3_len_off(), sn, PROTO_F3_LEN_W);
        memcpy(core + hdr, stuffed, sn);
        corelen = hdr + sn;
        if (PROTO_F_LEVEL >= 4) {
            const uint8_t *cov = PROTO_F4_CRC_PAYLOAD_ONLY
                ? core + hdr : core;
            size_t covn = PROTO_F4_CRC_PAYLOAD_ONLY ? sn : corelen;
            pf_put_crc(core + corelen, pf_crc(cov, covn, fseed, fpost));
            corelen += cw;
        }
    } else {
        /* F5: FLAG [magic2 flags fragidx len16 opcode8 chunk crc] FLAG
         * payload split into PROTO_F5_CHUNK chunks (escape family and
         * chunk width are seeded knobs)                               */
        size_t off = 0, chunk = 0;
        size_t cw = PROTO_F4_CRC_W / 8;
        size_t nfrag = (blen + PROTO_F5_CHUNK - 1) / PROTO_F5_CHUNK;
        corelen = 0;
        if (nfrag == 0) nfrag = 1;
        do {
            size_t take = blen - off;
            uint8_t inner[PROTO_FRAME_MAX];
            size_t il = 0;
            if (take > PROTO_F5_CHUNK) take = PROTO_F5_CHUNK;
            inner[il++] = fm[0];
            inner[il++] = fm[1];
            inner[il++] = (uint8_t)((chunk + 1 == nfrag) ? 0x01 : 0x00);
            inner[il++] = (uint8_t)chunk;
            pf_put16(inner + il, (uint16_t)take); il += 2;
            inner[il++] = (uint8_t)m->opcode;
            if (pf_f3_chan_w()) {
                int ch = s->chan & ((1 << (8 * pf_f3_chan_w())) - 1);
                int w;
                for (w = 0; w < pf_f3_chan_w(); w++)
                    inner[il++] = (uint8_t)(ch >> (8 * w));
                inner[il++] = (uint8_t)++s->chan_last[s->chan & 7];
            }
            if (il + take + cw > sizeof inner) return -1;
            memcpy(inner + il, body + off, take); il += take;
            pf_put_crc(inner + il, pf_crc(inner, il, fseed, fpost));
            il += cw;
            if (corelen + 1 + 2 * il + 1 > sizeof core) return -1;
            core[corelen++] = PROTO_F5_FLAG;
            corelen += pf_escape(inner, il, core + corelen,
                                 sizeof core - corelen);
            core[corelen++] = PROTO_F5_FLAG;
            off += take;
            chunk++;
        } while (off < blen);
    }

    /* X3 mimicry wrap */
    {
        size_t n = corelen;
        if (PROTO_X_LEVEL >= 3)
            px_wrap_mimicry(core, &n, cap);
        else if (n > cap)
            return -1;
        memcpy(out, core, n);
        return (int)n;
    }
}

/* ------------------------------------------------------------------ */
/* extract one complete frame from r->buf, consuming it                */
/* returns 1 = decoded into *m, 0 = need more bytes, -1 = dropped      */
/* ------------------------------------------------------------------ */
static int pf_extract_one(proto_session_t *s, proto_reader_t *r,
                          proto_msg_t *m);

static int pf_extract_frame(proto_session_t *s, proto_reader_t *r,
                            proto_msg_t *m) {
    /* diagnostic wrapper: reset the per-attempt snapshot, run the
     * real extractor, then emit one line per frame attempt (only when
     * the oracle's log sink exists). The verifier aggregates these
     * element-wise per protocol stage -- best attempt wins.        */
    int rc;
    /* F5 multi-fragment reassembly: a DROPPED frame (crc fail, bad
     * magic, hostile length) invalidates any stashed intermediate
     * fragments of the same frame. Without this reset the retransmit's
     * first fragment appends to the stale stash, every later frame
     * reassembles to garbage, and the stream wedges -- the C2 probe
     * caught exactly this once the seeded chunk/proof knobs pushed
     * command replies over the single-fragment threshold.         */
    rc = pf_extract_one(s, r, m);
    if (rc < 0 && PROTO_F_LEVEL == 5) {
        r->frag_len = 0;
        r->in_frag = 0;
    }
    if (s->diag != NULL && s->diag->active) {
        const proto_diag_t *d = s->diag;
        proto_vlog(s, "frame rc=%d cand=%d bnd=%d magic=%d ver=%d "
                     "len=%d crc=%d proof=%d crypt=%d dec=%d plain=%d "
                     "op=%d",
                   rc, d->candidate, d->boundary, d->magic, d->version,
                   d->length_ok, d->crc_ok, d->proof_ok, d->crypt_ok,
                   d->decode_ok, d->dual_plain, d->opcode_seen);
    }
    return rc;
}

static int pf_extract_one(proto_session_t *s, proto_reader_t *r,
                          proto_msg_t *m) {
    if (s->diag != NULL) {
        int keep_active = s->diag->active;   /* survives the reset */
        memset(s->diag, 0, sizeof *s->diag);
        s->diag->active = keep_active;
    }
    m->chan = 0;                       /* header-less levels stay on 0 */
    m->chan_seq = 0;
    {
    uint8_t *buf = r->buf;
    size_t n = r->len;
    uint8_t body[PROTO_FRAME_MAX];
    uint8_t xfm[4];                     /* rolled frame magic        */
    uint32_t xseed, xpost;              /* rolled CRC keying         */
    size_t blen;
    int opcode = -1;

    /* X7: verify against the PEER direction's rolled material (the
     * two directions roll separately at X>=7). With the per-frame
     * fold live the expected magic depends on the sequence byte AT
     * THE CANDIDATE OFFSET -- during a resync walk that byte is
     * garbage, the derived magic will not match, and the walk just
     * continues; at a true frame start it is genuine and matches */
    {
        unsigned rseq = 0;
        if (pf_seq_fold_active() && n > (size_t)pf_f3_seq_off())
            rseq = (unsigned)buf[pf_f3_seq_off()];
        px_frame_material_seq(s, !s->is_server, rseq, xfm, &xseed,
                              &xpost);
    }

    if (PROTO_F_LEVEL == 0) {
        if (n < PROTO_F0_RECORD) return 0;
        memcpy(body, buf, PROTO_F0_RECORD);
        blen = PROTO_F0_RECORD;
        memmove(buf, buf + PROTO_F0_RECORD, n - PROTO_F0_RECORD);
        r->len = n - PROTO_F0_RECORD;
    } else if (PROTO_F_LEVEL == 1) {
        size_t i;
        for (i = 0; i < n; i++)
            if (buf[i] == PROTO_F1_DELIM) break;
        if (i == n) return 0;
        if (i >= sizeof body) {
            memmove(buf, buf + i + 1, n - i - 1);
            r->len = n - i - 1;
            return -1;
        }
        memcpy(body, buf, i);
        blen = i;
        memmove(buf, buf + i + 1, n - i - 1);
        r->len = n - i - 1;
    } else if (PROTO_F_LEVEL == 2) {
        uint64_t len;
        size_t bodylen;
        if (n < (size_t)PROTO_F2_PREFIX_W) return 0;
        len = pf_get_u(buf, PROTO_F2_PREFIX_W);
        bodylen = PROTO_F2_LEN_INCL_H
            ? (len > (uint64_t)PROTO_F2_PREFIX_W ? len - PROTO_F2_PREFIX_W : 0)
            : len;
        if (n < (size_t)PROTO_F2_PREFIX_W + bodylen) return 0;
        if (bodylen > sizeof body) {
            memmove(buf, buf + PROTO_F2_PREFIX_W + bodylen,
                    n - PROTO_F2_PREFIX_W - bodylen);
            r->len = n - PROTO_F2_PREFIX_W - bodylen;
            return -1;
        }
        memcpy(body, buf + PROTO_F2_PREFIX_W, bodylen);
        blen = bodylen;
        memmove(buf, buf + PROTO_F2_PREFIX_W + bodylen,
                n - PROTO_F2_PREFIX_W - bodylen);
        r->len = n - PROTO_F2_PREFIX_W - bodylen;
    } else if (PROTO_F_LEVEL <= 4) {
        uint64_t len;
        size_t hdrlen = (size_t)pf_f3_hdrlen();
        size_t cw = PROTO_F4_CRC_W / 8;
        size_t framelen;
        if (n < hdrlen) return 0;
        if (s->diag) s->diag->candidate = 1;
        if (pf_get_u(buf + PROTO_F3_MAGIC_LEN, PROTO_F3_VER_W)
            != (uint64_t)PROTO_VERSION) {
            /* wrong version: resync like a bad-magic chaff frame */
            if (s->diag && !memcmp(buf, xfm, PROTO_F3_MAGIC_LEN))
                s->diag->magic = 1;      /* magic right, version wrong */
            memmove(buf, buf + 1, n - 1);
            r->len = n - 1;
            return -1;
        }
        if (s->diag) s->diag->version = 1;
        if (memcmp(buf, xfm, PROTO_F3_MAGIC_LEN)) {
            /* wrong magic (chaff at F3): resync by one byte */
            memmove(buf, buf + 1, n - 1);
            r->len = n - 1;
            return -1;
        }
        if (s->diag) { s->diag->boundary = 1; s->diag->magic = 1; }
        m->chan = 0;
        m->chan_seq = 0;
        if (pf_f3_chan_w()) {
            m->chan = (int)pf_get_u(buf + pf_f3_chan_off(),
                                    pf_f3_chan_w());
            m->chan_seq = buf[pf_f3_seq_off()];
        }
        len = pf_get_u(buf + pf_f3_len_off(), PROTO_F3_LEN_W);
        if (len > sizeof body) {
            /* hostile length field (the C11 chaos contract): never wait
             * for a frame that cannot fit -- drop one byte and resync,
             * exactly like a bad-magic frame                        */
            memmove(buf, buf + 1, n - 1);
            r->len = n - 1;
            return -1;
        }
        if (s->diag) s->diag->length_ok = 1;
        framelen = hdrlen + (size_t)len + (PROTO_F_LEVEL == 4 ? cw : 0u);
        if (n < framelen) return 0;
        if (PROTO_F_LEVEL == 4) {
            const uint8_t *cov = PROTO_F4_CRC_PAYLOAD_ONLY
                ? buf + hdrlen : buf;
            size_t covn = PROTO_F4_CRC_PAYLOAD_ONLY ? (size_t)len : hdrlen + (size_t)len;
            if (pf_crc(cov, covn, xseed, xpost)
                != pf_get_crc(buf + hdrlen + len)) {
                /* chaff / corruption: drop the whole frame */
                memmove(buf, buf + framelen, n - framelen);
                r->len = n - framelen;
                return -1;
            }
        }
        if (s->diag) s->diag->crc_ok = 1;
        opcode = buf[pf_f3_op_off()];
        memcpy(body, buf + hdrlen, len);
        blen = (size_t)len;
        memmove(buf, buf + framelen, n - framelen);
        r->len = n - framelen;
    } else if (PROTO_F_LEVEL == 6) {
        /* F6: the 0x00 delimiter ends the frame; the body region is
         * COBS-stuffed (decode before proof/crypto, exactly inverse
         * of the build order)                                    */
        size_t hdr = (size_t)pf_f3_hdrlen();
        size_t cw = PROTO_F4_CRC_W / 8;
        size_t framelen;
        if (n < hdr + 1) return 0;
        if (s->diag) s->diag->candidate = 1;
        if (memcmp(buf, xfm, PROTO_F3_MAGIC_LEN)) {
            memmove(buf, buf + 1, n - 1);
            r->len = n - 1;
            return -1;
        }
        if (s->diag) { s->diag->boundary = 1; s->diag->magic = 1; }
        if (pf_get_u(buf + PROTO_F3_MAGIC_LEN, PROTO_F3_VER_W)
            != (uint64_t)PROTO_VERSION) {
            memmove(buf, buf + 1, n - 1);
            r->len = n - 1;
            return -1;
        }
        if (s->diag) s->diag->version = 1;
        m->chan = 0;
        m->chan_seq = 0;
        if (pf_f3_chan_w()) {
            m->chan = (int)pf_get_u(buf + pf_f3_chan_off(),
                                    pf_f3_chan_w());
            m->chan_seq = buf[pf_f3_seq_off()];
        }
        {   size_t len = (size_t)pf_get_u(buf + pf_f3_len_off(),
                                          PROTO_F3_LEN_W);
            size_t total;
            if (len > PROTO_FRAME_MAX * 2) {
                memmove(buf, buf + 1, n - 1);
                r->len = n - 1;
                return -1;
            }
            total = hdr + len;   /* sn already counts the delimiter    */
            if (PROTO_F_LEVEL >= 4) total += cw;
            if (n < total) return 0;
            if (s->diag) s->diag->length_ok = 1;
            if (PROTO_F_LEVEL >= 4) {
                const uint8_t *cov = PROTO_F4_CRC_PAYLOAD_ONLY
                    ? buf + hdr : buf;
                size_t covn = PROTO_F4_CRC_PAYLOAD_ONLY ? len
                    : hdr + len;
                if (pf_crc(cov, covn, xseed, xpost)
                    != pf_get_crc(buf + hdr + len)) {
                    memmove(buf, buf + total, n - total);
                    r->len = n - total;
                    return -1;
                }
            }
            if (s->diag) s->diag->crc_ok = 1;
            opcode = buf[pf_f3_op_off()];
            blen = pf_cobs_decode(buf + hdr, len, body, sizeof body);
            if (blen == 0 && len > 1) return -1;
            memmove(buf, buf + total, n - total);
            r->len = n - total;
        }
    } else {
        /* F5: one FLAG..FLAG run; multi-fragment reassembly (the flag,
         * escape byte and xor mask are seeded knobs; L>=1 adds a
         * [chan][seq] extension after the opcode in the inner header) */
        size_t start = 0, end;
        uint8_t inner[PROTO_FRAME_MAX];
        size_t il, take;
        size_t cw = PROTO_F4_CRC_W / 8;
        int cext = pf_f3_chan_w() + (PROTO_L_LEVEL >= 1 ? 1 : 0);
        uint8_t re[PROTO_FRAME_MAX];
        size_t rel;
        while (start < n && buf[start] != PROTO_F5_FLAG) start++;
        if (start) { memmove(buf, buf + start, n - start); n -= start; r->len = n; }
        if (n < 2) return 0;
        end = 1;
        while (end < n && buf[end] != PROTO_F5_FLAG) end++;
        if (end >= n) return 0;
        il = pf_unescape(buf + 1, end - 1, inner, sizeof inner);
        memmove(buf, buf + end + 1, n - end - 1);
        r->len = n - end - 1;
        if (s->diag && end > 1) s->diag->boundary = 1;   /* flag pair   */
        if (il < (size_t)(7 + cext + cw)) return -1;
        if (inner[0] != xfm[0] || inner[1] != xfm[1])
            return -1;
        if (s->diag) s->diag->magic = 1;
        take = pf_get16(inner + 4);
        if (take > PROTO_FRAME_MAX) return -1;   /* hostile-length guard */
        if ((size_t)(7 + cext) + take + cw != il) return -1;
        if (s->diag) s->diag->length_ok = 1;
        if (pf_crc(inner, (size_t)(7 + cext) + take, xseed, xpost)
            != pf_get_crc(inner + (size_t)(7 + cext) + take))
            return -1;                          /* chaff */
        if (s->diag) s->diag->crc_ok = 1;
        opcode = inner[6];
        m->chan = 0;
        m->chan_seq = 0;
        if (pf_f3_chan_w()) {
            size_t w;
            for (w = 0; w < (size_t)pf_f3_chan_w(); w++)
                m->chan |= (int)((uint32_t)inner[7 + w] << (8 * w));
            m->chan_seq = inner[7 + pf_f3_chan_w()];
        }
        memcpy(re, inner + 7 + cext, take);
        rel = take;
        if (!(inner[2] & 0x01)) {
            /* intermediate fragment: stash; siblings may already be
             * buffered, so report "consumed, keep extracting"      */
            if (r->frag_len + rel > sizeof r->frag) {
                r->frag_len = 0;
                return -1;
            }
            memcpy(r->frag + r->frag_len, re, rel);
            r->frag_len += rel;
            r->in_frag = 1;
            return 2;
        }
        if (r->in_frag) {
            if (r->frag_len + rel > sizeof body) {
                r->frag_len = 0; r->in_frag = 0;
                return -1;
            }
            memcpy(body, r->frag, r->frag_len);
            memcpy(body + r->frag_len, re, rel);
            blen = r->frag_len + rel;
            r->frag_len = 0;
            r->in_frag = 0;
        } else {
            memcpy(body, re, rel);
            blen = rel;
        }
    }

    /* ---- peel proof, decrypt, unmask, decode ---- */
    {
        size_t off = pf_proof_len();
        uint8_t proof[16];
        if (blen < off) return -1;
        memcpy(proof, body, off);
        {
            size_t n2 = pf_crypt(s, 0, body + off, blen - off);
            if (n2 == (size_t)-1) {
                /* dual-path diagnostic: the tag failed -- if the SAME
                 * bytes decode cleanly as PLAINTEXT the sender has the
                 * grammar but not the crypto (graded as such)      */
                if (s->diag && opcode >= 0) {
                    const proto_schema_t *dsc = ps_schema_for(opcode);
                    proto_msg_t dm;
                    if (dsc && !pe_decode(dsc, body + off, blen - off, &dm))
                        s->diag->dual_plain = 1;
                }
                return -1;
            }
            if (s->diag) s->diag->crypt_ok = 1;
            blen = off + n2;
        }
        if (PROTO_X_LEVEL >= 2 && s->authed) {
            /* L6: mask keys are per-channel; the header (parsed
             * above) names the frame's channel -- borrow it for the
             * mask/unmask so both sides derive the same key       */
            int keep_chan = s->chan;
            if (PROTO_L_LEVEL >= 6 && m->chan != 0)
                s->chan = m->chan;
            px_mask(body + off, blen - off, s);
            s->chan = keep_chan;
        }

        if (opcode < 0 && PROTO_M_LEVEL == 0) {
            /* opcode rides the payload: E0 name token / E>=1 lead byte
             * (with M>=1 this moves below -- the lead is compressed) */
            if (PROTO_E_LEVEL == 0) {
                const proto_schema_t *cand = ps_schema_by_lead(body + off,
                                                               blen - off);
                if (!cand) return -1;
                opcode = cand->opcode;
            } else {
                if (blen - off < 1) return -1;
                opcode = body[off];
            }
        }
        if (s->diag && opcode >= 0) s->diag->opcode_seen = opcode;

        if (off) {
            /* symmetric rule: verify against the zero nonce until
             * this side holds the live nonce (client: after reading
             * HELLO_ACK; server: after answering a valid HELLO)     */
            proto_session_t vs = *s;
            if (!s->nonce_live) memset(vs.nonce, 0, 16);
            if (px_verify(&vs, s->peer_seq + 1, body + off,
                          blen - off, proof) == 0) {
                s->peer_seq++;
                if (s->diag) s->diag->proof_ok = 1;
            } else if (PROTO_S_LEVEL >= 3 && s->peer_seq > 0 &&
                       px_verify(&vs, s->peer_seq, body + off,
                                 blen - off, proof) == 0) {
                /* S3 retransmission tolerance: a duplicate of the last
                 * accepted sequence is re-processed without advancing
                 * the sequence (handlers are idempotent)             */
                if (s->diag) s->diag->proof_ok = 1;
            } else {
                /* one-frame loss tolerance (the robustness contract):
                 * a frame the PEER sent and we dropped (corruption)
                 * still consumed a sequence number on its side. L5
                 * widens the tolerance to a reorder WINDOW (up to +4)
                 * -- frames may arrive interleaved across channels  */
                int win = PROTO_L_LEVEL >= 5 ? 4 : 2, w, hit = 0;
                for (w = 2; w <= win; w++)
                    if (px_verify(&vs, s->peer_seq + (uint64_t)w,
                                  body + off, blen - off,
                                  proof) == 0) {
                        s->peer_seq += (uint64_t)w;
                        if (s->diag) s->diag->proof_ok = 1;
                        hit = 1;
                        break;
                    }
                if (hit) goto proof_done;
                return -1;                     /* replay / forgery */
            }
        proof_done: ;
        } else if (s->diag) {
            s->diag->proof_ok = 1;             /* no proof on this wire */
        }

        /* M: decompress AFTER proof/tag verification (they bind the
         * COMPRESSED bytes, same as the build order) and BEFORE the
         * payload-lead opcode extraction / schema decode            */
        if (PROTO_M_LEVEL >= 1) {
            uint8_t dec[PROTO_FRAME_MAX];
            size_t dn = pm_decompress(body + off, blen - off, dec,
                                      sizeof dec);
            if (dn == (size_t)-1) return -1;
            memcpy(body + off, dec, dn);
            blen = off + dn;
        }

        if (opcode < 0) {
            /* opcode rides the payload: E0 name token / E>=1 lead byte */
            if (PROTO_E_LEVEL == 0) {
                const proto_schema_t *cand = ps_schema_by_lead(body + off,
                                                               blen - off);
                if (!cand) return -1;
                opcode = cand->opcode;
            } else {
                if (blen - off < 1) return -1;
                opcode = body[off];
            }
        }
        if (s->diag) s->diag->opcode_seen = opcode;

        {
            const proto_schema_t *sch = ps_schema_for(opcode);
            if (!sch) return -1;               /* decoy / unknown     */
            if (pe_decode(sch, body + off, blen - off, m)) return -1;
            if (s->diag) s->diag->decode_ok = 1;
            m->opcode = opcode;
            return 1;
        }
    }
    }
}

/* ------------------------------------------------------------------ */
/* stream reader                                                       */
/* ------------------------------------------------------------------ */
int pf_reader_feed(proto_session_t *s, proto_reader_t *r,
                   const uint8_t *data, size_t n, proto_msg_t *out) {
    if (PROTO_T_LEVEL == 4) {
        /* T4: peel complete websocket records off the incoming stream
         * first (partial records stay stashed in r->ws across feeds);
         * the payloads then flow through the normal X3/plain paths.
         * A CLOSE record ends the stream; pings/pongs are skipped --
         * nothing in this engine ever emits them                */
        uint8_t clean[8192];
        size_t clen = 0, off = 0;
        if (r->ws_len + n > sizeof r->ws) r->ws_len = 0;
        if (n > sizeof r->ws) n = sizeof r->ws;
        if (n) memcpy(r->ws + r->ws_len, data, n);
        r->ws_len += n;
        while (off < r->ws_len) {
            size_t avail = r->ws_len - off;
            uint8_t b0 = r->ws[off], b1;
            int masked;
            uint64_t plen;
            size_t hl;
            if (avail < 2) break;
            b1 = r->ws[off + 1];
            masked = (b1 & 0x80) != 0;
            plen = b1 & 0x7F;
            hl = 2;
            if (plen == 126) {
                if (avail < 4) break;
                plen = ((uint64_t)r->ws[off + 2] << 8) | r->ws[off + 3];
                hl = 4;
            } else if (plen == 127) {
                int k;
                if (avail < 10) break;
                plen = 0;
                for (k = 0; k < 8; k++)
                    plen = (plen << 8) | r->ws[off + 2 + k];
                hl = 10;
            }
            if (masked) hl += 4;
            if (plen > sizeof clean) {        /* hostile length        */
                r->ws_len = 0;
                return -1;
            }
            if (avail < hl + (size_t)plen) break;
            if ((b0 & 0x0F) == 0x08) {        /* CLOSE: stream is over */
                r->ws_len = 0;
                return -1;
            }
            if ((b0 & 0x0F) == 0x02) {        /* binary payload        */
                const uint8_t *mk = r->ws + off + hl - (masked ? 4 : 0);
                size_t k;
                if (clen + (size_t)plen > sizeof clean) break;
                memcpy(clean + clen, r->ws + off + hl, (size_t)plen);
                if (masked)
                    for (k = 0; k < (size_t)plen; k++)
                        clean[clen + k] ^= mk[k & 3];
                clen += (size_t)plen;
            }
            off += hl + (size_t)plen;
        }
        memmove(r->ws, r->ws + off, r->ws_len - off);
        r->ws_len -= off;
        data = clean;
        n = clen;
    }
    if (PROTO_X_LEVEL >= 3) {
        /* X3: defragment, strip mimicry, frame-parse -- and KEEP
         * draining the reassembly buffer, because a dropped frame
         * (chaff) must not strand complete frames behind it      */
        int fed_input = 0;
        for (;;) {
            uint8_t chunk[8192];
            size_t clen = 0;
            int complete = 0;
            const uint8_t *d = fed_input ? NULL : data;
            size_t dn = fed_input ? 0 : n;
            fed_input = 1;
            if (px_defrag_feed(r, d, dn, &complete, chunk, &clen))
                return -1;
            if (!complete) return 0;
            if (px_unwrap_mimicry(chunk, &clen)) return -1;
            if (r->len + clen > sizeof r->buf) r->len = 0;
            memcpy(r->buf + r->len, chunk, clen);
            r->len += clen;
            for (;;) {
                int rc = pf_extract_frame(s, r, out);
                if (rc == 1) return 1;
                if (rc == 2) continue;      /* F5 fragment stashed  */
                if (rc == 0) break;         /* need more bytes      */
                if (r->len == 0) break;     /* dropped, drained     */
                continue;  /* dropped (junk prefix / chaff): a resync
                            * walk consumes one byte per call and the
                            * real frame sits behind it -- keep
                            * draining THIS feed, or the peer waits
                            * for a request we never send          */
            }
            /* try to emit the next complete X3 frame               */
        }
    } else {
        if (r->len + n > sizeof r->buf) r->len = 0;
        if (n > sizeof r->buf) n = sizeof r->buf;
        memcpy(r->buf + r->len, data, n);
        r->len += n;
    }

    for (;;) {
        int rc = pf_extract_frame(s, r, out);
        if (rc == 1) return 1;
        if (rc == 2) continue;        /* fragment stashed; keep going */
        if (rc == 0) return 0;
        if (r->len == 0) return 0;    /* dropped; nothing left to try */
    }
}

/* ------------------------------------------------------------------ */
/* writer                                                              */
/* ------------------------------------------------------------------ */
static int pf_write_all(int fd, const uint8_t *buf, size_t n) {
    size_t off = 0;
    while (off < n) {
        ssize_t w = write(fd, buf + off, n - off);
        if (w <= 0) {
            if (w < 0 && errno == EINTR) continue;
            return -1;
        }
        off += (size_t)w;
    }
    return 0;
}

/* construction-time capture tee: when PROTO_CAPTURE names a file, every
 * raw emission appends [u64 ns][u8 dir][u32 len][bytes] (dir 1 = c2s,
 * 2 = s2c). The pipeline runs one oracle+client pair with the tee and
 * merges both records into a sample-session pcap shipped as agent-facing
 * test data. The capture is honest observation material only: the
 * per-connection nonce and flag derivation make recorded bytes
 * structurally unreplayable against a fresh oracle.                 */
static void pf_capture(const proto_session_t *s, const uint8_t *buf,
                       size_t n) {
    static FILE *cap = NULL;
    static int tried = 0;
    struct timespec ts;
    uint8_t hdr[13];
    uint64_t ns;
    if (!tried) {
        const char *p = getenv("PROTO_CAPTURE");
        tried = 1;
        if (p != NULL)
            cap = fopen(p, "ab");
    }
    if (cap == NULL || n == 0)
        return;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    ns = (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
    hdr[0] = (uint8_t)(ns & 0xFF);          /* little-endian ns        */
    hdr[1] = (uint8_t)((ns >> 8) & 0xFF);
    hdr[2] = (uint8_t)((ns >> 16) & 0xFF);
    hdr[3] = (uint8_t)((ns >> 24) & 0xFF);
    hdr[4] = (uint8_t)((ns >> 32) & 0xFF);
    hdr[5] = (uint8_t)((ns >> 40) & 0xFF);
    hdr[6] = (uint8_t)((ns >> 48) & 0xFF);
    hdr[7] = (uint8_t)((ns >> 56) & 0xFF);
    hdr[8] = (uint8_t)(s == NULL ? 0 : (s->is_server ? 2 : 1));
    hdr[9] = (uint8_t)(n & 0xFF);           /* little-endian length    */
    hdr[10] = (uint8_t)((n >> 8) & 0xFF);
    hdr[11] = (uint8_t)((n >> 16) & 0xFF);
    hdr[12] = (uint8_t)((n >> 24) & 0xFF);
    if (fwrite(hdr, 1, sizeof hdr, cap) == sizeof hdr)
        fwrite(buf, 1, n, cap);
    fflush(cap);
}

/* T seam: one raw-emission choke point for all transports. The UDP
 * SERVER routes each datagram at its slot's peer address; the UDP
 * CLIENT holds a CONNECTED socket (its peer is implicit -- a sendto
 * with the zeroed session address would vanish); T4 wraps every
 * emission in one RFC 6455 binary record (client->server masked with
 * a fresh per-record key, server->client plain, exactly the spec's
 * asymmetry -- the reader side unmask mirrors it in pf_reader_feed) */
int pf_send_raw(proto_session_t *s, int fd, const uint8_t *buf, size_t n) {
    if (getenv("PROTO_CAPTURE") != NULL)
        pf_capture(s, buf, n);
    if (PROTO_T_LEVEL == 4) {
        uint8_t out[8192 + 16];
        uint8_t mask[4] = {0, 0, 0, 0};
        int masked = (s != NULL && !s->is_server);
        size_t hl = 0, i;
        if (n + 14 > sizeof out) return -1;
        out[hl++] = 0x82;                    /* FIN | binary opcode   */
        if (masked)
            for (i = 0; i < 4; i++) mask[i] = (uint8_t)prng_next(s);
        if (n < 126) {
            out[hl++] = (uint8_t)((masked ? 0x80 : 0) | n);
        } else if (n < 65536) {
            out[hl++] = (uint8_t)((masked ? 0x80 : 0) | 126);
            out[hl++] = (uint8_t)(n >> 8);
            out[hl++] = (uint8_t)n;
        } else {
            out[hl++] = (uint8_t)((masked ? 0x80 : 0) | 127);
            for (i = 0; i < 8; i++)
                out[hl++] = (uint8_t)(n >> (8 * (7 - i)));
        }
        if (masked) {
            memcpy(out + hl, mask, 4);
            hl += 4;
        }
        memcpy(out + hl, buf, n);
        if (masked)
            for (i = 0; i < n; i++) out[hl + i] ^= mask[i & 3];
        return pf_write_all(fd, out, hl + n);
    }
    if (s != NULL && s->is_udp) {
        if (s->is_server)
            return sendto(fd, buf, n, 0,
                          (const struct sockaddr *)&s->peer,
                          sizeof s->peer) == (ssize_t)n ? 0 : -1;
        return send(fd, buf, n, 0) == (ssize_t)n ? 0 : -1;
    }
    return pf_write_all(fd, buf, n);
}

/* X4: length-bucket padding -- pad the emitted frame to the next
 * power-of-two bucket with a filler that can never begin a frame
 * (rolled-magic[0] ^ 0xFF). The reader's resync walk consumes the
 * tail; a length analysis of a capture now sees buckets only.    */
static size_t pf_pad_bucket(const proto_session_t *s, uint8_t *buf,
                            size_t n, size_t cap) {
    static const size_t buckets[] = {64, 128, 256, 512, 1024};
    size_t target = 0, i;
    uint8_t fm[4];
    uint32_t cs, cp;
    if (PROTO_X_LEVEL < 4) return n;
    for (i = 0; i < sizeof buckets / sizeof buckets[0]; i++)
        if (buckets[i] >= n) { target = buckets[i]; break; }
    if (target == 0 || target > cap) return n;
    px_frame_material(s, fm, &cs, &cp);
    {   uint8_t filler = (uint8_t)(fm[0] ^ 0xFF);
        for (i = n; i < target; i++) buf[i] = filler;
    }
    return target;
}

/* X5: emission jitter -- a seeded 0-50ms hesitation in front of every
 * server write. Length side channels need frame boundaries AND the
 * emission rhythm; this fuzzes the rhythm.                       */
static void pf_jitter(proto_session_t *s) {
    if (PROTO_X_LEVEL < 5 || !s->is_server) return;
    {
        struct timespec ts = {0,
            (long)(prng_next(s) % 50000) * 1000};   /* 0-50 ms   */
        nanosleep(&ts, NULL);
    }
}

int pf_write_msg(proto_session_t *s, int fd, const proto_msg_t *m) {
    uint8_t wire[8192];
    size_t n;
    int b = pf_build(s, m, wire, sizeof wire);
    if (b <= 0) return -1;
    n = (size_t)b;
    s->my_seq++;
    pf_jitter(s);
    n = pf_pad_bucket(s, wire, n, sizeof wire);
    if (proto_chaos_mode() != PROTO_CHAOS_NONE && s->is_server)
        return px_chaos_wire(s, fd, wire, n);
    if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1;
    if (PROTO_X_LEVEL >= 3)
        return px_frag_write(s, fd, wire, n);
    return pf_send_raw(s, fd, wire, n);
}

/* L: write one frame on a DIFFERENT channel than the session's write
 * channel (the server's background interleave). The per-channel
 * sequence table is shared with the normal writer, so sequences on
 * every channel stay monotonic.                                      */
int pf_write_msg_chan(proto_session_t *s, int fd, const proto_msg_t *m,
                      int chan) {
    int keep = s->chan;
    int rc;
    s->chan = chan;
    rc = pf_write_msg(s, fd, m);
    s->chan = keep;
    return rc;
}
