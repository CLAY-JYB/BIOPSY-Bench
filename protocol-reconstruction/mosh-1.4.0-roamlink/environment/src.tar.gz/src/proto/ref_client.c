/* ref_client.c -- reference client driver (ground-truth solve side).
 *
 * Built together with protocol.c; uses the same engine the challenge
 * binary embeds. Modes:
 *   ref_client HOST PORT              full session, print session flag
 *   ref_client HOST PORT --converse N perform N round trips, print
 *                                     "CONVERSE N"
 *   ref_client HOST PORT --parallel N drive N concurrent full sessions
 *                                     in one process (in-process state
 *                                     isolation; the C10 contract),
 *                                     print each flag
 *
 * The client contract the verifier drives (instruction.md): the
 * deliverable is an executable named `client` invoked as
 * `client HOST PORT [--parallel N]` -- this driver implements it.
 */

#define _GNU_SOURCE
#include "proto_config.h"
#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>

typedef struct {
    const char *host;
    int port;
    int ok;
} par_arg_t;

static void *par_thread(void *vp) {
    par_arg_t *a = vp;
    char flag[PROTO_STR_MAX];
    int rc = proto_client_session(a->host, a->port, flag,
                                  sizeof flag);
    if (rc == 0)
        printf("%s\n", flag);
    else
        fprintf(stderr, "parallel session failed\n");
    a->ok = (rc == 0);
    return NULL;
}

int main(int argc, char **argv) {
    const char *host;
    int port;

    /* reconnect logic writes into sockets a faulted server may have
     * dropped already -- EPIPE is an error to handle, not a kill    */
    signal(SIGPIPE, SIG_IGN);

    if (argc < 3) {
        fprintf(stderr, "usage: %s HOST PORT [--converse N | "
                        "--parallel N]\n", argv[0]);
        return 2;
    }
    host = argv[1];
    port = atoi(argv[2]);
    if (argc >= 5 && !strcmp(argv[3], "--converse")) {
        int rounds = atoi(argv[4]);
        int done = proto_client_converse(host, port, rounds);
        printf("CONVERSE %d\n", done);
        return done == rounds ? 0 : 1;
    }
    if (argc >= 5 && !strcmp(argv[3], "--parallel")) {
        int n = atoi(argv[4]);
        int i, ok = 1;
        pthread_t th[64];
        par_arg_t args[64];
        if (n < 1 || n > 64) {
            fprintf(stderr, "parallel: 1..64\n");
            return 2;
        }
        for (i = 0; i < n; i++) {
            args[i].host = host;
            args[i].port = port;
            args[i].ok = 0;
            if (pthread_create(&th[i], NULL, par_thread, &args[i])
                != 0) {
                fprintf(stderr, "parallel: thread spawn failed\n");
                return 1;
            }
        }
        for (i = 0; i < n; i++)
            pthread_join(th[i], NULL);
        for (i = 0; i < n; i++) ok &= args[i].ok;
        fflush(stdout);
        return ok ? 0 : 1;
    }
    {
        char flag[PROTO_STR_MAX];
        int rc = proto_client_session(host, port, flag, sizeof flag);
        if (rc != 0) {
            fprintf(stderr, "session failed\n");
            return 1;
        }
        printf("%s\n", flag);
        return 0;
    }
}
