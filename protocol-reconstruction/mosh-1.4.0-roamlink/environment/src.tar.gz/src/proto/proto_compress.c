/* proto_compress.c -- compression axis (M).
 *
 * Static asset, level-switched via proto_config.h:
 *   M0  none
 *   M1  run-length encoding        (seeded marker byte + run cap)
 *   M2  raw DEFLATE (RFC 1951, stored + fixed-Huffman blocks; the
 *       compressor never emits dynamic blocks, so the matching
 *       inflater is exactly as expressive as the wire needs)
 *   M3  LZSS with a seeded preset dictionary
 *
 * Pipeline position: E -> M -> X1-proof -> X2-mask -> C (compress-
 * then-encrypt, the TLS-era convention). The transform is stateless
 * per message and every output starts with one control byte:
 *   0x00 = raw passthrough (incompressible guard)
 *   0x01 = compressed stream follows
 *
 * Public-primitive rule: every algorithm here is a published spec
 * implemented in-tree (no external dependency), same as the crypto
 * module. Knob domains are seeded by gen_protocol.py (parameters.md).
 */

#include <string.h>

/* ------------------------------------------------------------------ */
/* public entry points                                                 */
/* ------------------------------------------------------------------ */
/* Returns the transformed length, or (size_t)-1 on overflow. out and
 * in may not overlap. */
size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap);
/* Returns the original length, or (size_t)-1 if out overflows / the
 * stream is malformed. */
size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap);

#if PROTO_M_LEVEL == 0

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    (void)in; (void)n; (void)out; (void)cap;
    return 0;                                   /* never called at M0 */
}
size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    (void)in; (void)n; (void)out; (void)cap;
    return 0;
}

#elif PROTO_M_LEVEL == 1
/* ------------------------------------------------------------------ */
/* M1: run-length encoding                                             */
/* ------------------------------------------------------------------ */
/* stream (after the 0x01 control byte): literals copy straight through;
 * a run of >= 4 equal bytes is [marker][count][byte]; a literal that
 * equals the marker is emitted as the degenerate run [marker][1][b].  */

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 0, o = 1;
    if (cap < 1) return (size_t)-1;
    out[0] = 0x01;
    while (i < n) {
        size_t run = 1;
        while (i + run < n && in[i + run] == in[i]
               && run < (size_t)PROTO_M1_MAXRUN)
            run++;
        if (run >= 4 || in[i] == PROTO_M1_MARKER) {
            if (o + 3 > cap) return (size_t)-1;
            out[o++] = PROTO_M1_MARKER;
            out[o++] = (uint8_t)run;
            out[o++] = in[i];
            i += run;
        } else {
            if (o + run > cap) return (size_t)-1;
            memcpy(out + o, in + i, run);
            o += run;
            i += run;
        }
    }
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 1, o = 0;
    if (n < 1 || in[0] != 0x01) return (size_t)-1;
    while (i < n) {
        if (in[i] == PROTO_M1_MARKER) {
            size_t run;
            if (i + 3 > n) return (size_t)-1;
            run = in[i + 1];
            if (o + run > cap) return (size_t)-1;
            memset(out + o, in[i + 2], run);
            o += run;
            i += 3;
        } else {
            if (o + 1 > cap) return (size_t)-1;
            out[o++] = in[i++];
        }
    }
    return o;
}

#elif PROTO_M_LEVEL == 3
/* ------------------------------------------------------------------ */
/* M3: LZSS with seeded preset dictionary                              */
/* ------------------------------------------------------------------ */
/* stream: a flag byte precedes every group of 8 items; flag bit 1 =
 * 16-bit match token [dist:WPB | len-MINM], bit 0 = literal byte. The
 * history is the seeded dictionary (a proto_config.h constant, so it
 * is challenge-recoverable material) followed by the payload prefix;
 * distances are capped by the window knob.                         */

#define M3_WIN   PROTO_M3_WINDOW
#define M3_WPB   (M3_WIN == 4096 ? 12 : 11)
#define M3_LBITS (16 - M3_WPB)
#define M3_MINM  3
#define M3_MAXM  (PROTO_M3_MAXMATCH < (1 << M3_LBITS) + M3_MINM \
                  ? PROTO_M3_MAXMATCH : (1 << M3_LBITS) + M3_MINM - 1)

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    /* one combined history buffer: dict || input; matches are plain
     * absolute-position lookups -- no ring, no cross-boundary cases  */
    uint8_t hbuf[PROTO_M3_DICTLEN + PROTO_FRAME_MAX];
    size_t hd = (size_t)PROTO_M3_DICTLEN, hn = hd + n;
    size_t i, o = 1, flag_at = 0;
    int bit = 0;
    if (cap < 1) return (size_t)-1;
    out[0] = 0x01;
    if (hd) memcpy(hbuf, PROTO_M3_DICT, hd);
    if (n) memcpy(hbuf + hd, in, n);
    i = hd;
    while (i < hn) {
        size_t lo = i > M3_WIN ? i - M3_WIN : 0;
        size_t best_len = 0, best_dist = 0, j;
        for (j = i - 1; ; j--) {
            size_t l = 0;
            while (l < (size_t)M3_MAXM && i + l < hn
                   && hbuf[j + l] == hbuf[i + l])
                l++;
            if (l > best_len) { best_len = l; best_dist = i - j; }
            if (j == lo || best_len >= (size_t)M3_MAXM) break;
        }
        if (o + 3 > cap) return (size_t)-1;
        if (bit == 0) {
            flag_at = o;
            out[o++] = 0;
        }
        if (best_len >= M3_MINM) {
            uint16_t tok = (uint16_t)(((best_dist - 1) << M3_LBITS)
                                      | (best_len - M3_MINM));
            out[flag_at] |= (uint8_t)(1 << bit);
            out[o++] = (uint8_t)(tok >> 8);
            out[o++] = (uint8_t)tok;
            i += best_len;
        } else {
            out[o++] = hbuf[i];
            i++;
        }
        bit = (bit + 1) & 7;
    }
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t hd = (size_t)PROTO_M3_DICTLEN, i = 1, o = 0;
    int flags = 0, bit = 0;
    if (n < 1 || (in[0] != 0x01 && in[0] != 0x00)) return (size_t)-1;
    if (in[0] == 0x00) {
        if (n - 1 > cap) return (size_t)-1;
        memcpy(out, in + 1, n - 1);
        return n - 1;
    }
    while (i < n) {
        if (bit == 0) {
            if (i + 1 > n) break;
            flags = in[i++];
        }
        if (flags & (1 << bit)) {
            size_t dist, len, k;
            uint16_t tok;
            if (i + 2 > n) return (size_t)-1;
            tok = (uint16_t)((in[i] << 8) | in[i + 1]);
            i += 2;
            dist = (tok >> M3_LBITS) + 1;
            len = (tok & ((1u << M3_LBITS) - 1)) + M3_MINM;
            if (dist > o + hd) return (size_t)-1;
            if (o + len > cap) return (size_t)-1;
            for (k = 0; k < len; k++, o++) {
                out[o] = dist <= o ? out[o - dist]
                                   : PROTO_M3_DICT[hd - (dist - o)];
            }
        } else {
            if (i + 1 > n) return (size_t)-1;
            if (o + 1 > cap) return (size_t)-1;
            out[o++] = in[i++];
        }
        bit = (bit + 1) & 7;
    }
    return o;
}

#elif PROTO_M_LEVEL == 4
/* ------------------------------------------------------------------ */
/* M4: canonical Huffman with a SEEDED static table. The generator     */
/* emits per-byte code lengths (biased, deterministic); codes are      */
/* canonical, so both sides derive the codes from lengths alone.       */
/* ------------------------------------------------------------------ */
typedef struct { uint32_t code; int len; } m4_ent;
static m4_ent m4_table[256];
static int m4_ready = 0;

static void m4_init(void) {
    /* canonical code assignment: sort by (len, byte) */
    int len, b, code = 0, counts[64];
    memset(counts, 0, sizeof counts);
    for (b = 0; b < 256; b++) counts[PROTO_M4_LENS[b]]++;
    /* first_code[len] via the canonical algorithm */
    {   int next = 0;
        uint32_t first[64];
        memset(first, 0, sizeof first);
        for (len = 1; len < 64; len++) {
            first[len] = (uint32_t)next;
            next = ((next + counts[len]) << 1);
        }
        for (b = 0; b < 256; b++) {
            m4_table[b].len = PROTO_M4_LENS[b];
            m4_table[b].code = first[PROTO_M4_LENS[b]]++;
        }
    }
    m4_ready = 1;
}

static void m4_put(uint8_t *out, size_t *o, int *bitp,
                   uint32_t code, int len) {
    int i;
    for (i = len - 1; i >= 0; i--) {   /* MSB-first canonical codes */
        if (*bitp == 0) out[*o] = 0;
        out[*o] |= (uint8_t)(((code >> i) & 1) << (7 - *bitp));
        if (++(*bitp) == 8) { *bitp = 0; (*o)++; }
    }
}

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i, o = 1;
    int bitp = 0;
    if (cap < 1) return (size_t)-1;
    if (!m4_ready) m4_init();
    out[0] = 0x01;
    {   /* the final byte carries pad bits that would decode as a
         * spurious symbol; the original length rides the header   */
        size_t v = n;
        do { if (o >= cap) return (size_t)-1;
             out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7; } while (v);
        out[o - 1] &= 0x7F;
    }
    for (i = 0; i < n; i++)
        m4_put(out, &o, &bitp, m4_table[in[i]].code,
               m4_table[in[i]].len);
    if (bitp) o++;
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 1, o = 0, want = 0, shift = 0;
    int bitp = 0;
    if (n < 1 || in[0] != 0x01) return (size_t)-1;
    if (!m4_ready) m4_init();
    while (i < n) {
        uint8_t byte = in[i++];
        want |= (size_t)(byte & 0x7F) << shift;
        shift += 7;
        if (!(byte & 0x80)) break;
    }
    if (want > cap) return (size_t)-1;
    while (o < want) {
        int len;
        uint32_t code = 0;
        int b;
        for (len = 1; len < 64; len++) {
            if (i >= n && bitp == 0) return (size_t)-1;
            code = (code << 1) | ((in[i] >> (7 - bitp)) & 1);
            if (++bitp == 8) { bitp = 0; i++; }
            for (b = 0; b < 256; b++)
                if (m4_table[b].len == len
                    && m4_table[b].code == code) {
                    out[o++] = (uint8_t)b;
                    goto next_sym;
                }
        }
        return (size_t)-1;
    next_sym:;
    }
    return o;
}

#elif PROTO_M_LEVEL == 5
/* ------------------------------------------------------------------ */
/* M5: LZ77 with varint tokens -- flag byte per 8 items; matches are   */
/* (distance, length) varints over the plain history window.          */
/* ------------------------------------------------------------------ */
size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 0, o = 1;
    if (cap < 1) return (size_t)-1;
    out[0] = 0x01;
    while (i < n) {
        size_t flag_at, fbit = 0;
        size_t run_start = o;
        if (o + 1 >= cap) return (size_t)-1;
        flag_at = o++;
        out[flag_at] = 0;
        while (fbit < 8 && i < n) {
            size_t best_len = 0, best_dist = 0, j;
            for (j = i >= 4096 ? i - 4096 : 0; j < i; j++) {
                size_t l = 0;
                while (l < 255 && i + l < n && in[j + l] == in[i + l])
                    l++;
                if (l > best_len) { best_len = l; best_dist = i - j; }
            }
            if (best_len >= 4 && o + 4 < cap) {
                /* varint dist, then varint len */
                size_t v = best_dist;
                out[flag_at] |= (uint8_t)(1 << fbit);
                do { out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7; }
                while (v);
                out[o - 1] &= 0x7F;
                v = best_len;
                do { out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7; }
                while (v);
                out[o - 1] &= 0x7F;
                i += best_len;
            } else if (o + 1 < cap) {
                out[o++] = in[i++];
            } else {
                return (size_t)-1;
            }
            fbit++;
        }
    }
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 1, o = 0;
    if (n < 1 || in[0] != 0x01) return (size_t)-1;
    while (i < n) {
        size_t flag = in[i++], b;
        for (b = 0; b < 8 && i < n; b++) {
            if (flag & (1u << b)) {
                size_t dist = 0, len = 0, shift = 0, k;
                while (i < n) {
                    uint8_t byte = in[i++];
                    dist |= (size_t)(byte & 0x7F) << shift;
                    shift += 7;
                    if (!(byte & 0x80)) break;
                }
                shift = 0;
                while (i < n) {
                    uint8_t byte = in[i++];
                    len |= (size_t)(byte & 0x7F) << shift;
                    shift += 7;
                    if (!(byte & 0x80)) break;
                }
                if (dist > o || len == 0 || o + len > cap)
                    return (size_t)-1;
                for (k = 0; k < len; k++, o++)
                    out[o] = out[o - dist];
            } else {
                if (o + 1 > cap) return (size_t)-1;
                out[o++] = in[i++];
            }
        }
    }
    return o;
}

#elif PROTO_M_LEVEL == 6
/* ------------------------------------------------------------------ */
/* M6: carryless range coder (Subbotin shape). Deterministic, no      */
/* table; the decoder consumes exactly the encoder's arithmetic.       */
/* ------------------------------------------------------------------ */
#define M6_TOP   (1u << 24)
#define M6_BOT   (1u << 16)

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    uint32_t low = 0, range = 0xFFFFFFFFu;
    size_t i, o = 1;
    if (cap < 1) return (size_t)-1;
    out[0] = 0x01;
    {   /* the range stream is not self-terminating: the original
         * length rides the stream header as a varint            */
        size_t v = n;
        do { if (o >= cap) return (size_t)-1;
             out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7; } while (v);
        out[o - 1] &= 0x7F;
    }
    for (i = 0; i < n; i++) {
        uint32_t r = range >> 8;
        low += r * in[i];
        range = r;
        /* classic Subbotin normalization: carry-agreement or under-
         * flow; the second branch CLAMPS range to the boundary so
         * the loop always terminates                        */
        for (;;) {
            if ((low ^ (low + range)) < M6_TOP) {
                /* top bits agree: shift out              */
            } else if (range < M6_BOT) {
                range = (uint32_t)((-(int32_t)low)
                                   & (int32_t)(M6_BOT - 1));
            } else {
                break;
            }
            if (o >= cap) return (size_t)-1;
            out[o++] = (uint8_t)(low >> 24);
            low <<= 8;
            range <<= 8;
        }
    }
    for (i = 0; i < 4; i++) {
        if (o >= cap) return (size_t)-1;
        out[o++] = (uint8_t)(low >> 24);
        low <<= 8;
    }
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    /* mirrors the encoder EXACTLY: low and range track the encoder's
     * state, code rides (absolute - low); the normalization loop is
     * the same clamp-and-shift, with bytes fed INTO code          */
    uint32_t low = 0, code = 0, range = 0xFFFFFFFFu;
    size_t i = 1, o = 0, k, want = 0, shift = 0;
    if (n < 5 || in[0] != 0x01) return (size_t)-1;
    while (i < n) {
        uint8_t byte = in[i++];
        want |= (size_t)(byte & 0x7F) << shift;
        shift += 7;
        if (!(byte & 0x80)) break;
    }
    if (want > cap) return (size_t)-1;
    for (k = 0; k < 4; k++) {
        if (i >= n) return (size_t)-1;
        code = (code << 8) | in[i++];
    }
    while (o < want) {
        uint32_t r, sym;
        for (;;) {
            if ((low ^ (low + range)) < M6_TOP) {
            } else if (range < M6_BOT) {
                range = (uint32_t)((-(int32_t)low)
                                   & (int32_t)(M6_BOT - 1));
            } else {
                break;
            }
            code <<= 8;
            if (i < n) code |= in[i++];
            low <<= 8;
            range <<= 8;
        }
        r = range >> 8;
        sym = code / r;
        if (sym > 255) sym = 255;
        code -= r * sym;
        low += r * sym;
        range = r;
        out[o++] = (uint8_t)sym;
    }
    return o;
}

#elif PROTO_M_LEVEL == 7
/* ------------------------------------------------------------------ */
/* M7: LZSS matches + canonical-Huffman literals (the full DEFLATE
 * shape, static table like M4): literals/match-len symbols are
 * Huffman-coded; distances and lengths ride varints.              */
/* ------------------------------------------------------------------ */
typedef struct { uint32_t code; int len; } m7_ent;
static m7_ent m7_table[256];
static int m7_ready = 0;

static void m7_init(void) {
    int len, b, next = 0, counts[64];
    uint32_t first[64];
    memset(counts, 0, sizeof counts);
    for (b = 0; b < 256; b++) counts[PROTO_M4_LENS[b]]++;
    memset(first, 0, sizeof first);
    for (len = 1; len < 64; len++) {
        first[len] = (uint32_t)next;
        next = (next + counts[len]) << 1;
    }
    for (b = 0; b < 256; b++) {
        m7_table[b].len = PROTO_M4_LENS[b];
        m7_table[b].code = first[PROTO_M4_LENS[b]]++;
    }
    m7_ready = 1;
}

static void m7_put(uint8_t *out, size_t *o, int *bitp,
                   uint32_t code, int len) {
    int i;
    for (i = len - 1; i >= 0; i--) {
        if (*bitp == 0) out[*o] = 0;
        out[*o] |= (uint8_t)(((code >> i) & 1) << (7 - *bitp));
        if (++(*bitp) == 8) { *bitp = 0; (*o)++; }
    }
}

static int m7_get(const uint8_t *in, size_t n, size_t *i, int *bitp) {
    int len = 1;
    uint32_t code = 0, b;
    for (len = 1; len < 64; len++) {
        if (*i >= n) return -1;
        code = (code << 1) | ((in[*i] >> (7 - *bitp)) & 1);
        if (++(*bitp) == 8) { *bitp = 0; (*i)++; }
        for (b = 0; b < 256; b++)
            if (m7_table[b].len == len && m7_table[b].code == code)
                return (int)b;
    }
    return -1;
}

/* after a match marker: dist = 12 raw bits, len = 8 raw bits (MSB
 * first) -- raw bits, not Huffman, so no digit/marker ambiguity    */
static void m7_put_raw(uint8_t *out, size_t *o, int *bitp,
                       uint32_t v, int nbits) {
    int i;
    for (i = nbits - 1; i >= 0; i--) {
        if (*bitp == 0) out[*o] = 0;
        out[*o] |= (uint8_t)(((v >> i) & 1) << (7 - *bitp));
        if (++(*bitp) == 8) { *bitp = 0; (*o)++; }
    }
}

static uint32_t m7_get_raw(const uint8_t *in, size_t n, size_t *i,
                          int *bitp, int nbits) {
    uint32_t v = 0;
    int k;
    for (k = 0; k < nbits; k++) {
        if (*i >= n) return 0xFFFFFFFFu;
        v = (v << 1) | ((in[*i] >> (7 - *bitp)) & 1);
        if (++(*bitp) == 8) { *bitp = 0; (*i)++; }
    }
    return v;
}

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 0, o = 1;
    int bitp = 0;
    if (cap < 1) return (size_t)-1;
    if (!m7_ready) m7_init();
    out[0] = 0x01;
    {   size_t v = n;
        do { if (o >= cap) return (size_t)-1;
             out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7; } while (v);
        out[o - 1] &= 0x7F;
    }
    while (i < n) {
        size_t best_len = 0, best_dist = 0, j;
        for (j = i >= 4096 ? i - 4096 : 0; j < i; j++) {
            size_t l = 0;
            while (l < 255 && i + l < n && in[j + l] == in[i + l]) l++;
            if (l > best_len) { best_len = l; best_dist = i - j; }
        }
        if (best_len >= 4 && best_dist <= 0xFFF
            && best_len <= 0xFF) {
            m7_put(out, &o, &bitp, m7_table[0x00].code,
                   m7_table[0x00].len);        /* 0x00 = match marker */
            m7_put_raw(out, &o, &bitp, (uint32_t)best_dist, 12);
            m7_put_raw(out, &o, &bitp, (uint32_t)best_len, 8);
            i += best_len;
        } else {
            {   /* literals ride their own symbol; 0x00/0x01 escape
                 * through the 0x01 prefix (0x01 0x00 / 0x01 0x01)  */
                uint8_t b = in[i];
                if (b <= 0x01) {
                    m7_put(out, &o, &bitp, m7_table[0x01].code,
                           m7_table[0x01].len);
                    m7_put(out, &o, &bitp, m7_table[b].code,
                           m7_table[b].len);
                } else {
                    m7_put(out, &o, &bitp, m7_table[b].code,
                           m7_table[b].len);
                }
            }
            i++;
        }
    }
    if (bitp) o++;
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out, size_t cap) {
    size_t i = 1, o = 0, want = 0, shift = 0;
    int bitp = 0;
    if (n < 1 || in[0] != 0x01) return (size_t)-1;
    if (!m7_ready) m7_init();
    while (i < n) {
        uint8_t byte = in[i++];
        want |= (size_t)(byte & 0x7F) << shift;
        shift += 7;
        if (!(byte & 0x80)) break;
    }
    if (want > cap) return (size_t)-1;
    while (o < want) {
        int sym = m7_get(in, n, &i, &bitp);
        if (sym < 0) return (size_t)-1;
        if (sym == 0x00) {
            size_t dist, len, k;
            dist = m7_get_raw(in, n, &i, &bitp, 12);
            len = m7_get_raw(in, n, &i, &bitp, 8);
            if (dist == 0xFFFFFFFFu || len == 0xFFFFFFFFu)
                return (size_t)-1;
            if (dist > o || len == 0 || o + len > cap)
                return (size_t)-1;
            for (k = 0; k < len; k++, o++)
                out[o] = out[o - dist];
        } else if (sym == 0x01) {
            int lit = m7_get(in, n, &i, &bitp);
            if (lit < 0) return (size_t)-1;
            out[o++] = (uint8_t)lit;          /* escaped 0x00/0x01 */
        } else {
            out[o++] = (uint8_t)sym;
        }
    }
    return o;
}

#else
/* ------------------------------------------------------------------ */
/* M2: byte-aligned escape LZ (private shape). One seeded escape byte
 * leads every back-reference token (two-byte distance, one-byte
 * length); a literal equal to the escape byte is written twice. The
 * original length rides the header as a varint (self-terminating --
 * trailing pad bytes can never decode as spurious symbols). No
 * published-format tables or bit conventions ride along: the escape
 * byte, its distance byte order, the window and the minimum match
 * are all per-task seed material. The escape byte is >= 0x80 and the
 * window <= 0x7FFF, so a distance byte can never equal the escape
 * and the token/literal distinction is unambiguous by position.   */
/* ------------------------------------------------------------------ */

size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out,
                   size_t cap) {
    size_t i = 0, o = 1, v = n;
    const size_t win = (size_t)PROTO_M2_WIN;
    const size_t minm = (size_t)PROTO_M2_MINM;
    if (cap < 1) return (size_t)-1;
    if (2 + 2 * n + 1 > cap) {      /* worst case (all literals + all
                                     * escaped) cannot fit: raw      */
        if (1 + n > cap) return (size_t)-1;
        out[0] = 0x00;
        memcpy(out + 1, in, n);
        return 1 + n;
    }
    out[0] = 0x01;
    do {                            /* varint original length        */
        if (o >= cap) return (size_t)-1;
        out[o++] = (uint8_t)((v & 0x7F) | 0x80); v >>= 7;
    } while (v);
    out[o - 1] &= 0x7F;
    while (i < n) {
        size_t best_len = 0, best_dist = 0, j;
        size_t lo = i > win ? i - win : 0;
        for (j = i - 1; j + 1 > lo + 1 && j != (size_t)-1; j--) {
            size_t l = 0;
            while (l < 255 && i + l < n && in[j + l] == in[i + l])
                l++;
            if (l > best_len) { best_len = l; best_dist = i - j; }
            if (j == lo) break;
        }
        if (best_len >= minm && best_len >= 5
            && best_dist <= 0x7FFF) {
            if (o + 4 > cap) return (size_t)-1;
            out[o++] = (uint8_t)PROTO_M2_ESCAPE;
            if (PROTO_M2_DLE) {
                out[o++] = (uint8_t)(best_dist & 0xFF);
                out[o++] = (uint8_t)(best_dist >> 8);
            } else {
                out[o++] = (uint8_t)(best_dist >> 8);
                out[o++] = (uint8_t)(best_dist & 0xFF);
            }
            out[o++] = (uint8_t)best_len;
            i += best_len;
        } else {
            if (o + 2 > cap) return (size_t)-1;
            out[o++] = in[i];
            if (in[i] == (uint8_t)PROTO_M2_ESCAPE)
                out[o++] = (uint8_t)PROTO_M2_ESCAPE;   /* escaped   */
            i++;
        }
    }
    return o;
}

size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out,
                     size_t cap) {
    size_t i = 1, o = 0, want = 0, shift = 0;
    if (n < 1 || (in[0] != 0x01 && in[0] != 0x00)) return (size_t)-1;
    if (in[0] == 0x00) {                       /* raw passthrough */
        if (n - 1 > cap) return (size_t)-1;
        memcpy(out, in + 1, n - 1);
        return n - 1;
    }
    while (i < n) {                            /* varint length    */
        uint8_t byte = in[i++];
        want |= (size_t)(byte & 0x7F) << shift;
        shift += 7;
        if (!(byte & 0x80)) break;
    }
    if (want > cap) return (size_t)-1;
    while (o < want) {
        uint8_t b = in[i++];
        if (b == (uint8_t)PROTO_M2_ESCAPE) {
            if (i >= n) return (size_t)-1;
            if (in[i] == (uint8_t)PROTO_M2_ESCAPE) {
                out[o++] = (uint8_t)PROTO_M2_ESCAPE;  /* literal */
                i++;
                continue;
            }
            {   size_t dist, len, k;
                if (i + 3 > n) return (size_t)-1;
                dist = PROTO_M2_DLE
                    ? (size_t)in[i] | ((size_t)in[i + 1] << 8)
                    : ((size_t)in[i] << 8) | (size_t)in[i + 1];
                len = in[i + 2];
                i += 3;
                if (dist == 0 || dist > o || len == 0)
                    return (size_t)-1;
                if (o + len > want) return (size_t)-1;
                for (k = 0; k < len; k++, o++)
                    out[o] = out[o - dist];
            }
        } else {
            if (i > n) return (size_t)-1;
            out[o++] = b;
        }
    }
    return o;
}
#endif
