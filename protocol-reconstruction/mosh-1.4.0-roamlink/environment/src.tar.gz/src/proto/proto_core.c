/* proto_core.c -- session engine: server loop, handlers and the
 * hidden carrier entry (SERVER side only).
 *
 * Static asset, level-switched via proto_config.h. Field-slot order
 * per message is canonical (see gen_protocol.py schema model):
 *   HELLO       ints: [0]=proto_ver [1]=client_caps
 *   HELLO_ACK   ints: [0]=server_ver [1]=session_id(S>=2)
 *               blobs: [2]=nonce16(X>=1) [3]=server_pub32(C3)
 *   PARAMS      ints: [0]=window [1]=mss
 *   PARAMS_ACK  ints: [0]=rwindow [1]=token
 *   AUTH        blobs: [0]=mac16 | [0]=pub32 [1]=mac16 (C3)
 *   AUTH_OK     ints: [0]=status  blobs: [1]=confirm8 (C3)
 *   GET         strs: [0]=key
 *   VAL         strs: [0]=key  ints: [1]=value
 *   SET         strs: [0]=key  ints: [1]=value
 *   OK          ints: [0]=status
 *   SUM         ints: [0]=a [1]=b
 *   SUM_RES     ints: [0]=sum
 *   FLAG        ints: [0]=token (S>=2)
 *   FLAG_RES    strs: [0]=flag
 *   ERR         ints: [0]=code
 *   BYE         ints: [0]=reason
 *   BYE_ACK     ints: [0]=code
 *   PING/PONG   ints: [0]=seq/echo          (X2 decoys)
 *   STAT/STAT_RES ints: [0]=id / strs[0]    (X2 decoys)
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <time.h>

/* ------------------------------------------------------------------ */
/* engine-internal literals (decoded via px_strdec, proto_conceal.c)   */
/* ------------------------------------------------------------------ */
/* Entry flag, milestone env names, milestone tags and auth labels are
 * stored XOR-encoded: no plaintext "--proto-server" / "PROTO_MILESTONE_*
 * " rides in .rodata, so `strings` does not hand over the hidden
 * mode. None of these is seeded ground truth -- the encoding only
 * removes the free fingerprint.                                      */
static const uint8_t LIT_MODE[14] = {0xbc, 0x0c, 0x15, 0xe7, 0x35, 0x41, 0xac, 0xfd, 0xec, 0x80, 0x5a, 0x00, 0xea, 0x3d};
static const uint8_t LIT_MSLOG[19] = {0xc1, 0x73, 0x2a, 0xc1, 0x15, 0x6a, 0x8e, 0x99, 0xd3, 0xa0, 0x7b, 0x22, 0xc0, 0x01, 0x6b, 0x89, 0x0d, 0x9e, 0x12};
static const uint8_t LIT_MSSECRET[22] = {0xc1, 0x73, 0x2a, 0xc1, 0x15, 0x6a, 0x8e, 0x99, 0xd3, 0xa0, 0x7b, 0x22, 0xc0, 0x01, 0x6b, 0x89, 0x12, 0x94, 0x16, 0xb7, 0x2f, 0x91};
static const uint8_t LIT_TAG_HELLO[8] = {0xf9, 0x44, 0x09, 0xf9, 0x35, 0x6a, 0xac, 0xbb};
static const uint8_t LIT_TAG_AUTH[7] = {0xf0, 0x54, 0x11, 0xfd, 0x05, 0x5a, 0xa8};
static const uint8_t LIT_TAG_ROUND[5] = {0xe3, 0x4e, 0x10, 0xfb, 0x3e};
static const uint8_t LIT_TAG_FLAG[9] = {0xf7, 0x4d, 0x04, 0xf2, 0x05, 0x46, 0xa6, 0xbe, 0xeb};
static const uint8_t LIT_FLAGTOK[7] = {0xf7, 0x4d, 0x04, 0xf2, 0x2e, 0x5a, 0xa8};
static const uint8_t LIT_CONFIRM[7] = {0xf2, 0x4e, 0x0b, 0xf3, 0x33, 0x47, 0xae};
static const uint8_t LIT_STATFMT[19] = {0xf9, 0x44, 0x04, 0xe5, 0x67, 0x10, 0xaf, 0xbc, 0xea, 0xde, 0x5c, 0x1e, 0xfd, 0x2a, 0x4f, 0xb2, 0x32, 0xec, 0x61};
static const uint8_t LIT_MSFMT[6] = {0xb4, 0x52, 0x45, 0xb0, 0x29, 0x3f};
static const uint8_t LIT_CHAOS[7] = {0xbc, 0x0c, 0x06, 0xfd, 0x3b, 0x5a, 0xb0};

/* ------------------------------------------------------------------ */
/* per-connection RNG (xorshift64*) -- response values randomized per
 * run so recorded sessions can never be replayed for score            */
/* ------------------------------------------------------------------ */
uint64_t prng_next(proto_session_t *s) {
    uint64_t x = s->rng;
    x ^= x >> 12;
    x ^= x << 25;
    x ^= x >> 27;
    s->rng = x;
    return x * 0x2545F4914F6CDD1DULL;
}

void prng_seed(proto_session_t *s) {
    uint64_t seed = 0;
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd >= 0) {
        if (read(fd, &seed, sizeof seed) != sizeof seed) seed = 0;
        close(fd);
    }
    if (!seed)
        seed = (uint64_t)getpid() << 32 ^ (uint64_t)time(NULL)
             ^ (uint64_t)(uintptr_t)&seed;
    s->rng = seed ? seed : 0x9E3779B97F4A7C15ULL;
}

/* ------------------------------------------------------------------ */
/* TCP helpers (loopback only)                                         */
/* ------------------------------------------------------------------ */
int pc_full_tcp_listen(int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    int one = 1;
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    a.sin_port = htons((uint16_t)port);
    if (bind(fd, (struct sockaddr *)&a, sizeof a) < 0 ||
        listen(fd, 4) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

int pc_full_tcp_connect(const char *host, int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    if (fd < 0) return -1;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, host, &a.sin_addr) != 1 ||
        connect(fd, (struct sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

/* T1: a CONNECTED UDP socket -- the client's read()/write() paths
 * then work unchanged (single peer, implicit address on both ends)  */
int pc_udp_connect(const char *host, int port) {
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a;
    if (fd < 0) return -1;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, host, &a.sin_addr) != 1 ||
        connect(fd, (struct sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

int pc_udp_listen(int port) {
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a;
    int one = 1;
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    a.sin_port = htons((uint16_t)port);
    if (bind(fd, (struct sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

/* T3: unix domain stream socket at the seeded path -- the docker.sock
 * shape: local IPC carrier, framing identical to the TCP path       */
int pc_unix_listen(const char *path) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    struct sockaddr_un a;
    if (fd < 0) return -1;
    memset(&a, 0, sizeof a);
    a.sun_family = AF_UNIX;
    snprintf(a.sun_path, sizeof a.sun_path, "%s", path);
    unlink(a.sun_path);              /* stale socket from a dead run */
    if (bind(fd, (struct sockaddr *)&a, sizeof a) < 0 ||
        listen(fd, 4) < 0) {
        close(fd);
        return -1;
    }
    /* connecting to a unix socket needs WRITE on the socket file: the
     * default 0755&umask creation locks out any peer running under a
     * different credential (the verifier serves as root and drives the
     * client under an unprivileged drop) -- docker.sock-style explicit
     * permissions instead                                  */
    chmod(a.sun_path, 0777);
    return fd;
}

int pc_unix_connect(const char *path) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    struct sockaddr_un a;
    if (fd < 0) return -1;
    memset(&a, 0, sizeof a);
    a.sun_family = AF_UNIX;
    snprintf(a.sun_path, sizeof a.sun_path, "%s", path);
    if (connect(fd, (struct sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

/* ------------------------------------------------------------------ */
/* T4: RFC 6455 websocket carrier. One HTTP Upgrade at connect, then   */
/* every protocol frame rides a masked (c2s) / plain (s2c) binary      */
/* websocket record -- the record layer lives in proto_frame.c (wrap   */
/* at pf_send_raw, unwrap in pf_reader_feed); these are the two        */
/* handshake halves.                                                   */
/* ------------------------------------------------------------------ */
#define PC_WS_GUID "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

static void pc_ws_accept(const char *key, char out[32]) {
    uint8_t sha[20];
    char cat[128];
    snprintf(cat, sizeof cat, "%s%s", key, PC_WS_GUID);
    pc_sha1((const uint8_t *)cat, strlen(cat), sha);
    pc_b64_encode(sha, 20, out, 32);
}

static int pc_ws_read_head(int fd, char *buf, size_t cap) {
    size_t got = 0;
    while (got + 3 < cap) {
        ssize_t r = read(fd, buf + got, cap - got - 1);
        if (r <= 0) {
            if (r < 0 && errno == EINTR) continue;
            return -1;
        }
        got += (size_t)r;
        buf[got] = 0;
        if (got >= 4 && !memcmp(buf + got - 4, "\r\n\r\n", 4)) return 0;
    }
    return -1;
}

int pc_ws_connect(const char *host, int port) {
    int fd = pc_full_tcp_connect(host, port);
    char req[512], resp[1024], key_b64[32], accept[32], expect[32];
    uint8_t key_raw[16];
    int i;
    FILE *ur;
    if (fd < 0) return -1;
    ur = fopen("/dev/urandom", "rb");
    if (ur == NULL || fread(key_raw, 1, 16, ur) != 16) {
        for (i = 0; i < 16; i++)
            key_raw[i] = (uint8_t)(0x30 + ((i * 7 + port) & 31));
    }
    if (ur != NULL) fclose(ur);
    pc_b64_encode(key_raw, 16, key_b64, sizeof key_b64);
    {
        int w = snprintf(req, sizeof req,
                         "GET %s HTTP/1.1\r\n"
                         "Host: %s:%d\r\n"
                         "Upgrade: websocket\r\n"
                         "Connection: Upgrade\r\n"
                         "Sec-WebSocket-Key: %s\r\n"
                         "Sec-WebSocket-Version: 13\r\n\r\n",
                         PROTO_WS_PATH, host, port, key_b64);
        if (w <= 0 || write(fd, req, (size_t)w) != w) {
            close(fd);
            return -1;
        }
    }
    if (pc_ws_read_head(fd, resp, sizeof resp)) {
        close(fd);
        return -1;
    }
    if (strncmp(resp, "HTTP/1.1 101", 12) != 0 &&
        strncmp(resp, "HTTP/1.0 101", 12) != 0) {
        close(fd);
        return -1;
    }
    /* verify the accept token: proves the peer ran the RFC 6455 KDF,
     * not a parroting 101 -- a wrong accept is a hostile middlebox   */
    pc_ws_accept(key_b64, accept);
    {
        char *lp = strstr(resp, "Sec-WebSocket-Accept: ");
        if (lp == NULL) {
            close(fd);
            return -1;
        }
        lp += strlen("Sec-WebSocket-Accept: ");
        for (i = 0; i < 28 && lp[i] && lp[i] != '\r'; i++)
            expect[i] = lp[i];
        expect[i] = 0;
        if (strcmp(accept, expect) != 0) {
            close(fd);
            return -1;
        }
    }
    return fd;
}

int pc_ws_server_handshake(int fd) {
    char req[1024], *lp, key_b64[64], accept[32], resp[256];
    size_t kl = 0, i;
    int w;
    if (pc_ws_read_head(fd, req, sizeof req)) return -1;
    if (strstr(req, "Upgrade: websocket") == NULL &&
        strstr(req, "upgrade: websocket") == NULL) return -1;
    lp = strstr(req, "Sec-WebSocket-Key: ");
    if (lp == NULL) lp = strstr(req, "sec-websocket-key: ");
    if (lp == NULL) return -1;
    lp += strlen("Sec-WebSocket-Key: ");
    while (*lp == ' ') lp++;
    while (lp[kl] && lp[kl] != '\r' && lp[kl] != '\n' && kl < 40) {
        key_b64[kl] = lp[kl];
        kl++;
    }
    key_b64[kl] = 0;
    if (kl < 20) return -1;
    pc_ws_accept(key_b64, accept);
    w = snprintf(resp, sizeof resp,
                 "HTTP/1.1 101 Switching Protocols\r\n"
                 "Upgrade: websocket\r\n"
                 "Connection: Upgrade\r\n"
                 "Sec-WebSocket-Accept: %s\r\n\r\n", accept);
    if (w <= 0) return -1;
    for (i = 0; i < (size_t)w; i++) {
        ssize_t wr = write(fd, resp + i, w - (int)i);
        if (wr <= 0) {
            if (wr < 0 && errno == EINTR) continue;
            return -1;
        }
        i += (size_t)wr - 1;
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* small server-side key/value store (SET/GET)                         */
/* ------------------------------------------------------------------ */
typedef struct { char k[PROTO_STR_MAX]; uint64_t v; int used; } kv_t;
/* per-thread: the threaded oracle serves concurrent connections and
 * each session's KV store is its own (C10 isolation); the sequential
 * carrier entry is one thread, same behavior as before            */
static __thread kv_t g_kv[32];

static void kv_set(const char *k, uint64_t v) {
    int i;
    for (i = 0; i < 32; i++)
        if (g_kv[i].used && !strcmp(g_kv[i].k, k)) { g_kv[i].v = v; return; }
    for (i = 0; i < 32; i++)
        if (!g_kv[i].used) {
            g_kv[i].used = 1;
            snprintf(g_kv[i].k, PROTO_STR_MAX, "%s", k);
            g_kv[i].v = v;
            return;
        }
}

static int kv_get(const char *k, uint64_t *v) {
    int i;
    for (i = 0; i < 32; i++)
        if (g_kv[i].used && !strcmp(g_kv[i].k, k)) { *v = g_kv[i].v; return 0; }
    return -1;
}

/* ------------------------------------------------------------------ */
/* auth / key-derivation helpers (shared with proto_client.c; declared
 * in proto_internal.h -- the server path needs them too, so exporting
 * them adds nothing client-only to the challenge binary)             */
/* ------------------------------------------------------------------ */
void px_auth_mac(const proto_session_t *s, uint8_t out[16]) {
    uint8_t mac[32];
    pc_prv_hash(PROTO_AUTH_SECRET, PROTO_AUTH_SECRET_LEN,
                   s->nonce, PROTO_NONCE_W, mac);
    memcpy(out, mac, 16);
}

/* S7 resumption: the PSK-style secret and the token both derive from
 * the closing session's material -- both ends (and only they) can
 * compute them. Shared with proto_client.c.                     */
void px_resume_material(const proto_session_t *s, uint8_t secret[32],
                        uint8_t token[16]) {
    uint8_t mac[32];
    pc_prv_kdf(s->nonce, PROTO_NONCE_W, PROTO_AUTH_SECRET,
            PROTO_AUTH_SECRET_LEN, "resume-master", secret);
    pc_prv_hash(secret, 32, (const uint8_t *)"resume-token", 12,
                   mac);
    memcpy(token, mac, 16);
}

void px_resume_mac(const uint8_t secret[32], const proto_session_t *s,
                   uint8_t out[16]) {
    uint8_t mac[32];
    pc_prv_hash(secret, 32, s->nonce, PROTO_NONCE_W, mac);
    memcpy(out, mac, 16);
}

/* S7 server-side token table (bounded; the process that issued a
 * token is the only one that can validate it)                    */
#define RESUME_SLOTS 8
static struct {
    uint8_t token[16];
    uint8_t secret[32];
    int used;
} g_resume[RESUME_SLOTS];
static pthread_mutex_t g_resume_mu = PTHREAD_MUTEX_INITIALIZER;

static int resume_lookup(const uint8_t token[16], uint8_t secret[32]) {
    int hit = 0, i;
    pthread_mutex_lock(&g_resume_mu);
    for (i = 0; i < RESUME_SLOTS; i++)
        if (g_resume[i].used
            && memcmp(g_resume[i].token, token, 16) == 0) {
            memcpy(secret, g_resume[i].secret, 32);
            g_resume[i].used = 0;       /* single-use, TLS-style */
            hit = 1;
            break;
        }
    pthread_mutex_unlock(&g_resume_mu);
    return hit;
}

static void resume_store(const uint8_t token[16], const uint8_t sec[32]) {
    int i, slot = -1;
    pthread_mutex_lock(&g_resume_mu);
    for (i = 0; i < RESUME_SLOTS; i++)
        if (!g_resume[i].used) { slot = i; break; }
    if (slot < 0) slot = 0;             /* bounded table: recycle */
    memcpy(g_resume[slot].token, token, 16);
    memcpy(g_resume[slot].secret, sec, 32);
    g_resume[slot].used = 1;
    pthread_mutex_unlock(&g_resume_mu);
}

uint32_t px_flag_token(const proto_session_t *s, const char *label) {
    uint8_t mac[32];
    uint8_t buf[48];
    memcpy(buf, label, strlen(label));
    memcpy(buf + strlen(label), s->nonce, PROTO_NONCE_W);
    pc_prv_hash(PROTO_AUTH_SECRET, PROTO_AUTH_SECRET_LEN,
                   buf, strlen(label) + PROTO_NONCE_W, mac);
    return (uint32_t)(mac[0] | (mac[1] << 8) | (mac[2] << 16)
                      | ((uint32_t)mac[3] << 24));
}

void px_derive_direction_keys(const uint8_t shared[32],
                              const uint8_t nonce[16],
                              uint8_t c2s[32], uint8_t s2c[32],
                              uint8_t c2s_iv[8], uint8_t s2c_iv[8]) {
    /* one labeled HKDF per direction secret + per direction IV
     * (pc_prv_kdf yields 32 bytes per call) -- key
     * schedule shape (RFC 8446 7.1)                              */
    char label[48];
    uint8_t tmp[32];
    const uint8_t *ikm = shared;
#ifdef PROTO_HOST_BINDING
    /* host-bound: the shared secret is folded with the site-C salt (a
     * seeded host-database row materialized at boot) before the key
     * schedule. The oracle folds the SAME constant out of
     * proto_config.h, so both ends derive identical direction keys --
     * recovering the wire crypto now requires the host state too.   */
    uint8_t ikm_host[32];
    int i;
    for (i = 0; i < 32; i++)
        ikm_host[i] = (uint8_t)(shared[i]
                                ^ PROTO_HOST_KEX_SALT[i % PROTO_HOST_KEX_SALT_LEN]);
    ikm = ikm_host;
#endif
    snprintf(label, sizeof label, "%s-c2s", PROTO_HKDF_LABEL_KEYS);
    pc_prv_kdf(nonce, PROTO_NONCE_W, ikm, 32, label, c2s);
    snprintf(label, sizeof label, "%s-s2c", PROTO_HKDF_LABEL_KEYS);
    pc_prv_kdf(nonce, PROTO_NONCE_W, ikm, 32, label, s2c);
    snprintf(label, sizeof label, "%s-c2s", PROTO_HKDF_LABEL_IVS);
    pc_prv_kdf(nonce, PROTO_NONCE_W, ikm, 32, label, tmp);
    memcpy(c2s_iv, tmp, 8);
    snprintf(label, sizeof label, "%s-s2c", PROTO_HKDF_LABEL_IVS);
    pc_prv_kdf(nonce, PROTO_NONCE_W, ikm, 32, label, tmp);
    memcpy(s2c_iv, tmp, 8);
}

/* ------------------------------------------------------------------ */
/* send helpers                                                        */
/* ------------------------------------------------------------------ */
static int send_msg(proto_session_t *s, int fd, proto_msg_t *m) {
    return pf_write_msg(s, fd, m);
}

/* ------------------------------------------------------------------ */
/* L (multiplex) machinery                                             */
/* ------------------------------------------------------------------ */
/* channels: control = CHAN_BASE, background interleave = CHAN_BASE+1,
 * granted data channel (L2) = CHAN_BASE+2, re-grant = CHAN_BASE+3   */
static int l_bg_chan(void)   { return PROTO_L_CHAN_BASE + 1; }
static int l_data_chan(void) { return PROTO_L_CHAN_BASE + 2; }
static int l_regrant_chan(void) { return PROTO_L_CHAN_BASE + 3; }

/* server: interleave one VALID background frame (PONG-shaped, real
 * schema, real proof) on the background channel every K-th reply --
 * the client must discover the channel field and filter            */
static void maybe_bg_frame(proto_session_t *s, int fd) {
    proto_msg_t bg;
    int shape, chan;
    if (PROTO_L_LEVEL < 1) return;
    if (++s->bg_ctr % PROTO_L_INTERLEAVE_K != 0) return;
    /* L4: background traffic rides a HIGH-priority channel (base+4);
     * L7: every K*M bursts also hit the broadcast channel (0xFF),
     * which every multiplexed endpoint must process            */
    if (PROTO_L_LEVEL >= 7 && s->bg_ctr % (PROTO_L_INTERLEAVE_K * 2) == 0)
        chan = 0xFF;
    else if (PROTO_L_LEVEL >= 4)
        chan = PROTO_L_CHAN_BASE + 4;
    else
        chan = l_bg_chan();
    memset(&bg, 0, sizeof bg);
    /* the seeded background shape: PONG echoes, STAT_RES snapshots, or
     * an alternating mix (STAT needs its X2 schema; guarded)        */
    shape = PROTO_L_BG_SHAPE == 2 ? (int)(s->bg_ctr & 1)
                                  : PROTO_L_BG_SHAPE;
    if (shape == 1 && ps_schema_for(OP_STAT_RES) != NULL) {
        char fmt[24];
        bg.opcode = OP_STAT_RES;
        px_strdec(fmt, LIT_STATFMT, sizeof LIT_STATFMT);
        snprintf(bg.strs[0], PROTO_STR_MAX, fmt,
                 (unsigned long long)(prng_next(s) % 9999));
    } else {
        bg.opcode = OP_PONG;
        bg.ints[0] = prng_next(s) & 0xFFFF;
    }
    if (pf_write_msg_chan(s, fd, &bg, chan)) {
        proto_vlog(s, "bg_write_failed=1");
    }
}

/* server: MUX_ACK helper (grant / open-ack / refill-ack)            */
static int send_mux_ack(proto_session_t *s, int fd, int chan,
                        int credit) {
    proto_msg_t r;
    memset(&r, 0, sizeof r);
    r.opcode = OP_MUX_ACK;
    r.ints[0] = (uint64_t)(unsigned)chan;
    r.ints[1] = (uint64_t)(unsigned)credit;
    return send_msg(s, fd, &r);
}

/* Optional milestone log for the verifier: when PROTO_MILESTONE_LOG
 * is set, server-side session progress AND the per-frame/chaos
 * diagnostic lines are appended there. Every line carries the
 * verifier's per-run secret and the connection id. The challenge
 * binary never sets the env -- only the oracle does.               */
int proto_vlog_enabled(void) {
    char env1[32];
    const char *path;
    px_strdec(env1, LIT_MSLOG, sizeof LIT_MSLOG);
    path = getenv(env1);
    return path != NULL;
}

void proto_vlog(const proto_session_t *s, const char *fmt, ...) {
    /* "<secret> conn=<id> <text>". The secret comes from the
     * verifier's environment and is NOT exported to the analyzed
     * command, so an agent sharing the container cannot forge
     * log lines by appending to the file.                         */
    char env1[32];
    char env2[32];
    const char *path;
    const char *secret;
    va_list ap;
    px_strdec(env1, LIT_MSLOG, sizeof LIT_MSLOG);
    px_strdec(env2, LIT_MSSECRET, sizeof LIT_MSSECRET);
    path = getenv(env1);
    secret = getenv(env2);
    if (path == NULL || secret == NULL) return;
    {
        FILE *f = fopen(path, "a");
        if (f == NULL) return;
        fprintf(f, "%s conn=%d ", secret, s ? s->conn_id : 0);
        va_start(ap, fmt);
        vfprintf(f, fmt, ap);
        va_end(ap);
        fputc('\n', f);
        fclose(f);
    }
}

static void milestone(const proto_session_t *s,
                      const uint8_t *tag_enc, size_t tag_len) {
    /* ladder tags (hello_ok / auth_ok / round / flag_sent) on the same
     * conn-attributed log the diagnostics use                        */
    char tag[16];
    if (tag_len < sizeof tag) px_strdec(tag, tag_enc, tag_len);
    else return;
    proto_vlog(s, "%s", tag);
}

/* decode the obfuscated session flag into out (NUL-terminated) */
void proto_session_flag_decode(char *out, size_t cap) {
    int i;
    /* volatile loads: mandatory anti-constant-fold -- with plain loads,
     * clang's GlobalOpt promotes the never-written arrays back to
     * constants and SSE-vectorizes this loop, shipping flag[0:16]
     * verbatim in .rodata.cst16 (R7 catches this on the xollvm/clang
     * path; tigress-VM paths are immune)          */
    const volatile uint8_t *enc = PROTO_SESSION_FLAG_ENC;
    const volatile uint8_t *ks = PROTO_FLAG_XOR;
    for (i = 0; i < PROTO_FLAG_LEN && i + 1 < (int)cap; i++)
        out[i] = (char)(enc[i] ^ ks[i % 64]);
    out[i] = 0;
}

/* ------------------------------------------------------------------ */
/* per-connection session flag                                         */
/* ------------------------------------------------------------------ */
/* The static encoded material now provides only the task-unique PREFIX
 * ("flag{" + 3 chars); the 20-character BODY is derived from THIS
 * connection's nonce. Consequences:
 *   - every run delivers a different flag, so replaying a recorded
 *     FLAG_RES (or printing a statically dumped constant) can never
 *     match the value the verifier expects for the live run
 *   - the verifier learns the expected value from the oracle's own
 *     secret-prefixed log line, never from a fixed field
 *   - the encoded static suffix riding in the image is a DECOY: it is
 *     not the answer to anything                              */
static void flag_deliver(const proto_session_t *s, char *out, size_t cap) {
    static const char b32[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    uint8_t mac[32];
    char pref[PROTO_STR_MAX];
    int i;
    pc_prv_hash(PROTO_AUTH_SECRET, PROTO_AUTH_SECRET_LEN,
                   s->nonce, PROTO_NONCE_W, mac);
    proto_session_flag_decode(pref, sizeof pref);
    if (cap < 8 + 20 + 2) { if (cap) out[0] = 0; return; }
    memcpy(out, pref, 8);                     /* "flag{XXX" prefix     */
    for (i = 0; i < 20; i++)
        out[8 + i] = b32[mac[i] & 31];
    out[28] = '}';
    out[29] = 0;
}

/* ------------------------------------------------------------------ */
/* server message handling                                             */
/* ------------------------------------------------------------------ */
/* session-command set (mirrors st_is_command in proto_state.c)        */
static int hd_is_command(int opcode) {
    return opcode == OP_GET || opcode == OP_SET || opcode == OP_SUM
        || opcode == OP_FLAG || opcode == OP_BYE;
}

static int handle_message_inner(proto_session_t *s, int fd,
                                proto_msg_t *m);

/* C12 bookkeeping: the drop fires ONCE per oracle process -- the
 * client's reconnect must then complete a clean full session       */
static int g_chaos_dropped = 0;

static int handle_message(proto_session_t *s, int fd, proto_msg_t *m) {
    int rc = handle_message_inner(s, fd, m);
    if (rc == 0 && proto_chaos_mode() == PROTO_CHAOS_DROP
        && proto_chaos_applicable(PROTO_CHAOS_DROP)
        && ps_fsm_is_kind(s->state, 3) && s->chaos_cmds == 3
        && !(s->chaos_once & PROTO_CHAOS_BIT_DROP) && !g_chaos_dropped) {
        s->chaos_once |= PROTO_CHAOS_BIT_DROP;
        g_chaos_dropped = 1;
        proto_vlog(s, "chaos_drop forced=1");
        return 2;               /* the serve loop closes without BYE   */
    }
    return rc;
}

static uint64_t now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + (uint64_t)(ts.tv_nsec / 1000000);
}

/* VALUE-gate evaluation: the edge names a message field (by sem) and a
 * comparison; the match side advances, the fail side earns the ERR
 * transition (field-level validation)                    */
static int fsm_cond_match(const proto_msg_t *m, const ps_fsm_edge_t *ed) {
    const proto_schema_t *sch;
    int slot;
    uint64_t v = 0;
    if (ed->cond_sem == 0) return 1;              /* unconditional */
    sch = ps_schema_for(ed->opcode);
    if (sch == NULL) return 1;
    slot = ps_sem_slot(sch, ed->cond_sem, 0);
    if (slot < 0) return 1;
    if (m->strs[slot][0] != 0 || m->blobs[slot][0] || m->blobs[slot][1]) {
        /* string/blob fields compare by LENGTH against the operand --
         * a length-domain gate keeps the check schema-uniform       */
        v = (uint64_t)strlen(m->strs[slot]);
    } else {
        v = m->ints[slot];
    }
    switch (ed->cond_op) {
    case 0: return v == ed->cond_operand;         /* EQ */
    case 1: return v != ed->cond_operand;         /* NE */
    case 2: return v <  ed->cond_operand;         /* LT */
    case 3: return v >= ed->cond_operand;         /* GE */
    case 4: return v <= ed->cond_operand;         /* LE */
    case 5: return v >  ed->cond_operand;         /* GT */
    }
    return 1;
}

/* the dialog-graph dispatch: the serialized table is the single
 * authority for which message walks which transition in which state
 * The table is the single dispatch authority. Edge
 * milestones feed the verifier's coverage scoring.                  */
static int dispatch_message(proto_session_t *s, int fd,
                            proto_msg_t *m, const ps_fsm_edge_t *ed,
                            int has_edge, int *rejected);

static int handle_message_inner(proto_session_t *s, int fd,
                                proto_msg_t *m) {
    proto_msg_t r;
    ps_fsm_edge_t ed;
    int has_edge, rejected = 0, rc;

    memset(&r, 0, sizeof r);
    /* L1+: the reply channel follows the PEER -- the channel this
     * inbound frame rode is where the peer is listening NOW (after
     * a mid-session re-grant the peer may re-open from a moved
     * channel while our chan_active already points at the new one;
     * answering on anything but the peer's channel gets the reply
     * skipped as foreign forever). The client mirrors this rule in
     * cli_txn (re-anchor after the dance)                        */
    if (PROTO_L_LEVEL >= 1 && m->chan != 0)
        s->chan = m->chan;
    /* precedence lookup: the once-per-session reauth edge (flags bit2)
     * wins while unfired, then success edges, then declared err edges
     * -- a plain first-match would let a success edge shadow the
     * error/reauth siblings declared for the same role          */
    {
        int k, best = -1;
        ps_fsm_edge_t cand;
        has_edge = 0;
        for (k = 0; k < 32; k++) {
            if (ps_fsm_edge_at(s->state, k, &cand) != 0) break;
            if (cand.opcode != (uint8_t)m->opcode) continue;
            if (!s->reauth_done && (cand.flags & 4)) { best = k; break; }
            if (cand.cls != 3 && best < 0) best = k;
            if (cand.cls == 3 && best < 0) best = k;
        }
        if (best >= 0) {
            ps_fsm_edge_at(s->state, best, &ed);
            has_edge = 1;
        }
    }

    /* per-state negotiation deadline (the timeout transition). The
     * clock is IDLE time since the state was ENTERED, refreshed on
     * every inbound message: a peer that keeps the dialog moving (a
     * slow but live walker) never trips it, a stalled one does    */
    {
        /* idle-gap semantics: the transition fires when the gap from
         * the PREVIOUS inbound message to this one exceeded the
         * state's deadline (the peer stalled inside a timed state).
         * A live-but-slow walker never trips it; the deliberate
         * timeout sleep does -- which is how the edge is covered   */
        uint32_t tmo = ps_fsm_timeout_ms(s->state);
        int te = ps_fsm_timeout_edge(s->state);
        uint64_t now = now_ms();
        if (tmo && te >= 0 && s->last_msg_ms
            && now - s->last_msg_ms > (uint64_t)tmo) {
            proto_vlog(s, "edge on=%d from=%d to=%d rc=1",
                       -1, s->state, te);
            s->state = te;
            s->state_enter_ms = now;
        }
        s->last_msg_ms = now;
    }

    /* S5: the once-per-session forced re-auth rides one working edge
     * (flags bit2); after it fires the edge's normal handling applies */
    if (has_edge && (ed.flags & 4) && !s->reauth_done) {
        s->reauth_done = 1;
        proto_vlog(s, "s5_reauth_forced=1");
        r.opcode = OP_ERR;
        r.ints[0] = PROTO_ERR_REAUTH;
        if (send_msg(s, fd, &r)) return -1;
        proto_vlog(s, "edge on=%d from=%d to=%d rc=0",
                   m->opcode, s->state, s->state);
        /* the forced re-auth HOLDS the dialog: the class contract is
         * "re-run the AUTH stage alone" -- walking the carrier edge's
         * declared next moved the session to an error state the peer
         * then had to re-ladder out of; the auth drop alone carries
         * the downgrade semantics                              */
        s->authed = 0;
        s->tx_ctr = s->rx_ctr = 0;
        return 0;
    }

    if (m->opcode == OP_AUTH && !s->authed && s->reauth_done
        && (!has_edge || ed.cls == 3)) {
        /* the S5 recovery re-AUTH: the forced reauth left the session
         * unauthed mid-dialog and the peer re-runs the AUTH stage --
         * at a mode state the table names no auth-success edge (only
         * the auth-ERR probe), so the mandated recovery could never
         * land. The recovery AUTH is a session-level operation: serve
         * it from the handler wherever the dialog sits          */
        return dispatch_message(s, fd, m, &ed, 0, &rejected);
    }
    if (!has_edge && PROTO_L_LEVEL >= 2 && m->opcode == OP_MUX_OPEN) {
        /* the L2 control plane is transport housekeeping, not dialog:
         * an open must be answered wherever the session sits. The
         * table's mux edges (self items on the mode states, declared
         * ERR probes elsewhere) stay COVERAGE fires -- only an open
         * the table does NOT name falls through to the handler, so a
         * wedged peer can always re-open after a silent move      */
        return dispatch_message(s, fd, m, &ed, 0, &rejected);
    }
    if (!has_edge && m->opcode == OP_FLAG && s->flag_fired) {
        /* the flag edge already fired but its reply was replaced by
         * a mid-session re-grant (an organic L2 event): the re-issued
         * FLAG past the departed state is answered by re-delivering
         * the same FLAG_RES -- idempotent, like the bootstrap
         * re-announce, so a conformant peer's re-issue lands       */
        return dispatch_message(s, fd, m, &ed, 0, &rejected);
    }
    if (!has_edge || ed.cls == 3) {
        /* wrong message for this state (or a declared ERR edge): the
         * class-coded reply goes out and the state usually holds --
         * real protocols reject without moving; downgrade edges enter
         * the error state. Inside an error state the class says
         * RESYNC so a conformant peer recognizes the recovery
         * (re-ladder) rather than misreading a plain wrong-state  */
        r.opcode = OP_ERR;
        r.ints[0] = has_edge ? ed.err_code
            : ps_fsm_is_kind(s->state, 5) ? PROTO_ERR_RESYNC
            : PROTO_ERR_STATE;
        if (send_msg(s, fd, &r)) return -1;
        proto_vlog(s, "edge on=%d from=%d to=%d rc=0",
                   m->opcode, s->state,
                   has_edge ? ed.next : s->state);
        if (has_edge && (ed.flags & 1)) {
            s->state = ed.next;
            s->state_enter_ms = now_ms();
            s->authed = 0;
            s->tx_ctr = s->rx_ctr = 0;
        }
        return 0;
    }
    if (ed.cls == 2 && !fsm_cond_match(m, &ed)) {
        /* VALUE gate failed: the field-content branch -- a malformed
         * or out-of-domain field earns its own ERR transition       */
        r.opcode = OP_ERR;
        r.ints[0] = ed.err_code ? ed.err_code : PROTO_ERR_STATE;
        if (send_msg(s, fd, &r)) return -1;
        proto_vlog(s, "edge on=%d from=%d to=%d rc=0",
                   m->opcode, s->state,
                   ed.alt == 0xFF ? s->state : ed.alt);
        return 0;
    }

    {
        int pre_state = s->state;
        rc = dispatch_message(s, fd, m, &ed, has_edge, &rejected);
        /* a chaos injection (forced resync/re-auth) moves the state
         * INSIDE dispatch and consumes the message: the wrapper must
         * NOT then blindly advance along the old edge -- that would
         * clobber the error state the fault just installed (leaving
         * authed=0 at a working state, an unrecoverable mix)     */
        if (s->state != pre_state)
            return rc < 0 ? rc : 0;
        if (m->dup) {
            /* a retransmission (S3 tolerance): the handler above just
             * re-ran for the reply; the edge does NOT fire again -- a
             * duplicate value-edge would double-advance the dialog  */
            proto_vlog(s, "dup_tolerated on=%d state=%d",
                       m->opcode, s->state);
            return rc < 0 ? rc : 0;
        }
        if (rc == 1 && !rejected) {
            /* the BYE close: log + advance BEFORE reporting the
             * close, or the close edge never reaches the log      */
            int nxt = ed.next == 0xFF ? s->state : ed.next;
            proto_vlog(s, "edge on=%d from=%d to=%d rc=1",
                       m->opcode, s->state, nxt);
            s->state = nxt;
            return 1;
        }
        if (rc != 0)
            return rc;                 /* -1 io dead                */
        if (rejected)
            return 0;                  /* organic ERR: state holds  */
    }
    {
        int nxt = ed.next == 0xFF ? s->state : ed.next;
        /* S7 resume: an abbreviated re-HELLO skips the negotiation
         * segment -- jump straight to the auth gate                 */
        if (m->opcode == OP_HELLO && s->has_resume) {
            int a = ps_fsm_find_kind(2 /* auth */);
            if (a >= 0) nxt = a;
        }
        if (nxt != s->state) {
            proto_vlog(s, "edge on=%d from=%d to=%d rc=1",
                       m->opcode, s->state, nxt);
            s->state = nxt;
            s->state_enter_ms = now_ms();
        } else {
            proto_vlog(s, "edge on=%d from=%d to=%d rc=1",
                       m->opcode, s->state, s->state);
        }
        /* the flag EDGE fired (the handler may have been skipped when
         * a mid-session re-grant replaced the reply inside dispatch):
         * mark it so a re-issued FLAG past this state is re-answered
         * idempotently instead of ERR STATE                      */
        if (m->opcode == OP_FLAG)
            s->flag_fired = 1;
    }
    return 0;
}

static int dispatch_message(proto_session_t *s, int fd,
                            proto_msg_t *m, const ps_fsm_edge_t *ed,
                            int has_edge, int *rejected) {
    proto_msg_t r;
    memset(&r, 0, sizeof r);

    /* chaos orchestration (session commands): counters + one-shot
     * semantic faults live ahead of the normal dispatch             */
    if (ps_fsm_is_kind(s->state, 3) && hd_is_command(m->opcode)) {
        s->chaos_cmds++;
        /* C14/C17/C18 (error-code-class faults): silently tear one
         * piece of session-admission state once, so the NEXT
         * otherwise-valid command hits the class's organic gate
         * (S6 txn bracket / L3 credit window / L2 channel binding)
         * and the recovery branch per class is observable on the
         * wire. The tear itself consumes nothing                   */
        if (s->chaos_cmds == 3) {
            if (proto_chaos_mode() == PROTO_CHAOS_ERRSTATE
                && proto_chaos_applicable(PROTO_CHAOS_ERRSTATE)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ESTATE)) {
                s->chaos_once |= PROTO_CHAOS_BIT_ESTATE;
                s->txn_open = 0;
                proto_vlog(s, "chaos_errstate forced=1");
            }
            if (proto_chaos_mode() == PROTO_CHAOS_ERRCREDIT
                && proto_chaos_applicable(PROTO_CHAOS_ERRCREDIT)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ECREDIT)) {
                s->chaos_once |= PROTO_CHAOS_BIT_ECREDIT;
                s->credit = 0;
                proto_vlog(s, "chaos_errcredit forced=1");
            }
            if (proto_chaos_mode() == PROTO_CHAOS_ERRCHANNEL
                && proto_chaos_applicable(PROTO_CHAOS_ERRCHANNEL)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ECHAN)) {
                s->chaos_once |= PROTO_CHAOS_BIT_ECHAN;
                /* BASE+5 sits past every seeded channel role (data
                 * +2, mid-session regrant +3, L4 priority +4), so
                 * the redirect can never alias the channel the
                 * client already holds                        */
                s->chan_active = PROTO_L_CHAN_BASE + 5;
                s->mux_opened = 0;
                s->credit = 0;
                proto_vlog(s, "chaos_errchannel forced=1");
            }
        }
        /* L2: exactly one mid-session channel re-grant -- the command
         * is CONSUMED (no reply): the peer sees the MUX_ACK redirect,
         * must re-open on the new channel and retransmit            */
        if (PROTO_L_LEVEL >= 2 && s->chaos_cmds == 2
            && !s->mux_regranted && s->mux_opened) {
            s->mux_regranted = 1;
            s->chan_active = l_regrant_chan();
            s->mux_opened = 0;
            s->credit = 0;
            proto_vlog(s, "mux_regrant chan=%d", s->chan_active);
            /* the command is CONSUMED, not answered: mark it rejected so
             * the wrapper does not advance the dialog along the edge the
             * redirect just swallowed -- the peer re-opens and RETRANS-
             * MITS, and only that copy may fire the edge. An advancing
             * edge (the FLAG) that advanced here left the server one
             * state past the retransmit's landing: every retry met a
             * declared wrong-state ERR and the session died       */
            *rejected = 1;
            return send_mux_ack(s, fd, s->chan_active, 0);
        }
        /* L>=1: commands are only valid on the ACTIVE channel. Both
         * admission rejections are ORGANIC ERRs: mark rejected or the
         * wrapper advances the dialog along the edge the gate just
         * refused (a mid-session grant's CHANNEL err then walked the
         * server past the FLAG state and every retry died STATE)   */
        if (PROTO_L_LEVEL >= 1 && m->chan != s->chan_active) {
            *rejected = 1;
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_CHANNEL;
            return send_msg(s, fd, &r);
        }
        /* L3: credit accounting -- a starved client must refill via
         * MUX_OPEN before its next command                         */
        if (PROTO_L_LEVEL >= 3 && s->credit <= 0) {
            *rejected = 1;
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_CREDIT;
            return send_msg(s, fd, &r);
        }
        if (PROTO_L_LEVEL >= 3) s->credit--;
        /* S6: commands ride inside a transaction group (the edge's
         * bracket flag). BYE is exempt -- closing outside a group is
         * legitimate (and gating it would strand the S7 token)    */
        if (has_edge && (ed->flags & 2) && !s->txn_open) {
            if ((s->chaos_once & PROTO_CHAOS_BIT_ESTATE)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ESTATE_R))
                proto_vlog(s, "chaos_errstate_hit=1");
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_STATE;
            return send_msg(s, fd, &r);
        }
        /* C19: answer one fully-valid command with ERR unknown in
         * place of its reply -- the class recovery re-establishes
         * position the same way a resync does (re-run the ladder).
         * One-shot by bit alone: at L>=2 the organic mid-session
         * re-grant consumes the second command, so a fixed counter
         * would never fire */
        if (proto_chaos_mode() == PROTO_CHAOS_ERRUNKNOWN
            && proto_chaos_applicable(PROTO_CHAOS_ERRUNKNOWN)
            && !(s->chaos_once & PROTO_CHAOS_BIT_EUNK)) {
            s->chaos_once |= PROTO_CHAOS_BIT_EUNK;
            proto_vlog(s, "chaos_errunknown forced=1");
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_UNKNOWN;
            if (send_msg(s, fd, &r)) return -1;
            /* the class recovery is a re-ladder: downgrade after the
             * keyed ERR is on the wire (resync semantics)          */
            { int e = ps_fsm_find_kind(5); if (e >= 0) s->state = e; }
            s->authed = 0;
            s->tx_ctr = s->rx_ctr = 0;
            s->my_seq = s->peer_seq = 0;
            return 0;
        }
        /* C2 observation: a further command AFTER the corrupted reply
         * means the client noticed and retried (or is pipelining; the
         * ladder outcome line separates the two)                     */
        if (proto_chaos_mode() == PROTO_CHAOS_CORRUPTREPLY
            && (s->chaos_once & PROTO_CHAOS_BIT_CORRUPT)
            && !(s->chaos_once & PROTO_CHAOS_BIT_RETRANS)) {
            s->chaos_once |= PROTO_CHAOS_BIT_RETRANS;
            proto_vlog(s, "chaos_retrans observed=1");
        }
        /* C6: force the resync dance once, at the third command */
        if (proto_chaos_mode() == PROTO_CHAOS_RESYNC
            && proto_chaos_applicable(PROTO_CHAOS_RESYNC)
            && s->chaos_cmds == 3
            && !(s->chaos_once & PROTO_CHAOS_BIT_RESYNC)) {
            s->chaos_once |= PROTO_CHAOS_BIT_RESYNC;
            proto_vlog(s, "chaos_resync forced=1");
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_RESYNC;
            if (send_msg(s, fd, &r)) return -1;
            /* downgrade AFTER the encrypted ERR is on the wire: the
             * peer restarts the ladder in the clear (same semantics
             * as the organic error-recovery path above)             */
            { int e = ps_fsm_find_kind(5); if (e >= 0) s->state = e; }
            s->authed = 0;
            s->tx_ctr = s->rx_ctr = 0;
            return 0;
        }
    }

    switch (m->opcode) {
    case OP_HELLO: {
        if (m->ints[0] != PROTO_VERSION) {
            *rejected = 1;
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_VERSION;
            return send_msg(s, fd, &r);
        }
        /* C9: one ERR in front of the FIRST valid HELLO per connection
         * -- a conformant client recognizes ERR and retries          */
        if (proto_chaos_mode() == PROTO_CHAOS_ERRHELLO
            && proto_chaos_applicable(PROTO_CHAOS_ERRHELLO)
            && !(s->chaos_once & PROTO_CHAOS_BIT_ERRHELLO)) {
            /* the ERR replaces the ACK: mark rejected so the wrapper
             * does NOT advance along the (valid) HELLO edge       */
            *rejected = 1;
            s->chaos_once |= PROTO_CHAOS_BIT_ERRHELLO;
            proto_vlog(s, "chaos_errhello forced=1");
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_VERSION;
            return send_msg(s, fd, &r);
        }
        if (ps_fsm_is_kind(s->state, 5)
            && (s->chaos_once & PROTO_CHAOS_BIT_RESYNC))
            proto_vlog(s, "chaos_resync_recovered=1");
        if (PROTO_S_LEVEL >= 7) {
            /* abbreviated re-handshake: a presented token that matches
             * the table skips the PARAMS negotiation (S3) and re-keys
             * the AUTH challenge off the resumption secret        */
            const proto_schema_t *hs = ps_schema_for(OP_HELLO);
            int tslot = ps_sem_slot(hs, PSEM_TOKEN, 0);
            if (tslot >= 0 && resume_lookup(m->blobs[tslot],
                                            s->resume_secret)) {
                s->has_resume = 1;
                proto_vlog(s, "s7_resume_hit=1");
            } else if (s->has_resume) {
                /* a PLAIN re-HELLO (resync recovery after a resumed
                 * session) must run the full ladder: the stale resume
                 * flag would skip PARAMS and desync the dance       */
                s->has_resume = 0;
            }
        }
        r.opcode = OP_HELLO_ACK;
        r.ints[0] = PROTO_VERSION;
        if (PROTO_S_LEVEL >= 2) r.ints[1] = s->session_id;
        {
            const proto_schema_t *ha = ps_schema_for(OP_HELLO_ACK);
            int nslot = ps_sem_slot(ha, PSEM_NONCE, 0);
            int pslot = ps_sem_slot(ha, PSEM_KEY, 0);
            if (nslot >= 0) memcpy(r.blobs[nslot], s->nonce,
                                   PROTO_NONCE_W);
            if (PROTO_C_KEX && pslot >= 0) {
                uint8_t pub[32];
                pc_prv_pub(pub, PROTO_SERVER_PRIV, 32);
                memcpy(r.blobs[pslot], pub, 32);
            }
        }
        if (send_msg(s, fd, &r)) return -1;
        /* the nonce only goes live when the wire actually CARRIES it
         * (S>=2 or X>=1 per build_schemas). At S1X0 no nonce field
         * exists: the client can never adopt one, and flipping here
         * anyway rolls the server's frame material (magic/CRC keys)
         * out from under the still-static client -- every post-HELLO
         * frame dies at the magic check and the dialog wedges      */
        {
            const proto_schema_t *ha2 = ps_schema_for(OP_HELLO_ACK);
            if (ps_sem_slot(ha2, PSEM_NONCE, 0) >= 0)
                s->nonce_live = 1;
        }
        milestone(s, LIT_TAG_HELLO, sizeof LIT_TAG_HELLO);
        return 0;
    }
    case OP_PARAMS: {
        r.opcode = OP_PARAMS_ACK;
        r.ints[0] = m->ints[0];                       /* echo window */
        {
            char lb[12];
            px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
            r.ints[1] = px_flag_token(s, lb);
        }
        return send_msg(s, fd, &r);
    }
    case OP_AUTH: {
        /* C15 (error-code-class fault): reject the first re-AUTH of
         * the S5 downgrade once -- the class recovery is a retry in
         * place (the seeded organic budget still bounds genuinely
         * bad authenticators into a reconnect, so this fault does
         * NOT touch auth_fails)                                   */
        if (proto_chaos_mode() == PROTO_CHAOS_ERRAUTH
            && proto_chaos_applicable(PROTO_CHAOS_ERRAUTH)
            && s->reauth_done && ps_fsm_is_kind(s->state, 2)
            && !(s->chaos_once & PROTO_CHAOS_BIT_EAUTH)) {
            s->chaos_once |= PROTO_CHAOS_BIT_EAUTH;
            proto_vlog(s, "chaos_errauth forced=1");
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_AUTH;
            return send_msg(s, fd, &r);
        }
        /* slot layout resolved from the schema (C3: pub then mac)    */
        const proto_schema_t *as = ps_schema_for(OP_AUTH);
        int mslot = ps_sem_slot(as, PSEM_KEY,
                                PROTO_C_KEX ? 1 : 0);
        int pslot = ps_sem_slot(as, PSEM_KEY, 0);
        const uint8_t *mac = mslot >= 0 ? m->blobs[mslot] : NULL;
        uint8_t want[16];
        if (PROTO_S_LEVEL >= 7 && s->has_resume)
            px_resume_mac(s->resume_secret, s, want);
        else
            px_auth_mac(s, want);
        /* ② diagnostics: reaching the handler means opcode + payload
         * structure decoded (those elements are granted); the rest is
         * value-level -- mac value, and for C3 the pubkey shape      */
        {
            int macval = mac != NULL && memcmp(mac, want, 16) == 0;
            int pub_ok = 0, curve_ok = 0;
            if (PROTO_C_KEX && pslot >= 0) {
                uint8_t sh[32];
                pub_ok = 1;      /* the slot decoded a 32-byte blob    */
                curve_ok = pc_prv_shared(sh, PROTO_SERVER_PRIV, 32,
                                     m->blobs[pslot]) == 0;
            }
            proto_vlog(s, "auth macslot=%d macval=%d pub=%d curve=%d "
                         "crypt=%d",
                       mac != NULL, macval, pub_ok, curve_ok,
                       s->diag ? s->diag->crypt_ok : -1);
        }
        if (!mac || memcmp(mac, want, 16)) {
            *rejected = 1;
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_AUTH;
            if (send_msg(s, fd, &r)) return -1;
            /* the seeded retry budget: a locked-out peer must reconnect
             * (fresh nonce, fresh session -- nothing carries over)    */
            s->auth_fails++;
            if (PROTO_AUTH_FAIL_MAX > 0
                && s->auth_fails >= PROTO_AUTH_FAIL_MAX)
                return 1;
            return 0;
        }
        if (PROTO_C_KEX) {
            /* derive keys now, but keep authed=0 until AUTH_OK is on
             * the wire -- the client cannot decrypt AUTH_OK yet      */
            uint8_t shared[32];
            uint8_t c2s[32], s2c[32], c2s_iv[8], s2c_iv[8];
            if (pslot < 0 ||
                pc_prv_shared(shared, PROTO_SERVER_PRIV, 32,
                              m->blobs[pslot]))
                return -1;
            px_derive_direction_keys(shared, s->nonce, c2s, s2c,
                                  c2s_iv, s2c_iv);
            memcpy(s->tx_key, s2c, 32);
            memcpy(s->rx_key, c2s, 32);
            memcpy(s->tx_iv, s2c_iv, 8);
            memcpy(s->rx_iv, c2s_iv, 8);
            s->tx_ctr = s->rx_ctr = 0;
            r.opcode = OP_AUTH_OK;
            r.ints[0] = 0;
            {
                int cslot = ps_sem_slot(ps_schema_for(OP_AUTH_OK),
                                        PSEM_KEY, 0);
                uint8_t conf[32];
                char cf[12];
                px_strdec(cf, LIT_CONFIRM, sizeof LIT_CONFIRM);
                pc_prv_hash(shared, 32, cf, strlen(cf), conf);
                if (cslot >= 0) memcpy(r.blobs[cslot], conf, 8);
            }
            if (send_msg(s, fd, &r)) return -1;
            s->authed = 1;
            if ((s->chaos_once & PROTO_CHAOS_BIT_EAUTH)
                && !(s->chaos_once & PROTO_CHAOS_BIT_EAUTH_R)) {
                /* C15 recovery observed: AUTH retried and passed */
                s->chaos_once |= PROTO_CHAOS_BIT_EAUTH_R;
                proto_vlog(s, "chaos_errauth_recovered=1");
            }
            milestone(s, LIT_TAG_AUTH, sizeof LIT_TAG_AUTH);
            /* L2: the AUTH_OK is followed by a channel GRANT -- the
             * command traffic moves to the granted channel and the
             * client must activate it with MUX_OPEN                  */
            if (PROTO_L_LEVEL >= 2) {
                s->chan_active = l_data_chan();
                s->mux_opened = 0;
                s->credit = 0;
                return send_mux_ack(s, fd, s->chan_active, 0);
            }
            return 0;
        }
        r.opcode = OP_AUTH_OK;
        r.ints[0] = 0;
        if (send_msg(s, fd, &r)) return -1;
        s->authed = 1;
        if ((s->chaos_once & PROTO_CHAOS_BIT_EAUTH)
            && !(s->chaos_once & PROTO_CHAOS_BIT_EAUTH_R)) {
            s->chaos_once |= PROTO_CHAOS_BIT_EAUTH_R;
            proto_vlog(s, "chaos_errauth_recovered=1");
        }
        milestone(s, LIT_TAG_AUTH, sizeof LIT_TAG_AUTH);
        if (PROTO_L_LEVEL >= 2) {
            s->chan_active = l_data_chan();
            s->mux_opened = 0;
            s->credit = 0;
            return send_mux_ack(s, fd, s->chan_active, 0);
        }
        return 0;
    }
    case OP_GET: {
        uint64_t v = 0;
        int had = kv_get(m->strs[0], &v) == 0;
        proto_vlog(s, "cmd op=GET crypt=%d plain=%d samekey=%d",
                   s->diag ? s->diag->crypt_ok : -1,
                   s->diag ? s->diag->dual_plain : -1, had);
        milestone(s, LIT_TAG_ROUND, sizeof LIT_TAG_ROUND);
        r.opcode = OP_VAL;
        snprintf(r.strs[0], PROTO_STR_MAX, "%s", m->strs[0]);
        if (had) r.ints[1] = v;
        else r.ints[1] = 1000 + prng_next(s) % 63000;
        if (send_msg(s, fd, &r)) return -1;
        maybe_bg_frame(s, fd);
        return 0;
    }
    case OP_SET: {
        proto_vlog(s, "cmd op=SET crypt=%d plain=%d",
                   s->diag ? s->diag->crypt_ok : -1,
                   s->diag ? s->diag->dual_plain : -1);
        kv_set(m->strs[0], m->ints[1]);
        milestone(s, LIT_TAG_ROUND, sizeof LIT_TAG_ROUND);
        r.opcode = OP_OK;
        r.ints[0] = 0;
        if (send_msg(s, fd, &r)) return -1;
        maybe_bg_frame(s, fd);
        return 0;
    }
    case OP_SUM: {
        proto_vlog(s, "cmd op=SUM crypt=%d plain=%d",
                   s->diag ? s->diag->crypt_ok : -1,
                   s->diag ? s->diag->dual_plain : -1);
        milestone(s, LIT_TAG_ROUND, sizeof LIT_TAG_ROUND);
        r.opcode = OP_SUM_RES;
        r.ints[0] = (m->ints[0] + m->ints[1]) & 0xFFFF;
        if (send_msg(s, fd, &r)) return -1;
        maybe_bg_frame(s, fd);
        return 0;
    }
    case OP_FLAG: {
        if (PROTO_S_LEVEL >= 2) {
            char lb[12];
            uint32_t want;
            px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
            want = px_flag_token(s, lb);
            /* ④ diagnostics: the grammar element is granted (this
             * frame reached the handler); the token is the value   */
            proto_vlog(s, "flag token_ok=%d", !(!s->authed
                                                || m->ints[0] != want));
            if (!s->authed || m->ints[0] != want) {
                *rejected = 1;
                r.opcode = OP_ERR;
                r.ints[0] = PROTO_ERR_TOKEN;
                return send_msg(s, fd, &r);
            }
            /* C16 (error-code-class fault): refuse one VALID token --
             * the class recovery re-establishes the token position by
             * re-running the ladder (a fresh PARAMS token), so the
             * refusal downgrades to RESYNC exactly like the organic
             * resync path: the ERR rides the CURRENT keyed dialect,
             * the keys drop after it is on the wire            */
            if (proto_chaos_mode() == PROTO_CHAOS_ERRTOKEN
                && proto_chaos_applicable(PROTO_CHAOS_ERRTOKEN)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ETOKEN)) {
                *rejected = 1;
                s->chaos_once |= PROTO_CHAOS_BIT_ETOKEN;
                proto_vlog(s, "chaos_errtoken forced=1");
                r.opcode = OP_ERR;
                r.ints[0] = PROTO_ERR_TOKEN;
                if (send_msg(s, fd, &r)) return -1;
                { int e = ps_fsm_find_kind(5); if (e >= 0) s->state = e; }
                s->authed = 0;
                s->tx_ctr = s->rx_ctr = 0;
                s->my_seq = s->peer_seq = 0;
                return 0;
            }
        }
        r.opcode = OP_FLAG_RES;
        s->flag_fired = 1;
        flag_deliver(s, r.strs[0], PROTO_STR_MAX);
        milestone(s, LIT_TAG_FLAG, sizeof LIT_TAG_FLAG);
        /* the verifier's expected value for THIS run: secret-prefixed
         * and connection-attributed, so it is neither forgeable nor
         * reusable across runs                                     */
        proto_vlog(s, "flag_delivered value=%s", r.strs[0]);
        return send_msg(s, fd, &r);
    }
    case OP_TXN_BEGIN: {                   /* S6: transaction groups */
        if ((s->chaos_once & PROTO_CHAOS_BIT_ESTATE)
            && !(s->chaos_once & PROTO_CHAOS_BIT_ESTATE_R)) {
            /* C14 recovery observed: a group opened after the tear */
            s->chaos_once |= PROTO_CHAOS_BIT_ESTATE_R;
            proto_vlog(s, "chaos_errstate_recovered=1");
        }
        memcpy(s->txn_snap, g_kv, sizeof g_kv);
        s->txn_open = 1;
        proto_vlog(s, "s6_txn_begin=1");
        r.opcode = OP_OK;
        r.ints[0] = 0;
        return send_msg(s, fd, &r);
    }
    case OP_TXN_COMMIT: {
        s->txn_open = 0;
        proto_vlog(s, "s6_txn_commit=1");
        r.opcode = OP_OK;
        r.ints[0] = 0;
        return send_msg(s, fd, &r);
    }
    case OP_TXN_ROLLBACK: {
        memcpy(g_kv, s->txn_snap, sizeof g_kv);
        s->txn_open = 0;
        proto_vlog(s, "s6_txn_rollback=1");
        r.opcode = OP_OK;
        r.ints[0] = 0;
        return send_msg(s, fd, &r);
    }
    case OP_PING: {                        /* X2 decoy: plausible junk */
        r.opcode = OP_PONG;
        r.ints[0] = m->ints[0];
        return send_msg(s, fd, &r);
    }
    case OP_MUX_OPEN: {                    /* L2: channel activation   */
        if (PROTO_L_LEVEL < 2) {
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_CHANNEL;
            return send_msg(s, fd, &r);
        }
        /* an open on the CONTROL channel means the peer never saw the
         * grant (corruptreply/delay can eat it): re-announce instead
         * of erroring -- bootstrap is idempotent, like C9's ERR-retry */
        if (m->chan == PROTO_L_CHAN_BASE && !s->mux_opened) {
            proto_vlog(s, "mux_regrant_bootstrap chan=%d",
                       s->chan_active);
            if ((s->chaos_once & PROTO_CHAOS_BIT_ECHAN)
                && !(s->chaos_once & PROTO_CHAOS_BIT_ECHAN_R)) {
                /* C18 recovery observed: the client asked the
                 * control channel for a re-announce after the silent
                 * channel move                                    */
                s->chaos_once |= PROTO_CHAOS_BIT_ECHAN_R;
                proto_vlog(s, "chaos_errchannel_recovered=1");
            }
            return send_mux_ack(s, fd, s->chan_active, 0);
        }
        if (m->chan != s->chan_active) {
            r.opcode = OP_ERR;
            r.ints[0] = PROTO_ERR_CHANNEL;
            return send_msg(s, fd, &r);
        }
        /* (re)open on the active channel: an ack to our open, or the
         * idempotent retransmission of one whose ack was corrupted.
         * The ack ALWAYS carries the granted credit (nonzero) -- that
         * is the wire discriminator against a channel GRANT          */
        s->mux_opened = 1;
        s->credit = PROTO_L_CREDIT_INIT;
        if ((s->chaos_once & PROTO_CHAOS_BIT_ECREDIT)
            && !(s->chaos_once & PROTO_CHAOS_BIT_ECREDIT_R)) {
            /* C17 recovery observed: the window was refilled via
             * MUX_OPEN after the silent zeroing                  */
            s->chaos_once |= PROTO_CHAOS_BIT_ECREDIT_R;
            proto_vlog(s, "chaos_errcredit_recovered=1");
        }
        proto_vlog(s, "mux_open chan=%d credit=%d",
                   s->chan_active, s->credit);
        /* the OPEN-ack rides the channel being opened (the grant rode
         * the control channel; mixing them makes the client treat the
         * ack as another grant and wedge the open state)           */
        s->chan = s->chan_active;
        return send_mux_ack(s, fd, s->chan_active, s->credit);
    }
    case OP_STAT: {                        /* X2 decoy                */
        r.opcode = OP_STAT_RES;
        {
            char fmt[24];
            px_strdec(fmt, LIT_STATFMT, sizeof LIT_STATFMT);
            snprintf(r.strs[0], PROTO_STR_MAX, fmt,
                     (unsigned long long)(prng_next(s) % 9999));
        }
        return send_msg(s, fd, &r);
    }
    case OP_BYE: {
        int sr;
        proto_vlog(s, "cmd op=BYE crypt=%d",
                   s->diag ? s->diag->crypt_ok : -1);
        r.opcode = OP_BYE_ACK;
        r.ints[0] = 0;
        if (PROTO_S_LEVEL >= 7) {
            /* hand the peer a single-use resumption token (S7)     */
            uint8_t token[16];
            px_resume_material(s, s->resume_secret, token);
            resume_store(token, s->resume_secret);
            {
                const proto_schema_t *bs = ps_schema_for(OP_BYE_ACK);
                int tslot = ps_sem_slot(bs, PSEM_TOKEN, 0);
                if (tslot >= 0) memcpy(r.blobs[tslot], token, 16);
            }
        }
        sr = send_msg(s, fd, &r);
        return sr == 0 ? 1 : -1;                     /* close         */
    }
    default:
        if (PROTO_X_LEVEL >= 6) {
            /* X6 responsive decoy: an unknown opcode is answered with
             * a plausible VALUE-shaped frame instead of an ERR -- an
             * agent probing the opcode space cannot tell discovery
             * from decoy without checking semantics            */
            const proto_schema_t *vs = ps_schema_for(OP_SUM_RES);
            r.opcode = OP_SUM_RES;
            if (vs != NULL) {
                r.ints[0] = prng_next(s) & 0xFFFF;
                r.ints[1] = prng_next(s) & 0xFF;
            }
            return send_msg(s, fd, &r);
        }
        r.opcode = OP_ERR;
        r.ints[0] = PROTO_ERR_UNKNOWN;
        proto_vlog(s, "dispatch-unknown op=%02x state=%d chan=%d "
                     "act=%d", m->opcode, s->state, s->chan,
                     s->chan_active);
        return send_msg(s, fd, &r);
    }
}

/* ------------------------------------------------------------------ */
/* server connection loop                                              */
/* ------------------------------------------------------------------ */
static int g_conn_seq = 0;
static pthread_mutex_t g_conn_seq_mu = PTHREAD_MUTEX_INITIALIZER;

static int next_conn_id(void) {
    int id;
    pthread_mutex_lock(&g_conn_seq_mu);
    id = ++g_conn_seq;
    pthread_mutex_unlock(&g_conn_seq_mu);
    return id;
}

/* post-BYE drain: half-close our side, then watch how the PEER closes.
 * A client that read the ACK then closed sends FIN (fin=1); one that
 * closed with the ACK still buffered sends RST (rst=1). Both feed the
 * ⑤ clean-close element.                                            */
static void drain_peer_close(int cfd, int *fin, int *rst) {
    struct timeval tv = {2, 0};
    uint8_t sink[512];
    shutdown(cfd, SHUT_WR);
    setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    for (;;) {
        ssize_t r = read(cfd, sink, sizeof sink);
        if (r == 0) { *fin = 1; return; }
        if (r < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) return;
            *rst = (errno == ECONNRESET);
            return;
        }
    }
}

/* ------------------------------------------------------------------ */
/* T1: UDP server loop -- one socket, a (peer-address)->session slot   */
/* table, datagram dispatch. State per slot mirrors a connection;     */
/* loss tolerance rides the client's existing retransmission path    */
/* ------------------------------------------------------------------ */
#define PROTO_UDP_SLOTS 8
int proto_serve_udp(int fd) {
    static proto_session_t slots[PROTO_UDP_SLOTS];
    static proto_reader_t readers[PROTO_UDP_SLOTS];
    static proto_diag_t diags[PROTO_UDP_SLOTS];
    static struct sockaddr_in addrs[PROTO_UDP_SLOTS];
    static int inited = 0;
    uint8_t inbuf[4096];
    int i;

    if (!inited) {
        memset(slots, 0, sizeof slots);
        memset(readers, 0, sizeof readers);
        memset(diags, 0, sizeof diags);
        memset(addrs, 0, sizeof addrs);
        inited = 1;
        if (proto_vlog_enabled())
            for (i = 0; i < PROTO_UDP_SLOTS; i++) {
                diags[i].active = 1;
                slots[i].diag = &diags[i];
            }
    }
    for (;;) {
        struct sockaddr_in from;
        socklen_t flen = sizeof from;
        ssize_t r = recvfrom(fd, inbuf, sizeof inbuf, 0,
                             (struct sockaddr *)&from, &flen);
        int slot = -1;
        if (r < 0) {
            if (errno == EINTR) continue;
            break;
        }
        /* find (or open) the peer's slot */
        for (i = 0; i < PROTO_UDP_SLOTS; i++)
            if (addrs[i].sin_port != 0
                && addrs[i].sin_addr.s_addr == from.sin_addr.s_addr
                && addrs[i].sin_port == from.sin_port)
                { slot = i; break; }
        if (slot < 0) {
            for (i = 0; i < PROTO_UDP_SLOTS; i++)
                if (addrs[i].sin_port == 0) { slot = i; break; }
            if (slot < 0)
                continue;                  /* table full: drop (the peer
                                             * retransmits)             */
            px_session_init(&slots[slot], 1);
            memset(&readers[slot], 0, sizeof readers[slot]);
            slots[slot].diag = &diags[slot];   /* init wiped the pointer */
            slots[slot].state = ps_fsm_entry();
            slots[slot].state_enter_ms = now_ms();
            slots[slot].chan = slots[slot].chan_active =
                (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
            if (PROTO_L_LEVEL < 3) slots[slot].credit = 1 << 30;
            slots[slot].is_udp = 1;
            slots[slot].conn_id = next_conn_id();
            addrs[slot] = from;
        }
        slots[slot].peer = from;
        slots[slot].is_udp = 1;
        {
            const uint8_t *p = inbuf;
            size_t pending = (size_t)r;
            for (;;) {
                proto_msg_t m;
                int rc = pf_reader_feed(&slots[slot], &readers[slot],
                                        p, pending, &m);
                p = NULL; pending = 0;               /* drain mode    */
                if (rc == 0) break;
                if (rc < 0) {
                    if (readers[slot].x3_len == 0
                        && readers[slot].len == 0) break;
                    continue;
                }
                {
                    int hrc = handle_message(&slots[slot], fd, &m);
                    if (hrc == 1 || hrc == 2) {
                        /* BYE (or the chaos drop): retire the slot --
                         * the peer's reconnect opens a FRESH session
                         * (fresh nonce), which is the C12 contract.
                         * The BYE retirement carries the same close
                         * milestone the TCP loop emits (fin/rst are the
                         * PROTOCOL-level session end here: an ACK'd,
                         * orderly termination -- there is no TCP FIN on
                         * a datagram transport to observe)           */
                        if (hrc == 1)
                            proto_vlog(&slots[slot],
                                       "close bye=1 fin=1 rst=0 "
                                       "sendfail=0 chaos=%s bits=%d "
                                       "cmds=%d",
                                       proto_chaos_name(
                                           proto_chaos_mode()),
                                       slots[slot].chaos_once,
                                       slots[slot].chaos_cmds);
                        addrs[slot].sin_port = 0;
                        break;
                    }
                    if (hrc < 0) {
                        addrs[slot].sin_port = 0;
                        break;
                    }
                    /* T2: receiver-acknowledged datagrams (the CoAP
                     * CON shape): every ACCEPTED request earns an ACK
                     * datagram echoing its proof sequence -- sent AFTER
                     * the reply so the chaos fault modes keep hitting
                     * the reply itself, and the client (which never
                     * waits for one) just skips them            */
                    if (PROTO_T_LEVEL == 2) {
                        proto_msg_t ack;
                        memset(&ack, 0, sizeof ack);
                        ack.opcode = OP_ACK;
                        ack.ints[0] = (uint64_t)slots[slot].peer_seq;
                        (void)send_msg(&slots[slot], fd, &ack);
                    }
                }
            }
        }
    }
    return 0;
}

int proto_serve_connection(int cfd) {
    proto_session_t s;
    proto_reader_t rd;
    proto_diag_t diag;
    uint8_t inbuf[4096];
    int fin = 0, rst = 0, sendfail = 0, bye = 0;

    px_session_init(&s, 1);
    memset(&rd, 0, sizeof rd);
    memset(&diag, 0, sizeof diag);
    s.conn_id = next_conn_id();
    s.diag = &diag;
    diag.active = proto_vlog_enabled();
    s.state = ps_fsm_entry(); s.state_enter_ms = now_ms();
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30;   /* unlimited */
    if (PROTO_S_LEVEL >= 4) {
        /* S4 heartbeat contract: a peer silent past the watchdog is
         * dropped -- the client pings every command round. The window
         * sits ABOVE the 10s client read timeout, so retransmission
         * waits (corruptreply et al.) never trip it.              */
        struct timeval tv = {PROTO_S_WATCHDOG, 0};
        setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    }

    for (;;) {
        ssize_t r = read(cfd, inbuf, sizeof inbuf);
        if (r == 0) { fin = 1; break; }
        if (r < 0) {
            if (errno == EINTR) continue;
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                proto_vlog(&s, "s4_watchdog_drop=1");
                break;
            }
            rst = (errno == ECONNRESET);
            break;
        }
        {
            const uint8_t *p = inbuf;
            size_t pending = (size_t)r;
            for (;;) {
                proto_msg_t m;
                int rc = pf_reader_feed(&s, &rd, p, pending, &m);
                p = NULL; pending = 0;               /* drain mode    */
                if (rc == 0) break;
                if (rc < 0) {
                    if (rd.x3_len == 0 && rd.len == 0) break;
                    continue;
                }
                {
                    int hrc = handle_message(&s, cfd, &m);
                    if (hrc == 2) {          /* chaos drop: no BYE    */
                        proto_vlog(&s, "close dropped=1 fin=%d rst=%d "
                                     "sendfail=0 chaos=%s bits=%d "
                                     "cmds=%d",
                                     fin, rst,
                                     proto_chaos_name(proto_chaos_mode()),
                                     s.chaos_once, s.chaos_cmds);
                        close(cfd);
                        return 0;
                    }
                    if (hrc == 1) {          /* BYE: ACK already sent */
                        bye = 1;
                        drain_peer_close(cfd, &fin, &rst);
                        proto_vlog(&s, "close bye=1 fin=%d rst=%d "
                                     "sendfail=0 chaos=%s bits=%d "
                                     "cmds=%d",
                                     fin, rst,
                                     proto_chaos_name(proto_chaos_mode()),
                                     s.chaos_once, s.chaos_cmds);
                        close(cfd);
                        return 0;
                    }
                    if (hrc < 0) { sendfail = 1; goto done; }
                }
            }
        }
    }
done:
    proto_vlog(&s, "close bye=%d fin=%d rst=%d sendfail=%d chaos=%s "
                 "bits=%d cmds=%d",
               bye, fin, rst, sendfail,
               proto_chaos_name(proto_chaos_mode()),
               s.chaos_once, s.chaos_cmds);
    close(cfd);
    return 0;
}

/* ------------------------------------------------------------------ */
/* hidden carrier entry                                                */
/* ------------------------------------------------------------------ */
int proto_server_entry(int argc, char **argv, const char *applet) {
    int port;
    int lfd;
    char mode[16];
    /* the entry flag is decoded at use: `strings /app/binary` must not
     * hand over the hidden mode for free                              */
    px_strdec(mode, LIT_MODE, sizeof LIT_MODE);
    if (argc < 3 || strcmp(argv[1], mode))
        return 0;
    /* faulted self-test runs (the disclosed --chaos modes) drop
     * sockets mid-write: EPIPE must be an error, not a kill        */
    signal(SIGPIPE, SIG_IGN);
    port = atoi(argv[2]);
    if (port <= 0 || port > 65535)
        port = PROTO_DEFAULT_PORT;
    /* optional third token: the chaos self-test flag (instruction.md
     * discloses the fault NAMES; an agent can fault its own local
     * instance and practice against it -- that parity is the point) */
    if (argc >= 5) {
        char chaos[16];
        px_strdec(chaos, LIT_CHAOS, sizeof LIT_CHAOS);
        if (strcmp(argv[3], chaos) == 0)
            proto_chaos_set(argv[4]);
    }
    (void)applet;
#ifdef PROTO_HOST_MATERIAL
    /* host-bound carrier build only: the wire material boots from the
     * carrier's REAL state (config parser + host database subsystem)
     * before the listener exists. GT/oracle builds take the full
     * proto_config.h definitions and never call this. ast_proto_boot
     * never fails loudly -- missing or tampered host state, or a
     * detected tracer, yields poisoned material instead, and the
     * engine then speaks a self-consistent wrong dialect
     * (reference/host-binding.md).                                 */
    {
        extern int ast_proto_boot(void);
        (void)ast_proto_boot();
    }
#endif
    /* braced dispatch: the binary-concealment anti-debug layer anchors
     * its check at the FIRST pc_full_tcp_listen call LINE -- a ternary
     * would leave that call mid-expression and the injected statement
     * block would split it (CIL syntax error at the O4 build)        */
    lfd = -1;
    if (PROTO_T_LEVEL == 1) {
        lfd = pc_udp_listen(port);
    } else if (PROTO_T_LEVEL == 3) {
        lfd = pc_unix_listen(PROTO_UNIX_PATH);
    } else {
        lfd = pc_full_tcp_listen(port);
    }
    if (lfd < 0) return 1;
    if (PROTO_T_LEVEL == 1)
        return proto_serve_udp(lfd);
    for (;;) {
        int cfd = accept(lfd, NULL, NULL);
        if (cfd >= 0 && PROTO_T_LEVEL == 4
            && pc_ws_server_handshake(cfd) != 0) {
            close(cfd);           /* botched upgrade: not a ws client */
            cfd = -1;
        }
        if (cfd < 0) {
            if (errno == EINTR) continue;
            break;
        }
        proto_serve_connection(cfd);
    }
    return 0;
}
