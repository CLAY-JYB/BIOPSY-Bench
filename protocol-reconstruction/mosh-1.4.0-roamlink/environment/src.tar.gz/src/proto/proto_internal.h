/* proto_internal.h -- internal cross-module API (not injected).
 *
 * The session context threads through every axis module:
 *
 *   encode (E) -> mask (X2) -> encrypt (C) -> frame (F) -> wrap (X3)
 *   [wire]  unwrap (X3) -> deframe (F, drop chaff) -> decrypt (C)
 *         -> unmask (X2) -> decode (E) -> state machine (S)
 */

#ifndef PROTO_INTERNAL_H
#define PROTO_INTERNAL_H

#include "protocol.h"
#include <stdint.h>
#include <stddef.h>
#include <sys/socket.h>
#include <netinet/in.h>

/* proto_client.c (solve-side client TU, NOT part of the carrier-linked
 * protocol.c amalgamation) shares these session helpers through this
 * header; everything below is engine-internal and hidden-linked. */

/* states (S axis switches which are reachable) */
enum {
    PST_CLOSED = 0,
    PST_WAIT_HELLO,
    PST_WAIT_PARAMS,      /* S3 only                       */
    PST_WAIT_AUTH,
    PST_SESSION,
    PST_RESYNC            /* S3 error recovery             */
};

/* per-frame diagnostics (oracle-side FORMAT logging; see the chaos
 * block below for context). Declared here: proto_session_t carries a
 * pointer to one.                                                     */
typedef struct {
    int active;          /* env-provided log sink present               */
    int candidate;       /* a plausible frame start was observed        */
    int boundary;        /* F5 flag pair / framing delimiter found      */
    int magic;           /* magic bytes match                           */
    int version;         /* version byte/field matches                  */
    int length_ok;       /* length field sane (fits, frame complete)    */
    int crc_ok;          /* F4/F5 checksum verified                     */
    int proof_ok;        /* X1 proof verified                            */
    int crypt_ok;        /* C-layer tag verified                        */
    int decode_ok;       /* payload decoded against its schema          */
    int dual_plain;      /* C-layer failed but the payload decodes as
                          * PLAINTEXT (grammar without crypto)          */
    int opcode_seen;     /* raw opcode byte of the frame (-1 unknown)   */
} proto_diag_t;

typedef struct {
    /* per-connection identity (randomized per run -> anti-replay) */
    uint64_t rng;                 /* xorshift, seeded /dev/urandom  */
    uint32_t session_id;
    /* X1: server nonce + proof material                           */
    uint8_t nonce[16];
    uint8_t mask_key[32];         /* X2: HKDF(nonce,"mask")         */
    /* S2: sequencing                                              */
    uint64_t my_seq, peer_seq;
    int      authed;
    int      nonce_live;   /* proofs bind the nonce only once both
                           * sides hold it (after HELLO/HELLO_ACK)  */
    int      state;
    /* C3: derived direction keys                                  */
    uint8_t tx_key[32], rx_key[32];
    uint8_t tx_iv[8], rx_iv[8];
    uint64_t tx_ctr, rx_ctr;
    int      is_server;
    /* T (transport): UDP sessions carry their peer address; every
     * emission goes through pf_send_raw, which routes connected-TCP
     * writes and UDP sendto() through one seam                    */
    int      is_udp;
    struct sockaddr_in peer;
    /* L (multiplex): the channel THIS side writes on, the channel the
     * session's commands are valid on, per-channel wire sequence, the
     * granted credit window and the open/refill bookkeeping           */
    int      chan;         /* write channel (bg frames override)        */
    int      chan_active;  /* command channel (grant moves it, L2)      */
    uint8_t  chan_last[8]; /* last per-channel seq SENT (wrap index)    */
    int      credit;       /* L3: remaining credit on this side         */
    int      auth_fails;   /* S: failed AUTH attempts (retry budget)   */
    /* S5-S7: re-auth bookkeeping, transaction snapshot handle and the
     * session-resumption material (token + secret, client side)     */
    int      reauth_done;  /* S5: the one mid-session re-auth fired     */
    int      txn_open;     /* S6: a transaction group is open           */
    /* S6 KV snapshot (32 entries x kv_t, copied wholesale at BEGIN;
     * sized via PROTO_STR_MAX so internal.h stays self-contained) */
    uint8_t  txn_snap[32 * (PROTO_STR_MAX + 16)];
    int      has_resume;   /* S7: we hold a resumption token            */
    uint8_t  resume_token[16];
    uint8_t  resume_secret[32];
    uint8_t  server_pub[32];     /* captured at HELLO_ACK (C_KEX)     */
    int      have_server_pub;
    int      mux_opened;   /* L2: active channel opened via MUX_OPEN    */
    int      mux_wait_open;/* client: an MUX_OPEN is awaiting its ack   */
    int      mux_regranted;/* L2: one mid-session channel re-grant done */
    int      bg_ctr;       /* interleave cadence counter (server)       */
    /* oracle-side diagnostics + attribution (never set by the carrier
     * build; see proto_diag_t above)                                   */
    proto_diag_t *diag;
    int      conn_id;    /* oracle connection counter (log lines)       */
    int      chaos_once; /* per-connection one-shot chaos bookkeeping   */
    int      chaos_cmds; /* session commands served (chaos triggers)    */
} proto_session_t;

/* --------------------------------------------------------------------
 * chaos modes (verifier robustness battery, reference/scoring.md).
 * A chaos run is ONE fault injected into an otherwise clean server --
 * the oracle (and, for parity, the carrier's hidden entry) accepts
 * `--chaos <name>`; mode NONE leaves the engine byte-for-byte on its
 * normal paths. The names are DISCLOSED to the agent (instruction.md):
 * self-testing against a faulted local instance is part of the skill.
 * ------------------------------------------------------------------ */
enum {
    PROTO_CHAOS_NONE = 0,
    PROTO_CHAOS_CHAFFBURST,    /* C1  chaff burst after each reply       */
    PROTO_CHAOS_CORRUPTREPLY,  /* C2  CRC-corrupt one reply (retry test) */
    PROTO_CHAOS_MINFRAG,       /* C3  X3 chunks shrunk to 1 byte         */
    PROTO_CHAOS_ESCAPEDENSE,   /* C4  escape-dense chaff on the wire     */
    PROTO_CHAOS_NOISE,         /* C5  junk bytes before each reply       */
    PROTO_CHAOS_RESYNC,        /* C6  force RESYNC mid-session           */
    PROTO_CHAOS_DELAY,         /* C7  one 5s-slow reply                  */
    PROTO_CHAOS_DRIP,          /* C8  replies drip-fed 1B/10ms           */
    PROTO_CHAOS_ERRHELLO,      /* C9  ERR to the first valid HELLO       */
    PROTO_CHAOS_BADLEN,        /* C11 hostile length field ahead of the
                                  real reply                            */
    PROTO_CHAOS_DROP,          /* C12 server drops the connection once   */
    PROTO_CHAOS_DUPREPLY       /* C13 one reply sent twice               */
};
/* parse/lookup; proto_chaos_set returns 0 on a known name (also sets
 * the process-global mode), -1 on an unknown one                    */
PROTO_API int       proto_chaos_set(const char *name);
/* level applicability of a chaos mode (mirrors the verifier probe table
 * in reference/scoring.md): inapplicable probes are skipped by the
 * selftest battery AND become no-ops in the injection paths, so edge
 * level combinations (S2 without a RESYNC state, F0 without any
 * integrity point to scan to) generate and gate cleanly            */
PROTO_API int       proto_chaos_applicable(int mode);

/* knob-composed F3/F4 header layout (proto_frame.c) -- shared with the
 * chaff/fault builders in proto_conceal.c so decoys carry the seeded
 * wire shape, not the historical fixed offsets                   */
PROTO_API int pf_f3_hdrlen(void);
PROTO_API int pf_f3_op_off(void);
/* L>=1 layout extension: [chan CHAN_W bytes][chan_seq 1 byte] between
 * the opcode and the length field (zero-width at L0 -- the helpers
 * then collapse and the header is identical to the L0 shape)       */
PROTO_API int pf_f3_chan_w(void);
PROTO_API int pf_f3_chan_off(void);
PROTO_API int pf_f3_seq_off(void);
PROTO_API int pf_f3_len_off(void);
PROTO_API int pf_f3_len_width(void);
PROTO_API void pf_put_u(uint8_t *p, uint64_t v, int w);
/* F6 COBS stuffing -- shared with the chaff builders so decoys carry
 * the delimiter-terminated shape the F6 reader expects              */
PROTO_API size_t pf_cobs_encode(const uint8_t *in, size_t n, uint8_t *out,
                                size_t cap);

/* compression axis (M): per-message payload transform between the
 * encoder (E) and the proof/mask/crypto stack (proto_compress.c)     */
PROTO_API size_t pm_compress(const uint8_t *in, size_t n, uint8_t *out,
                             size_t cap);
PROTO_API size_t pm_decompress(const uint8_t *in, size_t n, uint8_t *out,
                               size_t cap);

/* T (transport) seam: every raw emission funnels here -- write() on a
 * connected TCP socket, sendto(peer) on a UDP session (proto_frame.c) */
PROTO_API int pf_send_raw(proto_session_t *s, int fd, const uint8_t *buf,
                          size_t n);
/* UDP server loop: one socket, a (addr)->session slot table, datagram
 * dispatch (proto_core.c); the TCP path stays proto_serve_connection */
PROTO_API int proto_serve_udp(int fd);
/* T (transport) connect/listen helpers (proto_core.c): T3 binds a unix
 * domain stream socket at the seeded path; T4 rides TCP but speaks the
 * RFC 6455 upgrade + record layer (proto_crypto.c supplies sha1/b64) */
PROTO_API int pc_unix_listen(const char *path);
PROTO_API int pc_unix_connect(const char *path);
PROTO_API int pc_ws_connect(const char *host, int port);
PROTO_API int pc_ws_server_handshake(int fd);
PROTO_API int       proto_chaos_mode(void);
PROTO_API const char *proto_chaos_name(int mode);

/* per-connection one-shot bookkeeping (session.chaos_once bits)      */
#define PROTO_CHAOS_BIT_CORRUPT    0x01  /* corrupt reply sent        */
#define PROTO_CHAOS_BIT_DELAY      0x02  /* slow reply sent           */
#define PROTO_CHAOS_BIT_DUP        0x04  /* duplicate reply sent      */
#define PROTO_CHAOS_BIT_BADLEN     0x08  /* hostile length sent       */
#define PROTO_CHAOS_BIT_ERRHELLO   0x10  /* ERR-on-valid-HELLO sent   */
#define PROTO_CHAOS_BIT_RESYNC     0x20  /* forced resync sent        */
#define PROTO_CHAOS_BIT_DROP       0x40  /* connection dropped        */
#define PROTO_CHAOS_BIT_RETRANS    0x80  /* client retried after it   */

/* proto_frame.c ----------------------------------------------------- */
PROTO_API int  pf_build(proto_session_t *s, const proto_msg_t *m,
                        uint8_t *out, size_t cap);
/* feed stream bytes; 1 = message decoded into *out, 0 = need more,
 * -1 = stream error (caller may drop this frame's bytes)          */
typedef struct {
    uint8_t  buf[8192];            /* frame-parse accumulation       */
    size_t   len;
    uint8_t  frag[8192];          /* F5 fragment reassembly         */
    size_t   frag_len;
    int      in_frag;
    uint8_t  x3[8192];            /* X3 transport defragmentation   */
    size_t   x3_len;
    int      x3_last;             /* saw the LAST flag              */
    uint8_t  ws[8216];            /* T4 websocket record assembly   */
    size_t   ws_len;
} proto_reader_t;

PROTO_API int  pf_reader_feed(proto_session_t *s, proto_reader_t *r,
                              const uint8_t *data, size_t n,
                              proto_msg_t *out);

PROTO_API int  pf_write_msg(proto_session_t *s, int fd,
                            const proto_msg_t *m);

/* proto_conceal.c --------------------------------------------------- */
PROTO_API void px_session_init(proto_session_t *s, int is_server);
PROTO_API void px_client_set_nonce(proto_session_t *s, const uint8_t *nonce);
/* per-message transforms (applied inside pf_build / reader)        */
PROTO_API void px_mask(uint8_t *buf, size_t n, const proto_session_t *s);
/* B-package frame-material binding (2026-09-19): the wire magic and the
 * CRC seed/xor-out are the STATIC per-task constants only until the
 * session nonce is live (the X1 binding rail); afterwards both roll
 * per connection off the nonce-derived mask key -- a captured local
 * exchange no longer generalizes to the verifier's fresh oracle    */
PROTO_API void px_frame_material_dir(const proto_session_t *s,
                                     int is_server, uint8_t magic_out[4],
                                     uint32_t *crc_seed,
                                     uint32_t *crc_post);
/* per-frame variant: seq > 0 additionally folds the header sequence
 * byte into the magic (no repeating prefix across a capture)       */
PROTO_API void px_frame_material_seq(const proto_session_t *s,
                                     int is_server, unsigned seq,
                                     uint8_t magic_out[4],
                                     uint32_t *crc_seed,
                                     uint32_t *crc_post);
PROTO_API void px_frame_material(const proto_session_t *s,
                                 uint8_t magic_out[4],
                                 uint32_t *crc_seed, uint32_t *crc_post);
/* X2: chaff injection (called by pf_write_msg)                     */
PROTO_API int  px_maybe_chaff(proto_session_t *s, int fd);
/* X1: anti-replay proof / verify over payload (truncation width is
 * the seeded PROTO_PROOF_TRUNC knob; buffers carry the max 16)      */
PROTO_API void px_proof(const proto_session_t *s, uint64_t seq,
                        const uint8_t *body, size_t n, uint8_t out[16]);
PROTO_API int  px_verify(const proto_session_t *s, uint64_t seq,
                         const uint8_t *body, size_t n,
                         const uint8_t proof[16]);
/* X3: transport fragmentation / mimicry                            */
PROTO_API int  px_frag_write(proto_session_t *s, int fd,
                             const uint8_t *buf, size_t n);
PROTO_API int  px_frag_write_sized(proto_session_t *s, int fd,
                                   const uint8_t *buf, size_t n,
                                   size_t chunk_cap);
/* chaos: the faulted server write path (called by pf_write_msg when
 * a chaos mode is active and the session is server-side)           */
PROTO_API int  px_chaos_wire(proto_session_t *s, int fd,
                             const uint8_t *wire, size_t n);
PROTO_API int  px_defrag_feed(proto_reader_t *r, const uint8_t *data,
                              size_t n, int *complete, uint8_t *chunk,
                              size_t *chunk_len);
PROTO_API void px_wrap_mimicry(uint8_t *buf, size_t *n, size_t cap);
PROTO_API int  px_unwrap_mimicry(uint8_t *buf, size_t *n);
/* decode an engine-internal literal (XOR-obfuscated at rest so no
 * grep-able plaintext rides in .rodata: entry flags, milestone env
 * names, protocol tags). out receives n bytes + NUL; cap >= n + 1. */
PROTO_API void px_strdec(char *out, const uint8_t *enc, size_t n);

/* proto_state.c ----------------------------------------------------- */
/* The schema registry is stored XOR-encoded and split across two
 * arrays (proto_config.h); these accessors decode ONE schema at a
 * time into internal scratch storage. The returned pointer is valid
 * until the NEXT ps_* call -- never hold two schema pointers at once
 * (call sites never do; pe_encode/pe_decode walk the schema they are
 * handed without re-entering ps_*). */
PROTO_API const proto_schema_t *ps_schema_for(int opcode);
PROTO_API const proto_schema_t *ps_schema_by_index(int idx); /* NULL at end */
PROTO_API const proto_schema_t *ps_schema_by_lead(const uint8_t *body,
                                                  size_t n);
/* field-slot lookup by semantic (nth occurrence, -1 if absent) --
 * blob/str/int slots are indexed by schema field position, which
 * varies with the level combination                              */
PROTO_API int  ps_sem_slot(const proto_schema_t *sch, int sem,
                           int occurrence);
/* server-side transition check: allowed(state, opcode)?            */
PROTO_API int  ps_server_allow(const proto_session_t *s, int opcode);
PROTO_API int  ps_server_step(proto_session_t *s, int opcode);

/* proto_crypto.c ---------------------------------------------------- */
/* crypto axis since the 2026-10 private-family rebuild: one seeded ARX
 * family (hash = MAC = KDF base, stream, CBC Feistel, MODP KEX) plus
 * the C1 XOR keystream. The only published primitives left are the
 * SHA-1 + base64 the T4 websocket MIMICRY handshake must compute to
 * be a credible RFC 6455 peer -- they never touch task crypto.     */
PROTO_API void pc_xor_crypt(const uint8_t *key, size_t keylen,
                            uint8_t *buf, size_t n);
PROTO_API size_t pc_prv_cbc(const uint8_t key[16], const uint8_t iv[8],
                            int rounds, int encrypt,
                            uint8_t *buf, size_t n);
/* T4 websocket handshake primitives (FIPS 180-1 / RFC 4648)        */
PROTO_API void pc_sha1(const uint8_t *p, size_t n, uint8_t out[20]);
PROTO_API size_t pc_b64_encode(const uint8_t *in, size_t n, char *out,
                               size_t cap);
/* private primitive family (2026-10-04): seeded ARX hash (doubles as
 * MAC/KDF base), seeded ARX counter stream, seeded MODP DH. See the
 * family block in proto_crypto.c for the construction contract      */
PROTO_API void pc_prv_hash(const uint8_t *seed, size_t seedlen,
                           const void *data, size_t n, uint8_t out[32]);
PROTO_API void pc_prv_kdf(const uint8_t *salt, size_t saltlen,
                          const uint8_t *ikm, size_t ikmlen,
                          const char *label, uint8_t out[32]);
PROTO_API void pc_prv_stream(const uint8_t key[32], const uint8_t iv[8],
                             uint64_t ctr, uint8_t *buf, size_t n);
PROTO_API int pc_prv_pub(uint8_t *pub, const uint8_t *priv,
                         size_t privlen);
PROTO_API int pc_prv_shared(uint8_t *out, const uint8_t *priv,
                            size_t privlen,
                            const uint8_t peer[PROTO_PRV_P_BYTES]);

/* proto_encode.c ---------------------------------------------------- */
PROTO_API int pe_encode(const proto_schema_t *sch, const proto_msg_t *m,
                        uint8_t *out, size_t cap,
                        int spans[PROTO_MAX_FIELDS][2]);
PROTO_API int pe_decode(const proto_schema_t *sch, const uint8_t *in,
                        size_t n, proto_msg_t *m);
PROTO_API int pe_example(const proto_schema_t *sch, uint8_t *out,
                         size_t cap, int spans[PROTO_MAX_FIELDS][2]);

/* proto_core.c ------------------------------------------------------ */
/* conn-attributed diagnostic log (same sink + secret as the milestone
 * lines; no-ops unless the oracle's env asks for it)                */
PROTO_API void proto_vlog(const proto_session_t *s, const char *fmt, ...);
PROTO_API int  proto_vlog_enabled(void);
PROTO_API uint64_t prng_next(proto_session_t *s);
PROTO_API void     prng_seed(proto_session_t *s);
PROTO_API int      pc_full_tcp_connect(const char *host, int port);
PROTO_API int      pc_full_tcp_listen(int port);
PROTO_API int      pc_udp_connect(const char *host, int port);
PROTO_API int      pc_udp_listen(int port);
/* session helpers shared with the solve-side client TU (proto_client.c):
 * the server path uses them too, so nothing client-only rides into the
 * challenge binary by exporting them                                  */
PROTO_API void px_auth_mac(const proto_session_t *s, uint8_t out[16]);
PROTO_API void px_resume_material(const proto_session_t *s,
                                  uint8_t secret[32], uint8_t token[16]);
PROTO_API void px_resume_mac(const uint8_t secret[32],
                             const proto_session_t *s, uint8_t out[16]);
PROTO_API uint32_t px_flag_token(const proto_session_t *s,
                                 const char *label);
PROTO_API void px_derive_direction_keys(const uint8_t shared[32],
                                        const uint8_t nonce[16],
                                        uint8_t c2s[32], uint8_t s2c[32],
                                        uint8_t c2s_iv[8],
                                        uint8_t s2c_iv[8]);

#endif /* PROTO_INTERNAL_H */
