/* oracle_server.c -- verifier-side oracle entry (tests image).
 *
 * Serves the generated protocol on loopback with milestone logging
 * enabled (PROTO_MILESTONE_LOG), so tests/test.sh can score the
 * ladder AND the per-frame/chaos diagnostics from observable
 * server-side events.
 *
 * Connections serve on their own thread: the robustness battery runs
 * concurrent client sessions (the C10 probe) and reconnect sequences
 * (C12); the engine's per-connection state is thread-local by design
 * (per-connection session struct, __thread schema scratch and KV
 * store).
 *
 * Build: cc oracle_server.c protocol.c -o oracle_server -lpthread
 * Run:   PROTO_MILESTONE_LOG=/tmp/ms PROTO_MILESTONE_SECRET=x \
 *        oracle_server PORT [--chaos NAME]
 *        (lines land as "<secret> conn=<id> <text>")
 */

#define _GNU_SOURCE
#include "proto_config.h"
#include "proto_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>

typedef struct {
    int fd;
} conn_arg_t;

static void *conn_thread(void *vp) {
    conn_arg_t *ca = vp;
    int cfd = ca->fd;
    free(ca);
    if (PROTO_T_LEVEL == 4 && pc_ws_server_handshake(cfd) != 0) {
        close(cfd);                /* botched upgrade: not a ws client */
        return NULL;
    }
    proto_serve_connection(cfd);
    return NULL;
}

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 0;   /* 0 = ephemeral */
    struct sockaddr_in sa;
    socklen_t sl = sizeof sa;
    int lfd;

    /* a peer that drops mid-write (the C12 fault, or any rude client)
     * must surface as -1/EPIPE, not kill the process             */
    signal(SIGPIPE, SIG_IGN);

    /* optional fault mode (verifier robustness battery; the names are
     * disclosed to the agent, who can practice against a faulted
     * local instance of the challenge binary the same way)         */
    if (argc >= 4 && !strcmp(argv[2], "--chaos")) {
        if (proto_chaos_set(argv[3]) != 0) {
            fprintf(stderr, "oracle: unknown chaos mode: %s\n", argv[3]);
            return 2;
        }
    }

    lfd = PROTO_T_LEVEL == 1 ? pc_udp_listen(port)
        : PROTO_T_LEVEL == 3 ? pc_unix_listen(PROTO_UNIX_PATH)
        : pc_full_tcp_listen(port);
    if (lfd < 0) {
        fprintf(stderr, "oracle: cannot listen on %d\n", port);
        return 1;
    }
    if (PROTO_T_LEVEL != 3) {
        if (getsockname(lfd, (struct sockaddr *)&sa, &sl) == 0)
            printf("LISTENING %d\n", ntohs(sa.sin_port));
    } else {
        printf("LISTENING %s\n", PROTO_UNIX_PATH);
    }
    fflush(stdout);
    if (PROTO_T_LEVEL == 1)
        return proto_serve_udp(lfd);
    for (;;) {
        int cfd = accept(lfd, NULL, NULL);
        pthread_t th;
        conn_arg_t *ca;
        if (cfd < 0) {
            if (errno == EINTR) continue;
            break;
        }
        ca = malloc(sizeof *ca);
        if (ca == NULL) {
            close(cfd);
            continue;
        }
        ca->fd = cfd;
        if (pthread_create(&th, NULL, conn_thread, ca) != 0) {
            /* fall back to sequential service rather than dropping */
            if (PROTO_T_LEVEL == 4
                && pc_ws_server_handshake(cfd) != 0) {
                close(cfd);
                continue;
            }
            proto_serve_connection(cfd);
            continue;
        }
        pthread_detach(th);
    }
    return 0;
}
