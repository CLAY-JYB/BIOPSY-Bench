/* proto_crypto.c -- crypto axis (C) primitives + shared hashes.
 *
 * Static asset, level-switched via proto_config.h:
 *   C1  fixed-key XOR keystream with the seeded key
 *   C2  RC4 stream cipher with the seeded key
 *   C3  X25519 key exchange -> HKDF-SHA256 key schedule -> ChaCha20
 *       encryption + HMAC-SHA256 authentication tag
 *
 * SHA-256 / HMAC / HKDF are always compiled (the X1 anti-replay proof
 * and the S>=2 challenge-response use them regardless of C level).
 *
 * The X25519 ladder follows the public-domain TweetNaCl reference shape;
 * the RFC 7748 Alice/Bob vectors are asserted in the selftest.
 */

#include <string.h>

/* ------------------------------------------------------------------ */
/* C1: fixed-key XOR keystream (involution: same op encrypts/decrypts) */
/* ------------------------------------------------------------------ */
void pc_xor_crypt(const uint8_t *key, size_t keylen,
                  uint8_t *buf, size_t n) {
    size_t i;
    for (i = 0; i < n; i++)
        buf[i] ^= key[i % keylen]
                  ^ (uint8_t)(i * PROTO_C1_MIX + i / 256);
}

/* ------------------------------------------------------------------ */
/* CBC block primitive: a private balanced Feistel over the 64-bit
 * block. The round function is the SAME seeded-ARX family as the
 * hash/stream/KEX primitives (rotation schedule and round salts from
 * the per-task tables), so the image carries one coherent private
 * family -- no published-cipher structure or constants ride along.
 * (The xtea_* config knob names are historical: they seed this
 * cipher's key/IV/round material.)                                 */
/* ------------------------------------------------------------------ */
static uint32_t prv_ffn(uint32_t x, uint32_t k0, uint32_t k1, int r) {
    x += k0;
    x ^= x << PROTO_PRV_ROTS(r, 0);
    x ^= x >> PROTO_PRV_ROTS(r, 1);
    x += k1;
    x ^= x << PROTO_PRV_ROTS(r, 2);
    x ^= x >> PROTO_PRV_ROTS(r, 3);
    return x;
}

static void prv_cbc_block(uint32_t v[2], const uint32_t k[4],
                          uint32_t rounds, int encrypt) {
    uint32_t a = v[0], b = v[1], i;
    for (i = 0; i < rounds; i++) {
        uint32_t r = encrypt ? i : rounds - 1 - i;
        if (!encrypt) { uint32_t t = a; a = b; b = t; }
        {
            uint32_t f = prv_ffn(b,
                                 k[r & 3] + PROTO_PRIV_IV_TAB[r & 7],
                                 k[(r + 2) & 3]
                                     ^ PROTO_PRIV_ROT_TAB[r & 31],
                                 (int)r);
            a ^= f;
        }
        if (encrypt) { uint32_t t = a; a = b; b = t; }
    }
    v[0] = a; v[1] = b;
}

/* XTEA-CBC with PKCS#7 padding: encrypt grows to a block multiple,
 * decrypt strips the pad. Returns the new length ((size_t)-1 bad). */
size_t pc_prv_cbc(const uint8_t key[16], const uint8_t iv[8],
                   int rounds, int encrypt,
                   uint8_t *buf, size_t n) {
    uint32_t k[4];
    size_t i;
    k[0] = ((uint32_t)key[0]<<24)|((uint32_t)key[1]<<16)|((uint32_t)key[2]<<8)|key[3];
    k[1] = ((uint32_t)key[4]<<24)|((uint32_t)key[5]<<16)|((uint32_t)key[6]<<8)|key[7];
    k[2] = ((uint32_t)key[8]<<24)|((uint32_t)key[9]<<16)|((uint32_t)key[10]<<8)|key[11];
    k[3] = ((uint32_t)key[12]<<24)|((uint32_t)key[13]<<16)|((uint32_t)key[14]<<8)|key[15];
    if (encrypt) {
        size_t pad = 8 - (n % 8);
        size_t total = n + pad, off;
        uint8_t prev[8];
        for (i = 0; i < pad; i++) buf[n + i] = (uint8_t)pad;
        memcpy(prev, iv, 8);
        for (off = 0; off < total; off += 8) {
            uint32_t v[2];
            for (i = 0; i < 8; i++) buf[off + i] ^= prev[i];
            v[0] = ((uint32_t)buf[off]<<24)|((uint32_t)buf[off+1]<<16)
                 | ((uint32_t)buf[off+2]<<8)|buf[off+3];
            v[1] = ((uint32_t)buf[off+4]<<24)|((uint32_t)buf[off+5]<<16)
                 | ((uint32_t)buf[off+6]<<8)|buf[off+7];
            prv_cbc_block(v, k, (uint32_t)rounds, 1);
            buf[off]   = (uint8_t)(v[0] >> 24); buf[off+1] = (uint8_t)(v[0] >> 16);
            buf[off+2] = (uint8_t)(v[0] >> 8);  buf[off+3] = (uint8_t)v[0];
            buf[off+4] = (uint8_t)(v[1] >> 24); buf[off+5] = (uint8_t)(v[1] >> 16);
            buf[off+6] = (uint8_t)(v[1] >> 8);  buf[off+7] = (uint8_t)v[1];
            memcpy(prev, buf + off, 8);
        }
        return total;
    } else {
        size_t total = (n / 8) * 8, off;
        uint8_t prev[8], cur[8];
        if (total != n || n == 0) return (size_t)-1;
        memcpy(prev, iv, 8);
        for (off = 0; off < total; off += 8) {
            uint32_t v[2];
            memcpy(cur, buf + off, 8);
            v[0] = ((uint32_t)cur[0]<<24)|((uint32_t)cur[1]<<16)
                 | ((uint32_t)cur[2]<<8)|cur[3];
            v[1] = ((uint32_t)cur[4]<<24)|((uint32_t)cur[5]<<16)
                 | ((uint32_t)cur[6]<<8)|cur[7];
            prv_cbc_block(v, k, (uint32_t)rounds, 0);
            buf[off]   = (uint8_t)(v[0] >> 24); buf[off+1] = (uint8_t)(v[0] >> 16);
            buf[off+2] = (uint8_t)(v[0] >> 8);  buf[off+3] = (uint8_t)v[0];
            buf[off+4] = (uint8_t)(v[1] >> 24); buf[off+5] = (uint8_t)(v[1] >> 16);
            buf[off+6] = (uint8_t)(v[1] >> 8);  buf[off+7] = (uint8_t)v[1];
            for (i = 0; i < 8; i++) buf[off + i] ^= prev[i];
            memcpy(prev, cur, 8);
        }
        {   size_t pad = buf[total - 1];
            if (pad == 0 || pad > 8 || pad > total) return (size_t)-1;
            return total - pad;
        }
    }
}

/* ------------------------------------------------------------------ */
/* SHA-1 (FIPS 180-1) + base64 (RFC 4648) -- the two public primitives */
/* the T4 websocket carrier needs for its RFC 6455 handshake           */
/* ------------------------------------------------------------------ */
#define PC_SHA1_ROL(x, n) (((x) << (n)) | ((x) >> (32 - (n))))
static void pc_sha1_block(uint32_t h[5], const uint8_t block[64]) {
    uint32_t w[80];
    uint32_t a, b, c, d, e;
    int j;
    for (j = 0; j < 16; j++)
        w[j] = ((uint32_t)block[4 * j] << 24)
             | ((uint32_t)block[4 * j + 1] << 16)
             | ((uint32_t)block[4 * j + 2] << 8)
             | (uint32_t)block[4 * j + 3];
    for (j = 16; j < 80; j++) {
        uint32_t x = w[j - 3] ^ w[j - 8] ^ w[j - 14] ^ w[j - 16];
        w[j] = PC_SHA1_ROL(x, 1);
    }
    a = h[0]; b = h[1]; c = h[2]; d = h[3]; e = h[4];
    for (j = 0; j < 80; j++) {
        uint32_t f, k, t;
        if (j < 20)      { f = (b & c) | ((~b) & d); k = 0x5A827999; }
        else if (j < 40) { f = b ^ c ^ d;            k = 0x6ED9EBA1; }
        else if (j < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDC; }
        else             { f = b ^ c ^ d;            k = 0xCA62C1D6; }
        t = PC_SHA1_ROL(a, 5) + f + e + k + w[j];
        e = d; d = c; c = PC_SHA1_ROL(b, 30); b = a; a = t;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e;
}

void pc_sha1(const uint8_t *p, size_t n, uint8_t out[20]) {
    uint32_t h[5] = {0x67452301, 0xEFCDAB89, 0x98BADCFE,
                     0x10325476, 0xC3D2E1F0};
    uint64_t total = (uint64_t)n * 8;
    uint8_t tail[128];                    /* one or two padded blocks  */
    size_t rem = n % 64, full = n - rem, tl, i;
    for (i = 0; i < full; i += 64)
        pc_sha1_block(h, p + i);
    tl = rem + 1 + 8;                     /* data + 0x80 + 64-bit len */
    if (tl < 64) tl = 64;
    else if (tl < 128) tl = 128;
    memset(tail, 0, sizeof tail);
    if (rem) memcpy(tail, p + full, rem);
    tail[rem] = 0x80;
    tail[tl - 8] = (uint8_t)(total >> 56);
    tail[tl - 7] = (uint8_t)(total >> 48);
    tail[tl - 6] = (uint8_t)(total >> 40);
    tail[tl - 5] = (uint8_t)(total >> 32);
    tail[tl - 4] = (uint8_t)(total >> 24);
    tail[tl - 3] = (uint8_t)(total >> 16);
    tail[tl - 2] = (uint8_t)(total >> 8);
    tail[tl - 1] = (uint8_t)total;
    pc_sha1_block(h, tail);
    if (tl == 128) pc_sha1_block(h, tail + 64);
    for (i = 0; i < 5; i++) {
        out[4 * i]     = (uint8_t)(h[i] >> 24);
        out[4 * i + 1] = (uint8_t)(h[i] >> 16);
        out[4 * i + 2] = (uint8_t)(h[i] >> 8);
        out[4 * i + 3] = (uint8_t)h[i];
    }
}

static const char PC_B64[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/* returns the encoded length (no line wrapping, padded) */
size_t pc_b64_encode(const uint8_t *in, size_t n, char *out, size_t cap) {
    size_t i, o = 0;
    for (i = 0; i + 2 < n; i += 3) {
        uint32_t v = ((uint32_t)in[i] << 16)
                   | ((uint32_t)in[i + 1] << 8) | in[i + 2];
        if (o + 4 > cap) return 0;
        out[o++] = PC_B64[(v >> 18) & 63];
        out[o++] = PC_B64[(v >> 12) & 63];
        out[o++] = PC_B64[(v >> 6) & 63];
        out[o++] = PC_B64[v & 63];
    }
    if (i < n) {
        uint32_t v = (uint32_t)in[i] << 16;
        int rem = (int)(n - i);
        if (rem == 2) v |= (uint32_t)in[i + 1] << 8;
        if (o + 4 > cap) return 0;
        out[o++] = PC_B64[(v >> 18) & 63];
        out[o++] = PC_B64[(v >> 12) & 63];
        out[o++] = rem == 2 ? PC_B64[(v >> 6) & 63] : '=';
        out[o++] = '=';
    }
    if (o < cap) out[o] = 0;
    return o;
}


/* ================================================================== */
/* PRIVATE PRIMITIVE FAMILY (2026-10-04 directive): the textbook      */
/* constructions above stay for OLD level ids, but every draw from    */
/* the private family onward uses the seeded constructions below.     */
/* Design rule: the algorithm itself is private and per-task seeded   */
/* (recognizable constants die), while reversibility is guaranteed    */
/* because the complete implementation ships inside the analyzed      */
/* binary -- the solver recovers it by reading code, never by         */
/* matching signatures.                                               */
/* ================================================================== */

/* PRV_HASH: seeded ARX sponge. 8-word state, per-task IV, per-task
 * rotation schedule (8 triples), 64-byte blocks, 32-byte squeeze.
 * pc_prv_hash(seed, seedlen, data, n, out) -- domain-separated keyed
 * hash: the seed slot doubles as the key slot (MAC == keyed hash).  */
static void prv_rot(uint32_t *s, int r1, int r2, int r3, int a,
                    int b, int c, int d) {
    s[a] += s[b] ^ PROTO_PRV_R(r1); s[a] ^= (s[a] << 16) | (s[d] >> r2);
    s[c] += s[d] ^ PROTO_PRV_R(r3); s[c] ^= (s[c] << 16) | (s[b] >> r1);
    s[b] += s[a]; s[d] += s[c];
    s[b] = (s[b] >> r2) | (s[b] << (32 - r2));
    s[d] = (s[d] >> r3) | (s[d] << (32 - r3));
}

static void prv_block(uint32_t st[8], const uint8_t blk[64]) {
    uint32_t x[8];
    int i, r;
    /* both 32-byte halves fold into every lane (rotated cross-mix) and
     * the state chains in: a real sponge, not independent per-block
     * permutations XORed together                             */
    for (i = 0; i < 8; i++) {
        uint32_t lo = ((uint32_t)blk[4*i]) | ((uint32_t)blk[4*i+1] << 8)
                    | ((uint32_t)blk[4*i+2] << 16)
                    | ((uint32_t)blk[4*i+3] << 24);
        uint32_t hi = ((uint32_t)blk[32+4*i])
                    | ((uint32_t)blk[33+4*i] << 8)
                    | ((uint32_t)blk[34+4*i] << 16)
                    | ((uint32_t)blk[35+4*i] << 24);
        x[i] = st[i] ^ lo ^ (hi << 16) ^ (hi >> 16);
    }
    for (r = 0; r < PROTO_PRV_ROUNDS; r++) {
        prv_rot(x, PROTO_PRV_ROTS(r, 0), PROTO_PRV_ROTS(r, 1),
                PROTO_PRV_ROTS(r, 2), 0, 4, 2, 6);
        prv_rot(x, PROTO_PRV_ROTS(r, 3), PROTO_PRV_ROTS(r, 4),
                PROTO_PRV_ROTS(r, 5), 1, 5, 3, 7);
        prv_rot(x, PROTO_PRV_ROTS(r, 6), PROTO_PRV_ROTS(r, 7),
                PROTO_PRV_ROTS(r, 8), 2, 6, 0, 4);
        prv_rot(x, PROTO_PRV_ROTS(r, 9), PROTO_PRV_ROTS(r, 10),
                PROTO_PRV_ROTS(r, 11), 3, 7, 1, 5);
    }
    for (i = 0; i < 8; i++) st[i] ^= x[i];
}

/* private KDF: extract-then-expand over pc_prv_hash (label folded
 * into the seed slot; counter block gives the expansion step)      */
void pc_prv_kdf(const uint8_t *salt, size_t saltlen,
                const uint8_t *ikm, size_t ikmlen,
                const char *label, uint8_t out[32]) {
    uint8_t prk[32], buf[64];
    size_t ll = strlen(label);
    pc_prv_hash(salt, saltlen, ikm, ikmlen, prk);
    memcpy(buf, prk, 32);
    memcpy(buf + 32, label, ll);
    buf[32 + ll] = 0xD3 ^ (uint8_t)ll;          /* private pad tag    */
    pc_prv_hash(prk, 32, buf, 32 + ll + 1, out);
}

void pc_prv_hash(const uint8_t *seed, size_t seedlen,
                 const void *data, size_t n, uint8_t out[32]) {
    uint32_t st[8];
    uint8_t blk[64], pad[64];
    const uint8_t *p = data;
    size_t off = 0, i;
    uint64_t bits = (uint64_t)n * 8 + (uint64_t)seedlen * 8;
    /* init: per-task IV absorbed with the seed (keyed from block 0) */
    for (i = 0; i < 8; i++)
        st[i] = PROTO_PRIV_IV(i) ^ (uint32_t)(0x9E37 * (i + 1));
    memset(blk, 0, sizeof blk);
    memcpy(blk, seed, seedlen < 32 ? seedlen : 32);
    blk[60] = (uint8_t)seedlen; blk[61] = 0xA5 ^ (uint8_t)n;
    prv_block(st, blk);
    /* absorb data */
    while (n - off >= 64) {
        prv_block(st, p + off);
        off += 64;
    }
    /* a 32+-byte tail is absorbed as one more full block first, so the
     * final block's length field (blk[32..43]) can never overlap real
     * payload bytes                                             */
    if (n - off >= 32) {
        uint8_t tb[64];
        memset(tb, 0, sizeof tb);
        memcpy(tb, p + off, 32);
        prv_block(st, tb);
        off += 32;
    }
    memset(pad, 0, sizeof pad);
    if (n - off) memcpy(pad, p + off, n - off);
    pad[n - off] = 0x80;                     /* deliberate non-MD pad  */
    memset(blk, 0, sizeof blk);
    memcpy(blk, pad, 64);                    /* full width: no tail
                                              * byte is dropped       */
    blk[32] = (uint8_t)(bits >> 56); blk[33] = (uint8_t)(bits >> 48);
    blk[34] = (uint8_t)(bits >> 40); blk[35] = (uint8_t)(bits >> 32);
    blk[36] = (uint8_t)(bits >> 24); blk[37] = (uint8_t)(bits >> 16);
    blk[38] = (uint8_t)(bits >> 8);  blk[39] = (uint8_t)bits;
    blk[40] = (uint8_t)(n >> 24); blk[41] = (uint8_t)(n >> 16);
    blk[42] = (uint8_t)(n >> 8);  blk[43] = (uint8_t)n;
    prv_block(st, blk);
    /* squeeze: rounds of state churning emit 4 bytes per word */
    for (i = 0; i < 8; i++) {
        uint32_t v = st[i];
        out[4*i]   = (uint8_t)(v >> 24);
        out[4*i+1] = (uint8_t)(v >> 16);
        out[4*i+2] = (uint8_t)(v >> 8);
        out[4*i+3] = (uint8_t)v;
        if (i == 3) prv_block(st, (const uint8_t *)"\0\0\0\0\0\0\0\0"
                          "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
                          "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"
                          "\0\0\0\0\0\0\0\0");
    }
}

/* PRV_STREAM: seeded ARX counter stream (an ARX round skeleton with
 * per-task state layout constants, rotation schedule and round count
 * -- nothing in the binary matches a public table). One keystream
 * block is 32 bytes: the 8-word state squeezed per block.        */
void pc_prv_stream(const uint8_t key[32], const uint8_t iv[8],
                   uint64_t ctr, uint8_t *buf, size_t n) {
    uint8_t ks[32];            /* one block = 32 keystream bytes (8 u32) */
    uint32_t st[8];
    size_t off = 0, i;
    int r, w;
    while (off < n) {
        size_t take = n - off < 32 ? n - off : 32;
        for (i = 0; i < 8; i++) st[i] = PROTO_PRIV_ST(i, key, iv, ctr);
        for (r = 0; r < PROTO_PRV_ROUNDS; r++) {
            prv_rot(st, PROTO_PRV_ROTS(r, 0), PROTO_PRV_ROTS(r, 1),
                    PROTO_PRV_ROTS(r, 2), 0, 4, 2, 6);
            prv_rot(st, PROTO_PRV_ROTS(r, 3), PROTO_PRV_ROTS(r, 4),
                    PROTO_PRV_ROTS(r, 5), 1, 5, 3, 7);
        }
        for (w = 0; w < 8; w++) {
            ks[4*w]   = (uint8_t)(st[w] >> 24);
            ks[4*w+1] = (uint8_t)(st[w] >> 16);
            ks[4*w+2] = (uint8_t)(st[w] >> 8);
            ks[4*w+3] = (uint8_t)st[w];
        }
        for (i = 0; i < take; i++) buf[off + i] ^= ks[i];
        off += take;
        ctr++;
    }
}

/* PRV_KEX: seeded MODP Diffie-Hellman over a per-task 512-bit prime
 * (no curve tables, no standard group constants in the image). The
 * private exponent is 128 bits -- discrete-log soundness is far past
 * the benchmark's needs; recoverability rides the shipped code.     */
static void prv_addmod(uint8_t *a, const uint8_t *b, const uint8_t *m,
                       int bytes) {
    int i; unsigned carry = 0;
    for (i = bytes - 1; i >= 0; i--) {
        unsigned v = (unsigned)a[i] + b[i] + carry;
        a[i] = (uint8_t)v;
        carry = v >> 8;
    }
    /* conditional subtract: on carry-out OR a >= m, subtract m once.
     * The carry case is NOT optional: operands are < m with m's top
     * bit set, so a+b < 2m may exceed 2^(8*bytes) and the wrapped
     * sum is short by exactly 2^(8*bytes) - m... which the borrow-
     * out of this subtract supplies (true a+b-m lands in [0, m))   */
    int ge = (int)carry;
    if (!ge) {
        for (i = 0; i < bytes; i++) {
            if (a[i] != m[i]) { ge = a[i] > m[i]; break; }
        }
    }
    if (ge) {
        int borrow = 0;
        for (i = bytes - 1; i >= 0; i--) {
            int v = (int)a[i] - (int)m[i] - borrow;
            borrow = v < 0;
            a[i] = (uint8_t)(v & 0xFF);
        }
    }
}

static void prv_mulmod(uint8_t *out, const uint8_t *a, const uint8_t *b,
                       const uint8_t *m, int bytes) {
    /* MSB-first shift-and-add over the big-endian multiplier: r walks
     * r = 2r (+a) per bit -- a true a*b mod m. Operands arrive < m
     * (bases are reduced pubs, r starts at 0/1, addmod keeps < m)   */
    uint8_t r[128], aa[128], bb[128];
    int i, k;
    memset(r, 0, sizeof r);
    memset(aa, 0, sizeof aa);
    memset(bb, 0, sizeof bb);
    /* both operands copied first: the callers square in place
     * (mulmod(x, x, ...) -- aliasing would scramble the bit scan
     * of a multiplier that is being accumulated into)          */
    memcpy(aa, a, bytes);
    memcpy(bb, b, bytes);
    for (i = 0; i < bytes; i++) {
        for (k = 7; k >= 0; k--) {
            prv_addmod(r, r, m, bytes);          /* r = 2r mod m     */
            if ((bb[i] >> k) & 1) prv_addmod(r, aa, m, bytes);
        }
    }
    memcpy(out, r, bytes);
}

static void prv_bytes_be(uint8_t *out, uint64_t v, int at) {
    out[at] = (uint8_t)(v >> 56); out[at+1] = (uint8_t)(v >> 48);
    out[at+2] = (uint8_t)(v >> 40); out[at+3] = (uint8_t)(v >> 32);
}

/* modexp base^e mod m, e = little-endian byte string of elen bytes */
static void prv_modexp(uint8_t *out, const uint8_t *base,
                       const uint8_t *e, size_t elen,
                       const uint8_t *m, int bytes) {
    /* left-to-right binary method: square r every bit, multiply the
     * FIXED base copy on set bits. (The previous body kept a running
     * square -- the right-to-left shape -- while scanning the exponent
     * MSB-first; the two forms mix only by accident.)              */
    uint8_t r[128], bs[128];
    int i, k;
    memset(r, 0, sizeof r);
    memset(bs, 0, sizeof bs);
    r[bytes - 1] = 1;                        /* r = 1 (big-endian)   */
    memcpy(bs, base, bytes);
    for (i = 0; i < (int)elen; i++) {   /* big-endian: byte 0 is
                                         * the MOST significant     */
        for (k = 7; k >= 0; k--) {
            prv_mulmod(r, r, r, m, bytes);   /* r = r^2 mod m        */
            if ((e[i] >> k) & 1)
                prv_mulmod(r, r, bs, m, bytes);
        }
    }
    memcpy(out, r, bytes);
}

int pc_prv_pub(uint8_t *pub, const uint8_t *priv, size_t privlen) {
    prv_modexp(pub, PROTO_PRV_G, priv, privlen, PROTO_PRV_P,
               PROTO_PRV_P_BYTES);
    return 0;
}

int pc_prv_shared(uint8_t *out, const uint8_t *priv, size_t privlen,
                  const uint8_t peer[PROTO_PRV_P_BYTES]) {
    uint8_t m[128];
    memcpy(m, peer, PROTO_PRV_P_BYTES);
    prv_modexp(out, m, priv, privlen, PROTO_PRV_P, PROTO_PRV_P_BYTES);
    return 0;
}
