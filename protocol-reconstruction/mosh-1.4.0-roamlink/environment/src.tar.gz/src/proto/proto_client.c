/* proto_client.c -- reference client engine (SOLVE-SIDE ONLY TU).
 *
 * This translation unit is deliberately OUTSIDE protocol.c: the
 * carrier-linked amalgamation carries the server path only, so the
 * challenge binary contains no client code to reuse, patch-redirect
 * or MITM (leak-audit fix 2026-08: an agent patched the carrier's
 * argv handling into a code cave that called proto_client_session and
 * reproduced the whole session for free). Only the solve-side builds
 * link this file:
 *
 *   oracle pair   environment Dockerfile origin-binary stage (ref_client)
 *   selftest      gen_protocol.py Step 3 gate (selftest_main.c)
 *   NEVER         the challenge-binary stage / the carrier build
 *
 * The session helpers it shares with the server path (px_auth_mac,
 * px_flag_token, px_derive_direction_keys) are defined in proto_core.c
 * and declared in proto_internal.h -- exporting them adds nothing
 * client-only to the challenge binary.
 *
 * Session shape mirrors the server state machine (proto_core.c):
 *   HELLO -> [PARAMS (S3)] -> [AUTH (S>=2)] -> N x (SET/GET/SUM)
 *   -> [FLAG] -> BYE
 *
 * ROBUSTNESS CONTRACT (the verifier's chaos battery; the same rules
 * are disclosed to the agent in instruction.md -- a conformant client):
 *   - reads until the EXPECTED reply type arrives, silently skipping
 *     chaff and duplicated frames (C1/C4/C13)
 *   - retransmits a request whose reply times out; a corrupted reply
 *     consumed a record number, and the reader's one-record skip
 *     tolerance re-syncs the stream (C2)
 *   - recognizes ERR: at the handshake it retries, mid-session it
 *     re-runs the ladder on the SAME connection (C9/C6)
 *   - survives a server drop: detects EOF mid-session, reconnects and
 *     completes a fresh full session (fresh nonce; recorded handshakes
 *     are worthless) (C12)
 *   - buffers drip-fed and fragmented transport writes (C3/C8) and
 *     waits through slow replies instead of flooding (C7)
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "proto_config.h"
#include "proto_internal.h"

/* the FLAG token label is decoded at use (same encoding as the
 * server-side literals: no plaintext rides in .rodata of the
 * solve-side binary either, keeping the pair byte-comparable) */
static const uint8_t LIT_FLAGTOK[7] = {0xf7, 0x4d, 0x04, 0xf2, 0x2e, 0x5a, 0xa8};

static int send_msg(proto_session_t *s, int fd, proto_msg_t *m) {
    return pf_write_msg(s, fd, m);
}

/* per-read timeout: generous enough for the slow-reply fault (5s) and
 * loopback scheduling jitter, short enough that a dead peer is an
 * error inside one request/reply cycle                                */
#define CLI_READ_MS 10000

static void cli_set_timeout(int fd, int ms) {
    struct timeval tv;
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
}

/* ------------------------------------------------------------------ */
/* read until the EXPECTED reply arrives                               */
/* ------------------------------------------------------------------ */
static int cli_frame_event(proto_session_t *s, proto_msg_t *m);
static int cli_read_expect_ms(int fd, proto_session_t *s, proto_reader_t *rd,
                              int want, proto_msg_t *out, int ms);
/* Returns 0 = wanted frame in *out; 1 = an ERR frame arrived instead
 * (*out holds it); -1 = EOF/conn error; -2 = timeout. Every other
 * parseable frame (chaff-filtered stream residue, duplicated replies,
 * stale re-answers of a retransmission) is consumed and skipped -- a
 * conformant reader never lets junk or duplicates shift its position.
 *
 * L (multiplex) rules folded in:
 *   - frames on a channel other than the ACTIVE one are skipped (the
 *     server interleaves valid background frames there)
 *   - an MUX_ACK on the active channel MOVES the session: a grant or
 *     re-grant redirects chan_active (and re-arms the open dance); an
 *     ack to our own MUX_OPEN sets mux_opened + the credit window  */
static int cli_read_expect(int fd, proto_session_t *s, proto_reader_t *rd,
                           int want, proto_msg_t *out) {
    return cli_read_expect_ms(fd, s, rd, want, out, CLI_READ_MS);
}

static int cli_read_expect_ms(int fd, proto_session_t *s, proto_reader_t *rd,
                              int want, proto_msg_t *out, int ms) {
    cli_set_timeout(fd, ms);
    for (;;) {
        uint8_t buf[4096];
        int rc = pf_reader_feed(s, rd, NULL, 0, out);
        if (rc == 1) {
            int act = cli_frame_event(s, out);
            if (act < 0) continue;         /* foreign channel: skip   */
            if (act > 0)
                return -2;  /* absorbed MUX_ACK (open-ack satisfied the
                             * dance, or a redirect killed the pending
                             * request): surface NOW -- sitting out the
                             * full timeout adds 10s per session      */
            if (out->opcode == want) return 0;
            if (out->opcode == OP_ERR) return 1;
            continue;                      /* duplicate / stale: skip  */
        }
        {
            ssize_t r = read(fd, buf, sizeof buf);
            if (r == 0) return -1;
            if (r < 0) {
                if (errno == EINTR) continue;
                if (errno == EAGAIN || errno == EWOULDBLOCK) return -2;
                return -1;
            }
            rc = pf_reader_feed(s, rd, buf, (size_t)r, out);
            if (rc == 1) {
                int act = cli_frame_event(s, out);
                if (act < 0) continue;     /* foreign channel: skip   */
                if (act > 0) return -2;    /* absorbed MUX_ACK: now   */
                if (out->opcode == want) return 0;
                if (out->opcode == OP_ERR) return 1;
                /* else fall through: skip                     */
            }
            /* rc < 0: dropped frame (chaff/corrupt) -- keep going */
        }
    }
}

/* L frame policy: -1 = skip (wrong channel); 0 = process normally;
 * 1 = absorbed (an MUX_ACK whose STATE EFFECT was applied -- the
 * caller keeps reading for its wanted type).                       */
static int cli_frame_event(proto_session_t *s, proto_msg_t *m) {
    if (PROTO_L_LEVEL >= 2 && m->opcode == OP_MUX_ACK
        && (m->chan == s->chan_active || m->chan == PROTO_L_CHAN_BASE)) {
        /* discriminator: an OPEN-ack always carries a nonzero credit
         * grant; a channel GRANT (post-auth, bootstrap re-announce or
         * mid-session redirect) carries zero -- conflating them wedges
         * a client whose stale channel equals the control channel   */
        if (s->mux_wait_open && m->chan == s->chan_active
            && m->ints[1] != 0) {
            s->mux_wait_open = 0;          /* ack to OUR open         */
            s->mux_opened = 1;
            s->credit = (int)m->ints[1];
        } else {                           /* grant / mid-session move */
            s->chan_active = (int)m->ints[0];
            s->mux_opened = 0;
            s->credit = 0;
        }
        return 1;
    }
    if (PROTO_L_LEVEL >= 1 && m->chan != s->chan_active) {
        /* L7 broadcast: chan 0xFF is addressed to EVERY endpoint  */
        if (PROTO_L_LEVEL >= 7 && m->chan == 0xFF)
            return 0;
        return -1;                         /* background / foreign    */
    }
    return 0;
}

/* L2/L3: open (or refill) the active channel, then await the ack.
 * Each round first drains any pending grant/redirect with a short
 * probe -- the server's grant MUX_ACK trails AUTH_OK, a mid-session
 * re-grant REPLACES a reply, and a stale open earns a bootstrap
 * re-announce rather than an ERR. If the poll absorbs a REDIRECT
 * (credit-0 grant), the next round re-opens on the moved channel;
 * bounded so a redirect loop still terminates.                        */
static int cli_mux_dance(int fd, proto_session_t *s, proto_reader_t *rd) {
    proto_msg_t m, r;
    int round;
    for (round = 0; round < 4; round++) {
        if (s->mux_opened && !(PROTO_L_LEVEL >= 3 && s->credit <= 0))
            return 0;                    /* nothing to dance for       */
        /* drain a pending grant/redirect (short probe; MUX_ACKs are
         * absorbed by cli_frame_event's state effect). Skipped on a
         * refill (already opened, nothing pending)                 */
        if (!s->mux_opened) {
            for (;;) {
                int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &r, 150);
                if (rc == -2) break;        /* quiescent               */
                if (rc == -1) return -1;
                if (s->mux_opened) return 0; /* drain satisfied open   */
            }
        }
        memset(&m, 0, sizeof m);
        m.opcode = OP_MUX_OPEN;
        m.ints[0] = (uint64_t)(unsigned)s->chan_active;
        m.ints[1] = PROTO_L_CREDIT_INIT;
        s->chan = s->chan_active;
        s->mux_wait_open = 1;
        if (send_msg(s, fd, &m)) return -1;
        /* the ack is ABSORBED by cli_frame_event (state, not a reply
         * type) -- poll the sentinel until mux_opened flips, or a
         * redirect tells us to re-open on the moved channel        */
        for (;;) {
            int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &r,
                                        CLI_READ_MS);
            if (s->mux_opened) return 0;
            if (rc == -2 && !s->mux_opened) break;   /* redirect      */
            if (rc == 1 || rc == -1) return -1;
        }
    }
    return s->mux_opened ? 0 : -1;
}

/* ------------------------------------------------------------------ */
/* request/reply cycle with retransmission                             */
/* ------------------------------------------------------------------ */
/* 0 = got the wanted reply; -1 = connection dead (caller decides
 * reconnect); -2 = gave up after retries; -3 = server sent ERR (the
 * reply is NOT in *out -- callers with ERR recovery use the flag)   */
static int cli_txn(int fd, proto_session_t *s, proto_reader_t *rd,
                   proto_msg_t *m, int want, proto_msg_t *out,
                   int allow_retry) {
    int tries;
    for (tries = 0; tries < 3; tries++) {
        int rc;
        /* L2/L3 session admission: activate (or refill) the channel
         * before the command, and spend one credit unit            */
        s->chan = s->chan_active;
        if (PROTO_L_LEVEL >= 2 && s->state == PST_SESSION
            && (!s->mux_opened
                || (PROTO_L_LEVEL >= 3 && s->credit <= 0))) {
            if (cli_mux_dance(fd, s, rd)) return -1;
        }
        if (PROTO_L_LEVEL >= 3 && s->state == PST_SESSION) s->credit--;
        if (send_msg(s, fd, m)) return -1;
        rc = cli_read_expect(fd, s, rd, want, out);
        if (rc == 0) return 0;
        if (rc == 1) return -3;           /* ERR: caller's policy      */
        if (rc == -1) return -1;
        /* rc == -2: timeout -- retransmit (the corrupted/lost reply
         * consumed its record number; the reader's one-skip tolerance
         * covers the gap when the real reply follows)                */
        if (!allow_retry) return -2;
    }
    return -2;
}

/* S4: keep the connection alive between rounds -- the server drops a
 * peer silent past PROTO_S_WATCHDOG. Fire-and-forget: the PONG reply
 * is skipped by the next read_expect like any duplicate.          */
static void cli_heartbeat(proto_session_t *s, int fd) {
    proto_msg_t p;
    if (PROTO_S_LEVEL < 4) return;
    memset(&p, 0, sizeof p);
    p.opcode = OP_PING;
    p.ints[0] = (uint64_t)(unsigned)s->my_seq;
    (void)send_msg(s, fd, &p);
}

/* S5: the AUTH stage alone (the mid-session re-auth path -- nonce and
 * captured server pub carry over, keys re-derive at C in {3,7,8}). */
static int cli_auth_stage(int fd, proto_session_t *s, proto_reader_t *rd,
                          uint32_t *flag_tok) {
    proto_msg_t m, r;
    const proto_schema_t *as = ps_schema_for(OP_AUTH);
    /* NOTE: no counter/key reset here. In the FRESH handshake the
     * HELLO already consumed record 0 on both sides; in the S5
     * re-auth path the CALLER performs the release right after the
     * re-auth ERR is read (cli_cmd does it), mirroring the server
     * which downgrades only after its ERR is on the wire         */
    int c_mslot = ps_sem_slot(as, PSEM_KEY, PROTO_C_KEX ? 1 : 0);
    int c_pslot = ps_sem_slot(as, PSEM_KEY, 0);
    int rc;
    memset(&m, 0, sizeof m);
    m.opcode = OP_AUTH;
    if (c_mslot >= 0) {
        if (PROTO_S_LEVEL >= 7 && s->has_resume)
            px_resume_mac(s->resume_secret, s, m.blobs[c_mslot]);
        else
            px_auth_mac(s, m.blobs[c_mslot]);
    }
    if (PROTO_C_KEX) {
        uint8_t priv[32], pub[32], shared[32];
        uint8_t c2s[32], s2c[32], c2s_iv[8], s2c_iv[8];
        int fd2 = open("/dev/urandom", O_RDONLY);
        if (fd2 >= 0) {
            if (read(fd2, priv, 32) != 32) memset(priv, 7, 32);
            close(fd2);
        } else memset(priv, 7, 32);
        pc_prv_pub(pub, priv, 32);
        if (c_pslot >= 0) memcpy(m.blobs[c_pslot], pub, 32);
        if (c_mslot >= 0) {
            if (PROTO_S_LEVEL >= 7 && s->has_resume)
                px_resume_mac(s->resume_secret, s, m.blobs[c_mslot]);
            else
                px_auth_mac(s, m.blobs[c_mslot]);
        }
        rc = cli_txn(fd, s, rd, &m, OP_AUTH_OK, &r, 0);
        if (rc != 0) return -1;
        if (!s->have_server_pub ||
            pc_prv_shared(shared, priv, 32, s->server_pub))
            return -1;
        px_derive_direction_keys(shared, s->nonce, c2s, s2c,
                                 c2s_iv, s2c_iv);
        memcpy(s->tx_key, c2s, 32);
        memcpy(s->rx_key, s2c, 32);
        memcpy(s->tx_iv, c2s_iv, 8);
        memcpy(s->rx_iv, s2c_iv, 8);
        s->tx_ctr = s->rx_ctr = 0;
        s->authed = 1;
        return 0;
    }
    rc = cli_txn(fd, s, rd, &m, OP_AUTH_OK, &r, 0);
    if (rc != 0) return -1;
    s->authed = 1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* handshake: HELLO -> [PARAMS] -> [AUTH]; fills *flag_tok from the
 * PARAMS_ACK (S3). Works on an existing fd, so the resync dance can
 * re-run the exact same code on a live connection. `resume` marks the
 * S7 abbreviated path (token rides HELLO, PARAMS is skipped).
 * ------------------------------------------------------------------ */
static int cli_handshake(int fd, proto_session_t *s, proto_reader_t *rd,
                         uint32_t *flag_tok, int resume) {
    proto_msg_t m, r;
    int hello_tries;

    /* the ladder always runs in the CLEAR: on a resync re-handshake
     * (ERR code 5 dropped the connection back to the pre-auth
     * dialect) this releases the old session keys before HELLO goes
     * out; on a fresh connection it is already 0                */
    s->authed = 0;
    s->tx_ctr = s->rx_ctr = 0;

    *flag_tok = 0;

    /* HELLO (with the ERR-retry contract) */
    for (hello_tries = 0; hello_tries < 3; hello_tries++) {
        int rc;
        memset(&m, 0, sizeof m);
        m.opcode = OP_HELLO;
        m.ints[0] = PROTO_VERSION;
        m.ints[1] = 0x0003;
        if (PROTO_S_LEVEL >= 7 && resume) {
            const proto_schema_t *hs = ps_schema_for(OP_HELLO);
            int tslot = ps_sem_slot(hs, PSEM_TOKEN, 0);
            if (tslot >= 0)
                memcpy(m.blobs[tslot], s->resume_token, 16);
        }
        rc = cli_txn(fd, s, rd, &m, OP_HELLO_ACK, &r, 0);
        if (rc == 0) break;
        if (rc == -3) continue;        /* ERR: version note, retry      */
        return -1;
    }
    if (hello_tries >= 3) return -1;
    {
        const proto_schema_t *ha = ps_schema_for(OP_HELLO_ACK);
        int nslot = ps_sem_slot(ha, PSEM_NONCE, 0);
        int pslot = ps_sem_slot(ha, PSEM_KEY, 0);
        if (nslot >= 0)
            px_client_set_nonce(s, r.blobs[nslot]);
        if (pslot >= 0) {
            memcpy(s->server_pub, r.blobs[pslot], 32);
            s->have_server_pub = 1;
        }
    }

    /* PARAMS (S3) -- skipped on the S7 abbreviated (resumed) path */
    if (PROTO_S_LEVEL >= 3 && !resume) {
        int rc;
        memset(&m, 0, sizeof m);
        m.opcode = OP_PARAMS;
        m.ints[0] = 32;
        m.ints[1] = 5;
        rc = cli_txn(fd, s, rd, &m, OP_PARAMS_ACK, &r, 0);
        if (rc != 0) return -1;
        *flag_tok = (uint32_t)r.ints[1];
    }

    /* AUTH (S>=2) -- shared with the S5 mid-session re-auth path */
    if (PROTO_S_LEVEL >= 2) {
        if (cli_auth_stage(fd, s, rd, flag_tok)) return -1;
    } else if (PROTO_C_KEX) {
        return -1;    /* KEX levels require S>=2 (enforced upstream) */
    }
    s->state = PST_SESSION;
    return 0;
}

/* command with the full S-level recovery ladder: a REAUTH err
 * re-runs the AUTH stage; any other mid-session err (S>=3) re-runs
 * the whole handshake; each recovery retries the command once.   */
static int cli_cmd(proto_session_t *s, int fd, proto_reader_t *rd,
                   proto_msg_t *m, int want, proto_msg_t *out,
                   uint32_t *flag_tok) {
    int rc = cli_txn(fd, s, rd, m, want, out, 1);
    if (rc == -3 && PROTO_S_LEVEL >= 5
        && out->ints[0] == PROTO_ERR_REAUTH) {
        /* the server downgraded AFTER its ERR hit the wire; release
         * our side now so the re-AUTH rides the clear dialect     */
        s->authed = 0;
        s->tx_ctr = s->rx_ctr = 0;
        if (cli_auth_stage(fd, s, rd, flag_tok)) return -1;
        rc = cli_txn(fd, s, rd, m, want, out, 1);
    }
    if (rc == -3 && PROTO_S_LEVEL >= 3) {
        if (cli_handshake(fd, s, rd, flag_tok, 0)) return -1;
        rc = cli_txn(fd, s, rd, m, want, out, 1);
        if (rc == -3 && PROTO_S_LEVEL >= 5
            && out->ints[0] == PROTO_ERR_REAUTH) {
            s->authed = 0;
            s->tx_ctr = s->rx_ctr = 0;
            if (cli_auth_stage(fd, s, rd, flag_tok)) return -1;
            rc = cli_txn(fd, s, rd, m, want, out, 1);
        }
    }
    return rc;
}

static int cli_session_inner(int fd, int rounds, char *flag_out,
                             size_t flag_cap,
                             uint8_t tok_out[16], uint8_t sec_out[32]) {
    proto_session_t s;
    proto_reader_t rd;
    proto_msg_t m, r;
    uint32_t flag_tok = 0;
    int i;

    px_session_init(&s, 0);
    memset(&rd, 0, sizeof rd);
    s.is_udp = (PROTO_T_LEVEL == 1);
    s.state = (PROTO_S_LEVEL >= 1) ? PST_WAIT_HELLO : PST_SESSION;
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    s.mux_opened = (PROTO_L_LEVEL < 2);       /* L<2: nothing to open */
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30; /* unlimited           */

    if (PROTO_S_LEVEL >= 1) {
        if (cli_handshake(fd, &s, &rd, &flag_tok, 0)) return -1;
    }

    /* rounds of conversation */
    for (i = 0; i < rounds; i++) {
        int rc;
        cli_heartbeat(&s, fd);                 /* S4 watchdog feed     */
        if (PROTO_S_LEVEL >= 6) {              /* S6: transaction group */
            memset(&m, 0, sizeof m);
            m.opcode = OP_TXN_BEGIN;
            m.ints[0] = (uint64_t)(unsigned)i;
            if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return i;
        }
        memset(&m, 0, sizeof m);
        m.opcode = OP_SET;
        snprintf(m.strs[0], PROTO_STR_MAX, "k%d", i);
        m.ints[1] = (uint64_t)(i * 7 + 1) & 0xFFFF;
        rc = cli_cmd(&s, fd, &rd, &m, OP_OK, &r, &flag_tok);
        if (rc != 0) return i;
        memset(&m, 0, sizeof m);
        m.opcode = OP_GET;
        snprintf(m.strs[0], PROTO_STR_MAX, "k%d", i);
        rc = cli_cmd(&s, fd, &rd, &m, OP_VAL, &r, &flag_tok);
        if (rc != 0) return i;
        memset(&m, 0, sizeof m);
        m.opcode = OP_SUM;
        m.ints[0] = (uint64_t)(i + 3) & 0xFFFF;
        m.ints[1] = (uint64_t)(i + 9) & 0xFFFF;
        rc = cli_cmd(&s, fd, &rd, &m, OP_SUM_RES, &r, &flag_tok);
        if (rc != 0) return i;
        if (PROTO_S_LEVEL >= 6) {
            /* the seeded rollback cadence: every Nth group unwinds */
            memset(&m, 0, sizeof m);
            m.opcode = ((i + 1) % PROTO_S_ROLLBACK_EVERY == 0)
                ? OP_TXN_ROLLBACK : OP_TXN_COMMIT;
            m.ints[0] = 0;
            if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return i;
        }
    }

    /* FLAG */
    if (flag_out) {
        char lb[12];
        int rc;
        cli_heartbeat(&s, fd);
        if (PROTO_S_LEVEL >= 6) {
            memset(&m, 0, sizeof m);
            m.opcode = OP_TXN_BEGIN;
            m.ints[0] = rounds;
            if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
        }
        memset(&m, 0, sizeof m);
        m.opcode = OP_FLAG;
        if (PROTO_S_LEVEL >= 2) {
            px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
            m.ints[0] = flag_tok ? flag_tok : px_flag_token(&s, lb);
        }
        rc = cli_cmd(&s, fd, &rd, &m, OP_FLAG_RES, &r, &flag_tok);
        if (rc != 0) return -1;
        snprintf(flag_out, flag_cap, "%s", r.strs[0]);
        if (PROTO_S_LEVEL >= 6) {
            memset(&m, 0, sizeof m);
            m.opcode = OP_TXN_COMMIT;
            m.ints[0] = 0;
            if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
        }
    }

    /* BYE: wait for the ACK, then close -- the clean-close contract.
     * S7: the ACK carries a single-use resumption token; both ends
     * derive the secret from this session's material             */
    memset(&m, 0, sizeof m);
    m.opcode = OP_BYE;
    m.ints[0] = 0;
    if (cli_txn(fd, &s, &rd, &m, OP_BYE_ACK, &r, 0) == 0
        && PROTO_S_LEVEL >= 7) {
        const proto_schema_t *bs = ps_schema_for(OP_BYE_ACK);
        int tslot = ps_sem_slot(bs, PSEM_TOKEN, 0);
        if (tslot >= 0) {
            uint8_t nz = 0, j;
            for (j = 0; j < 16; j++) if (r.blobs[tslot][j]) nz = 1;
            if (nz) {
                memcpy(s.resume_token, r.blobs[tslot], 16);
                px_resume_material(&s, s.resume_secret, s.resume_token);
                s.has_resume = 1;
                if (tok_out) memcpy(tok_out, s.resume_token, 16);
                if (sec_out) memcpy(sec_out, s.resume_secret, 32);
            }
        }
    }
    return rounds;
}

/* S7: one abbreviated (resumed) session -- token rides HELLO, PARAMS
 * is skipped, AUTH rides the resumption secret (PSK; C in {3,7,8}
 * still performs a fresh ECDH on top, TLS-1.3 PSK+DHE shape).     */
static int cli_resume_session(int fd, char *flag_out, size_t flag_cap,
                              const uint8_t token[16],
                              const uint8_t secret[32]) {
    proto_session_t s;
    proto_reader_t rd;
    proto_msg_t m, r;
    uint32_t flag_tok = 0;

    px_session_init(&s, 0);
    memset(&rd, 0, sizeof rd);
    s.is_udp = (PROTO_T_LEVEL == 1);
    memcpy(s.resume_token, token, 16);
    memcpy(s.resume_secret, secret, 32);
    s.has_resume = 1;
    s.state = PST_WAIT_HELLO;
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    s.mux_opened = (PROTO_L_LEVEL < 2);
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30;

    if (cli_handshake(fd, &s, &rd, &flag_tok, 1)) return -1;
    /* the flag token at S3 came from the FIRST session's PARAMS_ACK;
     * a resumed session skips PARAMS, so derive it locally (the GT
     * contract: the label HMAC over the fresh nonce)               */
    cli_heartbeat(&s, fd);
    if (PROTO_S_LEVEL >= 6) {
        memset(&m, 0, sizeof m);
        m.opcode = OP_TXN_BEGIN;
        m.ints[0] = 0xFE;
        if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
    }
    {
        char lb[12];
        memset(&m, 0, sizeof m);
        m.opcode = OP_FLAG;
        px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
        m.ints[0] = flag_tok ? flag_tok : px_flag_token(&s, lb);
        if (cli_txn(fd, &s, &rd, &m, OP_FLAG_RES, &r, 1) != 0)
            return -1;
        snprintf(flag_out, flag_cap, "%s", r.strs[0]);
    }
    if (PROTO_S_LEVEL >= 6) {
        memset(&m, 0, sizeof m);
        m.opcode = OP_TXN_COMMIT;
        m.ints[0] = 0;
        if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
    }
    memset(&m, 0, sizeof m);
    m.opcode = OP_BYE;
    m.ints[0] = 0;
    (void)cli_txn(fd, &s, &rd, &m, OP_BYE_ACK, &r, 0);
    return 0;
}

/* T seam: the session's transport dialer -- T3 binds the seeded unix
 * path, T4 rides TCP but completes the RFC 6455 upgrade first; the
 * T0/T1 dials stay the plain inet ones                            */
static int cli_connect(const char *host, int port) {
    if (PROTO_T_LEVEL == 3) return pc_unix_connect(PROTO_UNIX_PATH);
    if (PROTO_T_LEVEL == 4) return pc_ws_connect(host, port);
    return PROTO_T_LEVEL == 1 ? pc_udp_connect(host, port)
                              : pc_full_tcp_connect(host, port);
}

int proto_client_session(const char *host, int port,
                         char *flag_out, size_t flag_cap) {
    /* the drop contract: an EOF mid-session (server dropped without
     * BYE) is retried as a COMPLETE fresh session -- the reconnect
     * draws a fresh nonce, so nothing from the dead session replays */
    int attempt;
    uint8_t tok[16], sec[32];
    memset(tok, 0, sizeof tok);
    for (attempt = 0; attempt < 3; attempt++) {
        int fd = cli_connect(host, port);
        int rc;
        if (fd < 0) continue;
        rc = cli_session_inner(fd, PROTO_SESSION_ROUNDS, flag_out,
                               flag_cap, tok, sec);
        close(fd);
        if (rc == (int)PROTO_SESSION_ROUNDS) {
            /* S7: prove the resumption token on a SECOND connection
             * (abbreviated handshake + fresh flag). The verifier's
             * expected value reads the LAST delivered flag line.
             * A zero token means the harvest never happened (e.g. a
             * server that dropped before BYE) -- nothing to prove. */
            {
                uint8_t j, nz = 0;
                for (j = 0; j < 16; j++) if (tok[j]) nz = 1;
                if (!nz) return 0;
            }
            if (PROTO_S_LEVEL >= 7) {
                int fd2 = cli_connect(host, port);
                int r2;
                if (fd2 < 0) return -1;
                r2 = cli_resume_session(fd2, flag_out, flag_cap,
                                        tok, sec);
                close(fd2);
                if (r2 != 0) return -1;
            }
            return 0;
        }
    }
    return -1;
}

int proto_client_converse(const char *host, int port, int rounds) {
    int fd = cli_connect(host, port);
    int rc;
    if (fd < 0) return -1;
    rc = cli_session_inner(fd, rounds, NULL, 0, NULL, NULL);
    close(fd);
    return rc;
}
