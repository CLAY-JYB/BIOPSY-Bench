/* proto_client.c -- reference client engine (SOLVE-SIDE ONLY TU).
 *
 * This translation unit is deliberately OUTSIDE protocol.c: the
 * carrier-linked amalgamation carries the server path only, so the
 * challenge binary contains no client code to reuse, patch-redirect
 * or MITM (an agent can otherwise patch the carrier's argv handling
 * into a code cave that calls proto_client_session and reproduce the
 * whole session for free). Only the solve-side builds
 * link this file:
 *
 *   oracle pair   environment Dockerfile origin-binary stage (ref_client)
 *   selftest      gen_protocol.py Step 3 gate (selftest_main.c)
 *   NEVER         the challenge-binary stage / the carrier build
 *
 * The session helpers it shares with the server path (px_auth_mac,
 * px_flag_token, px_derive_direction_keys) are defined in proto_core.c
 * and declared in proto_internal.h -- exporting them adds nothing
 * client-only to the challenge binary.
 *
 * Session shape mirrors the server state machine (proto_core.c):
 *   HELLO -> [PARAMS (S3)] -> [AUTH (S>=2)] -> N x (SET/GET/SUM)
 *   -> [FLAG] -> BYE
 *
 * ROBUSTNESS CONTRACT (the verifier's chaos battery; the same rules
 * are disclosed to the agent in instruction.md -- a conformant client):
 *   - reads until the EXPECTED reply type arrives, silently skipping
 *     chaff and duplicated frames (C1/C4/C13)
 *   - retransmits a request whose reply times out; a corrupted reply
 *     consumed a record number, and the reader's one-record skip
 *     tolerance re-syncs the stream (C2)
 *   - recognizes ERR: at the handshake it retries, mid-session it
 *     re-runs the ladder on the SAME connection (C9/C6)
 *   - survives a server drop: detects EOF mid-session, reconnects and
 *     completes a fresh full session (fresh nonce; recorded handshakes
 *     are worthless) (C12)
 *   - buffers drip-fed and fragmented transport writes (C3/C8) and
 *     waits through slow replies instead of flooding (C7)
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/* walk-table geometry (the recovery path reads the table too)        */
#define WK_MAX_STATES 64
#define WK_MAX_EDGES  24
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/time.h>
/* the code of the most recent ERR a fire read: the walk's recovery
 * gating keys on the downgrade classes (root 42)                */
static int g_last_err = 0;


#include "proto_config.h"
#include "proto_internal.h"

/* the FLAG token label is decoded at use (same encoding as the
 * server-side literals: no plaintext rides in .rodata of the
 * solve-side binary either, keeping the pair byte-comparable) */
static const uint8_t LIT_FLAGTOK[7] = {0xf7, 0x4d, 0x04, 0xf2, 0x2e, 0x5a, 0xa8};

static int send_msg(proto_session_t *s, int fd, proto_msg_t *m) {
    if (getenv("DBG_EVT"))
        fprintf(stderr, "TX op=%02x myseq=%d chan=%d sup=%d auth=%d "
                "tc=%llu\n",
                m->opcode, (int)s->my_seq, s->chan,
                s->suppress_seq_bump, s->authed,
                (unsigned long long)s->tx_ctr);
    return pf_write_msg(s, fd, m);
}

/* per-read timeout: generous enough for the slow-reply fault (5s) and
 * loopback scheduling jitter, short enough that a dead peer is an
 * error inside one request/reply cycle                                */
#define CLI_READ_MS 6000

static void cli_set_timeout(int fd, int ms) {
    struct timeval tv;
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
}

/* ------------------------------------------------------------------ */
/* read until the EXPECTED reply arrives                               */
/* ------------------------------------------------------------------ */
static int g_traverse;    /* 1: pure traversal -- no retransmits */
static int cli_frame_event(proto_session_t *s, proto_msg_t *m);
static int cli_class_recover(int fd, proto_session_t *s,
                             proto_reader_t *rd, const proto_msg_t *err,
                             uint32_t *flag_tok, int local_only);
static int cli_handshake(int fd, proto_session_t *s, proto_reader_t *rd,
                         uint32_t *flag_tok, int resume);
static int cli_resync_recover(int fd, proto_session_t *s,
                              proto_reader_t *rd, uint32_t *flag_tok);
static int cli_cmd(proto_session_t *s, int fd, proto_reader_t *rd,
                   proto_msg_t *m, int want, proto_msg_t *out,
                   uint32_t *flag_tok);
static void cli_book_mark(int st, int opcode, int nxt);
static int cli_read_expect_ms(int fd, proto_session_t *s, proto_reader_t *rd,
                              int want, proto_msg_t *out, int ms);
/* Returns 0 = wanted frame in *out; 1 = an ERR frame arrived instead
 * (*out holds it); -1 = EOF/conn error; -2 = timeout. Every other
 * parseable frame (chaff-filtered stream residue, duplicated replies,
 * stale re-answers of a retransmission) is consumed and skipped -- a
 * conformant reader never lets junk or duplicates shift its position.
 *
 * L (multiplex) rules folded in:
 *   - frames on a channel other than the ACTIVE one are skipped (the
 *     server interleaves valid background frames there)
 *   - an MUX_ACK on the active channel MOVES the session: a grant or
 *     re-grant redirects chan_active (and re-arms the open dance); an
 *     ack to our own MUX_OPEN sets mux_opened + the credit window  */
static int cli_read_expect(int fd, proto_session_t *s, proto_reader_t *rd,
                           int want, proto_msg_t *out) {
    return cli_read_expect_ms(fd, s, rd, want, out, CLI_READ_MS);
}

static int cli_read_expect_ms(int fd, proto_session_t *s, proto_reader_t *rd,
                              int want, proto_msg_t *out, int ms) {
    cli_set_timeout(fd, ms);
    for (;;) {
        uint8_t buf[4096];
        int rc = pf_reader_feed(s, rd, NULL, 0, out);
        if (rc == 1) {
            int act = cli_frame_event(s, out);
            if (act < 0) continue;         /* foreign channel: skip   */
            if (act > 0)
                return -2;  /* absorbed MUX_ACK (open-ack satisfied the
                             * dance, or a redirect killed the pending
                             * request): surface NOW -- sitting out the
                             * full timeout adds 10s per session      */
            if (out->opcode == want) return 0;
            if (out->opcode == OP_ERR) return 1;
            continue;                      /* duplicate / stale: skip  */
        }
        {
            ssize_t r = read(fd, buf, sizeof buf);
            if (r == 0) return -1;
            if (r < 0) {
                if (errno == EINTR) continue;
                if (errno == EAGAIN || errno == EWOULDBLOCK) return -2;
                return -1;
            }
            rc = pf_reader_feed(s, rd, buf, (size_t)r, out);
            if (rc == 1) {
                int act = cli_frame_event(s, out);
                if (act < 0) continue;     /* foreign channel: skip   */
                if (act > 0) return -2;    /* absorbed MUX_ACK: now   */
                if (act == 0 && s->mux_opened && want == -0x7FFF)
                    return 0;  /* the dance's sentinel: a latched open
                                * IS the satisfying event -- sitting
                                * out the full clock wastes 6s/dance */
                if (out->opcode == want) return 0;
                if (out->opcode == OP_ERR) return 1;
                /* else fall through: skip                     */
            }
            /* rc < 0: dropped frame (chaff/corrupt) -- keep going */
        }
    }
}

/* L frame policy: -1 = skip (wrong channel); 0 = process normally;
 * 1 = absorbed (an MUX_ACK whose STATE EFFECT was applied -- the
 * caller keeps reading for its wanted type).                       */
static int cli_frame_event(proto_session_t *s, proto_msg_t *m) {
    if (PROTO_L_LEVEL >= 2 && m->opcode == OP_MUX_ACK) {
        /* an MUX_ACK is CONTROL PLANE: it must be applied wherever it
         * rides -- a redirect names the channel to MOVE TO, and it
         * need not arrive on the (now dead) channel the client still
         * holds. Matching only the active/BASE channels ate live
         * redirects as foreign frames, the client kept commanding on
         * the departed channel and every fire died on ERR CHANNEL   */
        if (s->mux_wait_open && m->chan == s->chan_active
            && m->ints[1] != 0) {
            s->mux_wait_open = 0;          /* ack to OUR open         */
            s->mux_opened = 1;
            s->credit = (int)m->ints[1];
            /* the latched open-ack may BE the wanted reply (a direct
             * MUX_OPEN fire expects MUX_ACK): let it flow to the want
             * check instead of absorbing it into a spurious -2     */
            return 0;
        } else {                           /* grant / mid-session move */
            s->chan_active = (int)m->ints[0];
            s->mux_opened = 0;
            s->credit = 0;
            s->redirect_consumed = 1;  /* a move that lands mid-wait
                                        * replaced the pending command's
                                        * reply: the server CONSUMED it   */
        }
        return 1;
    }
    if (PROTO_L_LEVEL >= 1 && m->chan != s->chan_active) {
        /* L7 broadcast: chan 0xFF is addressed to EVERY endpoint  */
        if (PROTO_L_LEVEL >= 7 && m->chan == 0xFF)
            return 0;
        return -1;                         /* background / foreign    */
    }
    return 0;
}

/* L2/L3: open (or refill) the active channel, then await the ack.
 * Each round first drains any pending grant/redirect with a short
 * probe -- the server's grant MUX_ACK trails AUTH_OK, a mid-session
 * re-grant REPLACES a reply, and a stale open earns a bootstrap
 * re-announce rather than an ERR. If the poll absorbs a REDIRECT
 * (credit-0 grant), the next round re-opens on the moved channel;
 * bounded so a redirect loop still terminates.                        */
static int cli_mux_dance(int fd, proto_session_t *s, proto_reader_t *rd) {
    proto_msg_t m, r;
    int round;
    if (getenv("DBG_EVT"))
        fprintf(stderr, "DANCE-ENTER mux=%d auth=%d chan=%d\n",
                s->mux_opened, s->authed, s->chan_active);
    for (round = 0; round < 4; round++) {
        if (s->mux_opened && !(PROTO_L_LEVEL >= 3 && s->credit <= 0))
            return 0;                    /* nothing to dance for       */
        /* drain a pending grant/redirect (short probe; MUX_ACKs are
         * absorbed by cli_frame_event's state effect). Skipped on a
         * refill (already opened, nothing pending)                 */
        if (!s->mux_opened) {
            for (;;) {
                int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &r, 150);
                if (rc == -2) break;        /* quiescent               */
                if (rc == -1) return -1;
                if (s->mux_opened) return 0; /* drain satisfied open   */
            }
        }
        memset(&m, 0, sizeof m);
        m.opcode = OP_MUX_OPEN;
        m.ints[0] = (uint64_t)(unsigned)s->chan_active;
        m.ints[1] = PROTO_L_CREDIT_INIT;
        s->chan = s->chan_active;
        s->mux_wait_open = 1;
        if (send_msg(s, fd, &m)) return -1;
        /* the ack is ABSORBED by cli_frame_event (state, not a reply
         * type) -- poll the sentinel until mux_opened flips, or a
         * redirect tells us to re-open on the moved channel        */
        int errtries = 0;
        for (;;) {
            int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &r,
                                        6000);   /* dance acks are
                                                  * near-instant on
                                                  * loopback, but the
                                                  * delay fault holds
                                                  * ANY reply 5s: the
                                                  * clock must clear
                                                  * it              */
            if (getenv("DBG_EVT"))
                fprintf(stderr, "DANCE-POLL rc=%d mux=%d chan=%d "
                        "errt=%d\n", rc, s->mux_opened, s->chan_active,
                        errtries);
            if (s->mux_opened) return 0;
            if (rc == -2 && !s->mux_opened) break;   /* redirect      */
            if (rc == 1) {
                /* ERR (typically CHANNEL after a silent server-side
                 * move): query the control channel for a re-announce
                 * instead of dying -- BOUNDED, an error state that
                 * rejects every open must fail the dance, not ping
                 * pong forever                                */
                if (++errtries > 2) return -1;
                proto_msg_t b;
                s->mux_opened = 0;
                s->chan = PROTO_L_CHAN_BASE;
                memset(&b, 0, sizeof b);
                b.opcode = OP_MUX_OPEN;
                b.ints[0] = (uint64_t)(unsigned)s->chan_active;
                b.ints[1] = PROTO_L_CREDIT_INIT;
                if (send_msg(s, fd, &b)) return -1;
                continue;
            }
            if (rc == -1) return -1;
        }
    }
    return s->mux_opened ? 0 : -1;
}

/* ------------------------------------------------------------------ */
/* request/reply cycle with retransmission                             */
/* ------------------------------------------------------------------ */
/* 0 = got the wanted reply; -1 = connection dead (caller decides
 * reconnect); -2 = gave up after retries; -3 = server sent ERR (the
 * reply is NOT in *out -- callers with ERR recovery use the flag)   */
/* post-recovery drain: a ladder's late replies (an ACK that raced
 * the return path) must not sit queued -- the next navigation hop
 * whose WANT matches (the mode_entry=HELLO fallback collides with
 * HELLO_ACK directly) would misread the stale frame as its own and
 * route the client past a hop the server never took            */
static void cli_drain_replies(int fd, proto_session_t *s,
                              proto_reader_t *rd, int ms) {
    proto_msg_t d;
    int t;
    for (t = 0; t < 8; t++) {
        int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &d, ms);
        if (rc != 0 && rc != 1) break;   /* drained or dead */
    }
}
static int cli_txn_inner(int fd, proto_session_t *s, proto_reader_t *rd,
                         proto_msg_t *m, int want,
                         proto_msg_t *out, int allow_retry);

/* every exchange the retry ladder TOUCHED (a retransmit makes the
 * peer's duplicate tolerance RE-ANSWER, and the duplicate reply
 * outlives the call) drains before the caller's next exchange --
 * otherwise the stale dup satisfies a later WANT (the ghost-ACK
 * cascade on the recovery ladders)                        */
static int cli_txn(int fd, proto_session_t *s, proto_reader_t *rd,
                   proto_msg_t *m, int want, proto_msg_t *out,
                   int allow_retry) {
    int rc = cli_txn_inner(fd, s, rd, m, want, out, allow_retry);
    if (rc == 0)
        cli_drain_replies(fd, s, rd, 20);
    return rc;
}

static int cli_txn_inner(int fd, proto_session_t *s, proto_reader_t *rd,
                         proto_msg_t *m, int want,
                         proto_msg_t *out, int allow_retry) {
    int tries, reread = 0, retransmitted = 0;
    s->redirect_consumed = 0;   /* only a redirect landing inside THIS
                                 * exchange's wait window speaks for the
                                 * in-flight command                  */
    for (tries = 0; tries < 3; tries++) {
        int rc;
        /* pre-send flush: earlier exchanges can leave frames queued
         * (dup re-answers, a redirect's ERR answering an open the
         * dance already absorbed). Consume them NOW -- a clean reply
         * stream means the next read's ERR really answers THIS
         * request, and the request never misreads a stale refusal */
        for (;;) {
            proto_msg_t extra;
            int drc = cli_read_expect_ms(fd, s, rd, -0x7FFF,
                                         &extra, 1);
            if (drc != 0) break;   /* nothing pre-queued (1ms: a 0ms
                                    * timeout DISABLES the socket
                                    * timer and blocks forever)    */
        }
        /* L2/L3 session admission: activate (or refill) the channel
         * before the command, and spend one credit unit            */
        s->chan = s->chan_active;
        if (PROTO_L_LEVEL >= 2 && ps_fsm_is_kind(s->state, 3)
            && (!s->mux_opened
                || (PROTO_L_LEVEL >= 3 && s->credit <= 0))) {
            if (cli_mux_dance(fd, s, rd)) return -1;
            s->redirect_consumed = 0;  /* the dance owned its own
                                        * redirects -- none of them
                                        * consumed THIS command      */
        }
        if (PROTO_L_LEVEL >= 3 && ps_fsm_is_kind(s->state, 3))
        s->credit--;
        /* re-anchor the channel AFTER the dance: a grant absorbed
         * during it moved chan_active, and sending on the stale
         * pre-dance channel produces a magic the server's reader
         * derives as garbage (frame rc=0 cand=0)              */
        s->chan = s->chan_active;
        /* an MUX_OPEN send IS an open: arm the wait flag AFTER the
         * dance (the dance's own latch clears it) so THIS open's ack
         * latches instead of being misread as a grant           */
        if (m->opcode == OP_MUX_OPEN)
            s->mux_wait_open = 1;
        if (send_msg(s, fd, m)) return -1;
        rc = cli_read_expect(fd, s, rd, want, out);
        if (rc == 0) return 0;
        if (rc == 1) {
            /* NB: the authed/counter mirror lives at the RECOVERY
             * entry (cli_resync_recover), NOT here: the organic
             * refusals carry the same codes WITHOUT downgrading the
             * server, and mirroring on every ERR unmasked frames the
             * still-authed server then dropped (the hostapd lesson) */
            return -3;           /* ERR: caller's policy      */
        }
        if (rc == -1) return -1;
        /* rc == -2: either the deadline passed, or a control frame
         * was absorbed mid-wait (the grant trailing a re-AUTH). In
         * the absorb case the ORIGINAL send already landed and its
         * reply is still queued -- re-send would double-fire the
         * server's edge. ONE short no-send re-read first            */
        if (rc == -2 && !reread) {
            reread = 1;
            rc = cli_read_expect_ms(fd, s, rd, want, out, 400);
            if (rc == 0) return 0;
            if (rc == 1) return -3;
            if (rc == -1) return -1;
        }
        /* still -2: retransmit (the SAME record number -- the peer's
         * duplicate tolerance re-processes without re-firing the
         * edge; a corrupted reply consumed its record, and the
         * reader's one-skip tolerance covers the gap when the real
         * reply follows)                                            */
        if (!allow_retry) return -2;
        if (s->redirect_consumed) {
            s->redirect_consumed = 0;
            s->suppress_seq_bump = 0;
        } else {
            s->suppress_seq_bump = 1;
        }
    }
    return -2;
}

/* S4: keep the connection alive between rounds -- the server drops a
 * peer silent past PROTO_S_WATCHDOG. Fire-and-forget: the PONG reply
 * is skipped by the next read_expect like any duplicate.          */
static void cli_heartbeat(proto_session_t *s, int fd) {
    proto_msg_t p;
    if (PROTO_S_LEVEL < 4) return;
    memset(&p, 0, sizeof p);
    p.opcode = OP_PING;
    p.ints[0] = (uint64_t)(unsigned)s->my_seq;
    (void)send_msg(s, fd, &p);
}

/* S5: the AUTH stage alone (the mid-session re-auth path -- nonce and
 * captured server pub carry over, keys re-derive at C in {3,7,8}). */
static int cli_auth_stage(int fd, proto_session_t *s, proto_reader_t *rd,
                          uint32_t *flag_tok) {
    proto_msg_t m, r;
    const proto_schema_t *as = ps_schema_for(OP_AUTH);
    /* NOTE: no counter/key reset here. In the FRESH handshake the
     * HELLO already consumed record 0 on both sides; in the S5
     * re-auth path the CALLER performs the release right after the
     * re-auth ERR is read (cli_cmd does it), mirroring the server
     * which downgrades only after its ERR is on the wire         */
    int c_mslot = ps_sem_slot(as, PSEM_KEY, PROTO_C_KEX ? 1 : 0);
    int c_pslot = ps_sem_slot(as, PSEM_KEY, 0);
    int rc;
    memset(&m, 0, sizeof m);
    m.opcode = OP_AUTH;
    if (c_mslot >= 0) {
        if (PROTO_S_LEVEL >= 7 && s->has_resume)
            px_resume_mac(s->resume_secret, s, m.blobs[c_mslot]);
        else
            px_auth_mac(s, m.blobs[c_mslot]);
    }
    if (PROTO_C_KEX) {
        uint8_t priv[32], pub[32], shared[32];
        uint8_t c2s[32], s2c[32], c2s_iv[8], s2c_iv[8];
        int fd2 = open("/dev/urandom", O_RDONLY);
        if (fd2 >= 0) {
            if (read(fd2, priv, 32) != 32) memset(priv, 7, 32);
            close(fd2);
        } else memset(priv, 7, 32);
        pc_prv_pub(pub, priv, 32);
        if (c_pslot >= 0) memcpy(m.blobs[c_pslot], pub, 32);
        if (c_mslot >= 0) {
            if (PROTO_S_LEVEL >= 7 && s->has_resume)
                px_resume_mac(s->resume_secret, s, m.blobs[c_mslot]);
            else
                px_auth_mac(s, m.blobs[c_mslot]);
        }
        {   /* AUTH-class recovery: an ERR auth answer (the S5 re-AUTH
             * can be refused once under fault) is retried in place;
             * the server's seeded budget still bounds organic bad
             * authenticators into a reconnect                    */
            int atry;
            for (atry = 0; atry < 3; atry++) {
                rc = cli_txn(fd, s, rd, &m, OP_AUTH_OK, &r, 0);
                if (rc != -3 && rc != -2) break;  /* -2: the grant
                                       * trailing this AUTH_OK rides
                                       * ahead of the NEXT read     */
            }
        }
        if (rc != 0) return -1;
        if (!s->have_server_pub ||
            pc_prv_shared(shared, priv, 32, s->server_pub))
            return -1;
        px_derive_direction_keys(shared, s->nonce, c2s, s2c,
                                 c2s_iv, s2c_iv);
        memcpy(s->tx_key, c2s, 32);
        memcpy(s->rx_key, s2c, 32);
        memcpy(s->tx_iv, c2s_iv, 8);
        memcpy(s->rx_iv, s2c_iv, 8);
        s->tx_ctr = s->rx_ctr = 0;
        s->authed = 1;
        return 0;
    }
    {   /* static-key path: same AUTH-class retry as the KEX path   */
        int atry;
        for (atry = 0; atry < 3; atry++) {
            rc = cli_txn(fd, s, rd, &m, OP_AUTH_OK, &r, 0);
            if (rc != -3 && rc != -2) break;
        }
    }
    if (rc != 0) return -1;
    s->authed = 1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* handshake: HELLO -> [PARAMS] -> [AUTH]; fills *flag_tok from the
 * PARAMS_ACK (S3). Works on an existing fd, so the resync dance can
 * re-run the exact same code on a live connection. `resume` marks the
 * S7 abbreviated path (token rides HELLO, PARAMS is skipped).
 * ------------------------------------------------------------------ */
/* role -> expected ACK opcode (the reply side of each edge) */
static int ack_of(int opcode) {
    switch (opcode) {
    case OP_HELLO:   return OP_HELLO_ACK;
    case OP_PARAMS:  return OP_PARAMS_ACK;
    case OP_AUTH:    return OP_AUTH_OK;
    case OP_SET:     return OP_OK;
    case OP_GET:     return OP_VAL;
    case OP_SUM:     return OP_SUM_RES;
    case OP_FLAG:    return OP_FLAG_RES;
    case OP_BYE:     return OP_BYE_ACK;
    case OP_PING:    return OP_PONG;
    case OP_STAT:    return OP_STAT_RES;
    case OP_TXN_BEGIN:
    case OP_TXN_COMMIT:
    case OP_TXN_ROLLBACK: return OP_OK;
    case OP_MUX_OPEN: return OP_MUX_ACK;   /* the channel dance's ack */
    default:         return OP_OK;
    }
}

/* shortest success-path from `from` to `to` over the table's accept/
 * self/value edges (client-side decode of the same masked table). The
 * path lands in path[] as a sequence of states to traverse; returns
 * the path length or -1. */
static int cli_path_to(int from, int to, int *path, int cap) {
    int prev[64], q[64], qh = 0, qt = 0, i, n = ps_fsm_n_states();
    if (n > 64) n = 64;
    for (i = 0; i < n; i++) prev[i] = -2;
    prev[from] = -1;
    q[qt++] = from;
    while (qh < qt) {
        int st = q[qh++], k;
        if (st == to) break;
        for (k = 0; k < 24; k++) {
            ps_fsm_edge_t ed;
            int nx;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            nx = ed.next == 0xFF ? st : ed.next;
            if (nx < n && prev[nx] == -2
                && (ed.cls == 1 || ed.cls == 2 || ed.cls == 0)) {
                prev[nx] = st;
                q[qt++] = nx;
            }
        }
    }
    if (prev[to] == -2) return -1;
    { int len = 0, cur = to;
      while (cur != from && len < cap) { path[len++] = cur; cur = prev[cur]; }
      /* reverse */
      for (i = 0; i < len / 2; i++) { int t = path[i]; path[i] = path[len-1-i]; path[len-1-i] = t; }
      return len; }
}

/* build the message that fires `ed` from state st. vgate: 0 = satisfy
 * the value condition, 1 = violate it (the fail-probe side) */
static void cli_build_edge(proto_session_t *s, int opcode,
                           const ps_fsm_edge_t *ed, int vgate,
                           proto_msg_t *m, uint32_t flag_tok) {
    memset(m, 0, sizeof *m);
    m->opcode = opcode;
    switch (opcode) {
    case OP_HELLO:
        m->ints[0] = PROTO_VERSION;
        m->ints[1] = 0x0003;
        if (PROTO_S_LEVEL >= 7 && s->has_resume) {
            const proto_schema_t *hs = ps_schema_for(OP_HELLO);
            int t = ps_sem_slot(hs, PSEM_TOKEN, 0);
            if (t >= 0) memcpy(m->blobs[t], s->resume_token, 16);
        }
        break;
    case OP_PARAMS: {
        m->ints[0] = 32;
        m->ints[1] = 5;
        break;
    }
    case OP_SET:
        snprintf(m->strs[0], PROTO_STR_MAX, "k0");
        m->ints[1] = 7;
        break;
    case OP_GET:
        snprintf(m->strs[0], PROTO_STR_MAX, "k0");
        break;
    case OP_SUM:
        m->ints[0] = 3;
        m->ints[1] = 9;
        break;
    case OP_FLAG:
        if (PROTO_S_LEVEL >= 2) {
            char lb[12];
            px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
            m->ints[0] = flag_tok ? flag_tok : px_flag_token(s, lb);
        }
        break;
    case OP_TXN_BEGIN:
        m->ints[0] = 1;
        break;
    default:
        break;                      /* PING/STAT/BYE/MUX/TXN carry 0s */
    }
    /* VALUE-gate satisfaction comes LAST: the per-opcode defaults
     * above name their own field values (OP_PARAMS sets its window
     * to 32), and the gated integer must WIN over the default      */
    /* VALUE-gate satisfaction is GENERIC: the negotiation roles vary
     * per form (the gated hop is not always PARAMS), so every build
     * fills the edge's gated integer field with the operand (GE/LE/EQ
     * pass on equality); vgate violates it instead. The generator's
     * gate sems (value/version/seq/status) are all integer slots   */
    if (ed && ed->cls == 2 && ed->cond_sem != 0) {
        const proto_schema_t *gsc = ps_schema_for(opcode);
        int gslot = gsc ? ps_sem_slot(gsc, ed->cond_sem, 0) : -1;
        if (gslot >= 0) {
            uint32_t v = ed->cond_operand;
            if (vgate) {          /* violate: below/above the gate */
                if (ed->cond_op == 2 || ed->cond_op == 3)
                    v = v > 0 ? v - 1 : 0;
                else if (ed->cond_op == 4 || ed->cond_op == 5)
                    v = v + 1;
                else v = v ^ 1u;
            }
            m->ints[gslot] = v;
        }
    }
}

/* fire one edge end-to-end: HELLO/AUTH get their special handling,
 * everything else rides the generic request/reply cycle. Returns 0 on
 * the ACK (or expected ERR), -1 dead, -3 ERR arrived. */
static int cli_fire_edge(int fd, proto_session_t *s,
                         proto_reader_t *rd, ps_fsm_edge_t *ed,
                         int vgate, uint32_t *flag_tok) {
    proto_msg_t m, r;
    int rc, want = ack_of(ed->opcode);
    if (ed->opcode == OP_AUTH)
        return cli_auth_stage(fd, s, rd, flag_tok);
    if (ed->opcode == OP_HELLO) {
        int htry;
        /* NO mask mirror here: the walker fires the HELLO edge as a
         * coverage item MID-SESSION, when the server is authed and
         * masked -- a raw HELLO would be unmasked (corrupted) by it.
         * The frame rides the session's CURRENT auth state; if the
         * server just downgraded, the -2 reconnect path absorbs the
         * drop (one reconnect, no deadlock)                      */
        cli_build_edge(s, ed->opcode, ed, vgate, &m, 0);
        for (htry = 0; htry < 3; htry++) {
            rc = cli_txn(fd, s, rd, &m, OP_HELLO_ACK, &r, 0);
            if (rc != -3 && rc != -2) break;  /* ERR: retry (errhello);
                                              * an absorbed control
                                              * frame (-2, the grant
                                              * trailing a re-AUTH)
                                              * re-drives as well    */
        }
        if (rc != 0) return rc;
        {
            const proto_schema_t *ha = ps_schema_for(OP_HELLO_ACK);
            int nslot = ps_sem_slot(ha, PSEM_NONCE, 0);
            int pslot = ps_sem_slot(ha, PSEM_KEY, 0);
            if (nslot >= 0) px_client_set_nonce(s, r.blobs[nslot]);
            if (pslot >= 0) {
                memcpy(s->server_pub, r.blobs[pslot], 32);
                s->have_server_pub = 1;
            }
        }
        return 0;
    }
    cli_build_edge(s, ed->opcode, ed, vgate, &m, *flag_tok);
    if (ed->opcode == OP_MUX_OPEN)
        s->mux_wait_open = 0;   /* cli_txn arms it post-dance */
    rc = cli_txn(fd, s, rd, &m, want, &r, g_traverse ? 0 : 1);
    if (rc == -3) {
        /* LOCAL class recovery only (re-auth / credit refill / channel
         * re-announce / txn re-open): the walker owns ROUTING -- the
         * global re-ladder here would land the retry at the wrong
         * state and burn the connection                     */
        int cr = cli_class_recover(fd, s, rd, &r, flag_tok,
                                    1 /* local only */);
        if (cr == 0 && r.ints[0] != PROTO_ERR_RESYNC)
            rc = cli_txn(fd, s, rd, &m, want, &r, 1);
        else if (cr == 0)
            /* the RESYNC recovery re-laddered to mode0: DO NOT retry
             * here -- the edge may be invalid at mode0 (FLAG lives at
             * the last mode). Return the -3 so the walk re-navigates
             * and fires fresh at the correct state             */
            rc = -3;
    }
    if (rc != 0) {
        if (rc == -3)
            g_last_err = (int)(uint8_t)r.ints[0];
        if (getenv("DBG_EVT") && rc == -3)
            fprintf(stderr, "FIRE-ERR op=%02x code=%02x\n",
                    ed->opcode, (unsigned)(uint8_t)r.ints[0]);
        return rc;   /* keep -3 ERR and -2 interrupted-apart: folding
                      * -2 into -1 defeated the hop re-drive in
                      * cli_traverse_to (the trailing-grant absorb
                      * after a re-AUTH surfaced as -2 mid-hop) and
                      * killed connections that were still live     */
    }
    if (ed->opcode == OP_PARAMS) {
        const proto_schema_t *pa = ps_schema_for(OP_PARAMS_ACK);
        int tslot = ps_sem_slot(pa, PSEM_TOKEN, 0);
        int vslot = ps_sem_slot(pa, PSEM_VALUE, 0);
        if (tslot >= 0) *flag_tok = (uint32_t)r.ints[tslot];
        else if (vslot >= 0) *flag_tok = (uint32_t)r.ints[vslot];
        else if (r.ints[1]) *flag_tok = (uint32_t)r.ints[1];
    }
    return 0;
}

/* in-band re-ladder/recovery: navigate the table spine from the entry
 * back to a working state (the resync/reauth recovery path under the
 * rich graph) */
static int cli_handshake_from(int fd, proto_session_t *s,
                              proto_reader_t *rd, uint32_t *flag_tok,
                              int resume, int from);
static int cli_handshake(int fd, proto_session_t *s, proto_reader_t *rd,
                         uint32_t *flag_tok, int resume) {
    return cli_handshake_from(fd, s, rd, flag_tok, resume,
                              ps_fsm_entry());
}


/* same ladder, starting from an arbitrary live state (the resync
 * recovery's declared edge may land mid-spine -- the entry-relative
 * hops behind the landing point are already behind the SERVER too) */
static int cli_handshake_from(int fd, proto_session_t *s,
                              proto_reader_t *rd, uint32_t *flag_tok,
                              int resume, int from) {
    int path[64];
    int mode0 = ps_fsm_find_kind(3);
    int len, i;
    s->authed = 0;
    if (getenv("DBG_EVT")) fprintf(stderr, "AUTH0 site%d\n", 1);
    s->tx_ctr = s->rx_ctr = 0;
    if (!resume) s->has_resume = 0;
    if (mode0 < 0) mode0 = ps_fsm_entry();
    len = cli_path_to(from, mode0, path, 64);
    if (len < 0) return -1;
    {
        int st = from;
        for (i = 0; i < len; i++) {
            ps_fsm_edge_t ed;
            int k, rc = -1;
            for (k = 0; k < 24; k++) {
                if (ps_fsm_edge_at(st, k, &ed) != 0) break;
                if ((ed.next == 0xFF ? st : ed.next) != path[i]) continue;
                if (ed.cls == 3) continue;
                {
                    /* a -2 (control frame absorbed mid-wait, e.g. the
                     * grant trailing a re-AUTH) re-drives the SAME hop
                     * -- the ladder edge is idempotent at its state   */
                    int hd;
                    for (hd = 0; hd < 3; hd++) {
                        if (hd > 0 && !s->redirect_consumed)
                            s->suppress_seq_bump = 1; /* retransmit */
                        rc = cli_fire_edge(fd, s, rd, &ed, 0,
                                           flag_tok);
                        s->suppress_seq_bump = 0; /* no-send bail
                                                  * must not leak  */
                        if (getenv("DBG_EVT"))
                            fprintf(stderr, "HS-HOP st=%d next=%d "
                                    "hd=%d rc=%d\n", st, path[i], hd,
                                    rc);
                        if (rc != -2) break;
                    }
                }
                break;
            }
            if (rc != 0) return -1;
            cli_book_mark(st, ed.opcode, path[i]);
            st = path[i];
            s->state = st;          /* keep the mirror on the path */
        }
    }
    s->state = mode0;
    return 0;
}

/* recovery for any fault that downgraded the server into an error
 * state (RESYNC class, or the TOKEN refusal whose injection also
 * downgrades): fire the error state's DECLARED recovery edge -- the
 * table names the move (a HELLO on most forms, but the graph decides,
 * not this function) -- then the ordinary handshake from the entry */
static int cli_resync_recover_code(int fd, proto_session_t *s,
                                   proto_reader_t *rd,
                                   uint32_t *flag_tok, int err_code);

static int cli_resync_recover(int fd, proto_session_t *s,
                              proto_reader_t *rd, uint32_t *flag_tok) {
    return cli_resync_recover_code(fd, s, rd, flag_tok, -1);
}

static int cli_resync_recover_code(int fd, proto_session_t *s,
                                   proto_reader_t *rd,
                                   uint32_t *flag_tok, int err_code) {
    proto_msg_t hm, hr;
    int hrc, htry;
    int es = ps_fsm_find_kind(5), ek;
    ps_fsm_edge_t rec;
    int have_rec = 0;
    memset(&hm, 0, sizeof hm);
    /* an ORGANIC resync (the error-state reply class) left the server
     * AUTHED -- its declared recovery edge fires masked just fine, so
     * try that FIRST and keep the session: only a true downgrade
     * needs the clear re-ladder below                     */
    int probe_ok = 0;                 /* ACK: the server MOVED along
                                       * the declared edge -- the
                                       * routing must follow it    */
    if (es >= 0 && s->authed) {
        for (ek = 0; ek < WK_MAX_EDGES; ek++) {
            ps_fsm_edge_t mrec;
            proto_msg_t mtry;
            proto_msg_t mrpl;
            int mrc;
            if (ps_fsm_edge_at(es, ek, &mrec) != 0) break;
            if (mrec.cls == 3) continue;
            cli_build_edge(s, mrec.opcode, &mrec, 0, &mtry, 0);
            /* a FAST probe: on a true downgrade this frame is dropped
             * and a full read clock burns 6s per recovery -- the lite
             * budgets die. Half a second names in-band from dead */
            s->chan = s->chan_active;
            if (send_msg(s, fd, &mtry) == 0) {
                mrc = cli_read_expect_ms(fd, s, rd,
                                         ack_of(mrec.opcode),
                                         &mrpl, 500);
                if (mrc == 0) {
                    /* the server answered: it took the declared edge
                     * and now sits at the edge's LANDING -- mirror
                     * nothing, but the client's routing must catch
                     * up (the ladder below walks it)             */
                    probe_ok = 1;
                    rec = mrec;
                    have_rec = 1;
                    hrc = 0;
                } else if (mrc == 1) {
                    /* an ERR answer to the masked try: the server is
                     * LIVE and authed AT ITS CURRENT STATE (a dropped
                     * probe frame is what a true downgrade looks
                     * like). The organic case must NOT mirror: the
                     * caller re-fires in place and its round/flag
                     * logic owns the rest                        */
                    return 0;
                }
            }
            break;                    /* first declared edge only   */
        }
    }
    (void)probe_ok;
    /* the downgrade that brought us here dropped the server's authed
     * AND reset its C-layer record counters (the X2 mask, the C-keyed
     * records and the proofs all key off them): mirror all three NOW
     * -- but ONLY for the true downgrade classes. A CREDIT/CHANNEL
     * class ERR did NOT downgrade the server: mirroring there keys
     * the recovery frames raw against the still-authed server and
     * every one dies as forgery (the drip-mode cascade)        */
    if (!probe_ok &&
        (err_code == PROTO_ERR_RESYNC
         || err_code == PROTO_ERR_REAUTH || err_code == PROTO_ERR_TOKEN
         || err_code == PROTO_ERR_AUTH
         || err_code == PROTO_ERR_UNKNOWN)) {
        s->authed = 0;
        if (getenv("DBG_EVT"))
            fprintf(stderr, "AUTH0 resync code=%02x\n",
                    (unsigned)(uint8_t)err_code);
        s->tx_ctr = s->rx_ctr = 0;
        /* seq renumber ONLY for the flag-position faults (TOKEN,
         * UNKNOWN): those downgrades leave no in-flight exchange, so
         * numbering from zero on both sides is exact. The RESYNC fault
         * strikes mid-flight -- a zeroed sequence makes the pending
         * retransmit land as a fresh frame and double-advance a
         * gated edge, so it keeps the old numbering and the proof
         * window absorbs the skew.                         */
        if (err_code == PROTO_ERR_TOKEN
            || err_code == PROTO_ERR_UNKNOWN) {
            s->my_seq = s->peer_seq = 0;
        }
    }
    if (es >= 0) {
        for (ek = 0; ek < WK_MAX_EDGES; ek++) {
            if (ps_fsm_edge_at(es, ek, &rec) != 0) break;
            if (rec.cls == 3) continue;
            have_rec = 1;
            break;
        }
    }
    if (have_rec) {
        /* the declared recovery edge: fire its opcode as built, then
         * ladder from its LANDING state (mid-spine landings skip the
         * entry-relative hops the server is already past)          */
        int land;
        proto_msg_t hm2;
        memset(&hm2, 0, sizeof hm2);
        hm2.opcode = OP_HELLO;
        hm2.ints[0] = PROTO_VERSION;
        hm2.ints[1] = 0x0003;
        if (!probe_ok) {
            /* the probe already drove the server down this exact edge:
             * firing it AGAIN advances the server one hop PAST the
             * landing, and the ladder's first hop then arrives at a
             * state that does not name that opcode -- an ERR for
             * every retry, the connection dies on a recovered fault */
            cli_build_edge(s, rec.opcode, &rec, 0, &hm, 0);
            for (htry = 0; htry < 3; htry++) {
                hrc = cli_txn(fd, s, rd, &hm, ack_of(rec.opcode), &hr, 0);
                if (hrc != -3 && hrc != -2) break;
            }
        }
        if (hrc != 0) {
            /* the FIRST error state's declared edge is not the one
             * this downgrade entered (several error states exist):
             * fire each error state's declared edge ONCE -- a miss
             * does not move the server, a hit walks it to that edge's
             * landing. NO bare HELLO ever: a bare HELLO fires at
             * whatever state the server is in and mutates it blindly
             * (the ghost-ACK cascade)                          */
            int es2, ek2, ns2 = ps_fsm_n_states();
            for (es2 = 0; es2 < ns2 && es2 < WK_MAX_STATES; es2++) {
                ps_fsm_edge_t rec2;
                if (!ps_fsm_is_kind(es2, 5)) continue;
                for (ek2 = 0; ek2 < WK_MAX_EDGES; ek2++) {
                    proto_msg_t hm3;
                    if (ps_fsm_edge_at(es2, ek2, &rec2) != 0) break;
                    if (rec2.cls == 3) continue;
                    cli_build_edge(s, rec2.opcode, &rec2, 0, &hm3, 0);
                    hrc = cli_txn(fd, s, rd, &hm3,
                                  ack_of(rec2.opcode), &hr, 0);
                    if (hrc == 0) {
                        int land2 = rec2.next == 0xFF ? es2
                                                      : rec2.next;
                        return cli_handshake_from(fd, s, rd, flag_tok,
                                                  0, land2);
                    }
                    if (hrc == -1) return -1;
                    break;         /* one edge per error state   */
                }
            }
            for (htry = 0; htry < 3; htry++) {
                hrc = cli_txn(fd, s, rd, &hm2, OP_HELLO_ACK, &hr, 0);
                if (hrc != -3 && hrc != -2) break;
            }
            if (hrc != 0) return -1;
            return cli_handshake_from(fd, s, rd, flag_tok, 0,
                                      ps_fsm_entry());
        }
        land = rec.next == 0xFF ? es : rec.next;
        return cli_handshake_from(fd, s, rd, flag_tok, 0, land);
    } else {
        /* no declared recovery edge anywhere: same no-spray rule, the
         * conn is spent */
        return -1;
    }
    return cli_handshake(fd, s, rd, flag_tok, 0);
}

/* mid-session ERR recovery, by error-code class. Returns 0 = a class
 * branch was applied (caller resends the command), 1 = no class
 * matched (the generic re-ladder applies), -1 = fatal.
 *   REAUTH  re-run the AUTH stage alone (S5 downgrade)
 *   CREDIT  refill the window via the mux dance (L3)
 *   CHANNEL re-announce via a control-channel open (L2)
 *   STATE   re-open the transaction group (S6 bracket tear)        */
static int cli_class_recover(int fd, proto_session_t *s,
                             proto_reader_t *rd, const proto_msg_t *err,
                             uint32_t *flag_tok, int local_only) {
    proto_msg_t m, r;
    if (PROTO_S_LEVEL >= 5 && err->ints[0] == PROTO_ERR_REAUTH) {
        s->authed = 0;
        if (getenv("DBG_EVT")) fprintf(stderr, "AUTH0 site%d\n", 3);
        s->tx_ctr = s->rx_ctr = 0;
        return cli_auth_stage(fd, s, rd, flag_tok);
    }
    if (PROTO_L_LEVEL >= 3 && err->ints[0] == PROTO_ERR_CREDIT) {
        s->credit = 0;
        return 0;
    }
    if (PROTO_L_LEVEL >= 2 && err->ints[0] == PROTO_ERR_CHANNEL) {
        int stale = s->chan_active;
        int keep = s->chan;
        int tries;
        s->mux_opened = 0;
        s->chan = PROTO_L_CHAN_BASE;
        memset(&m, 0, sizeof m);
        m.opcode = OP_MUX_OPEN;
        m.ints[0] = (uint64_t)(unsigned)s->chan_active;
        m.ints[1] = PROTO_L_CREDIT_INIT;
        if (send_msg(s, fd, &m)) { s->chan = keep; return -1; }
        for (tries = 0; tries < 3 && s->chan_active == stale; tries++) {
            int rc = cli_read_expect_ms(fd, s, rd, -0x7FFF, &r, 300);
            if (rc == -1) { s->chan = keep; return -1; }
            if (rc == 1) break;
        }
        s->chan = keep;
        return 0;
    }
    if (PROTO_S_LEVEL >= 6 && err->ints[0] == PROTO_ERR_STATE) {
        memset(&m, 0, sizeof m);
        m.opcode = OP_TXN_BEGIN;
        m.ints[0] = 0;
        if (cli_txn(fd, s, rd, &m, OP_OK, &r, 1) != 0) return -1;
        return 0;
    }
    if (PROTO_S_LEVEL >= 3 && err->ints[0] == PROTO_ERR_RESYNC
        && !local_only)
        return cli_resync_recover_code(fd, s, rd, flag_tok,
                                       PROTO_ERR_RESYNC);
    if (err->ints[0] == PROTO_ERR_UNKNOWN && !local_only) {
        /* the unknown-in-place-of-reply fault downgrades like the
         * organic resync (position is re-established by redoing the
         * ladder): recover in the clear and resume from mode0. The
         * ORGANIC dispatch-unknown (a schema-less op) only answers
         * probes, which never reach the class recovery        */
        return cli_resync_recover_code(fd, s, rd, flag_tok,
                                       PROTO_ERR_UNKNOWN);
    }
    if (PROTO_S_LEVEL >= 2 && err->ints[0] == PROTO_ERR_TOKEN
        && !local_only) {
        /* the refused-valid-token fault downgrades like the organic
         * resync (the refusal means re-run the ladder): recover in
         * the clear and re-derive the flag token from the fresh
         * PARAMS_ACK -- the class contract's fresh-token ladder */
        return cli_resync_recover_code(fd, s, rd, flag_tok,
                                       PROTO_ERR_TOKEN);
    }
    /* local_only (the fire-edge's internal recovery): the RESYNC
     * re-ladder is ROUTING -- a nested ladder here would recurse
     * (fire -> recover -> ladder -> fire ...) and blow the stack;
     * the caller sees the -3 and re-navigates instead        */
    return 1;
}

/* command with the full S-level recovery ladder: an ERR answer first
 * runs the per-class branch (re-auth / credit refill / channel
 * re-announce / txn re-open), looping so a second, DIFFERENT class
 * arriving on the recovery retry (e.g. the S5 re-auth after a txn
 * re-open) gets its own branch instead of the generic ladder; any
 * other mid-session err (S>=3) re-runs the whole handshake.        */
static int cli_cmd(proto_session_t *s, int fd, proto_reader_t *rd,
                   proto_msg_t *m, int want, proto_msg_t *out,
                   uint32_t *flag_tok) {
    int rc = cli_txn(fd, s, rd, m, want, out, 1);
    int stage;
    for (stage = 0; stage < 3 && rc == -3; stage++) {
        int cr = cli_class_recover(fd, s, rd, out, flag_tok, 0);
        if (cr < 0) return -1;
        if (cr == 0) {
            rc = cli_txn(fd, s, rd, m, want, out, 1);
            continue;
        }
        break;                  /* no class matched: generic ladder  */
    }
    if (rc == -3 && PROTO_S_LEVEL >= 3) {
        if (cli_handshake(fd, s, rd, flag_tok, 0)) return -1;
        rc = cli_txn(fd, s, rd, m, want, out, 1);
        for (stage = 0; stage < 2 && rc == -3; stage++) {
            int cr = cli_class_recover(fd, s, rd, out, flag_tok, 0);
            if (cr < 0) return -1;
            if (cr == 0) {
                rc = cli_txn(fd, s, rd, m, want, out, 1);
                continue;
            }
            break;
        }
    }
    return rc;
}

/* ------------------------------------------------------------------ */
/* the GT walk planner: full-coverage traversal of the dialog graph.
 * The book (walked edges/states) persists ACROSS connections inside
 * one invocation, so a fresh connection resumes the plan where the
 * last one ended (close edges terminate a connection by nature, and
 * downgrade/reauth transitions re-enter from the spine).           */
/* ------------------------------------------------------------------ */
/* (WK_MAX_STATES / WK_MAX_EDGES live at the top: the resync recovery
 * reads the walk table as well)                                     */

typedef struct {
    uint8_t edge[WK_MAX_STATES][WK_MAX_EDGES];
    uint8_t tmo[WK_MAX_STATES];
    uint8_t att[WK_MAX_STATES][WK_MAX_EDGES]; /* refused-fire budget */
    int     rounds;               /* command rounds completed        */
} walk_book_t;

static walk_book_t g_book;
static uint8_t g_close_tried[WK_MAX_STATES];  /* close-pass attempts */
static uint8_t g_tmo_tried[WK_MAX_STATES];   /* timeout-pass attempts */        /* per-invocation (thread-local in
                                    * the --parallel case via CLS)   */
static int g_lite_walk = 0;     /* 1: skip deliberate timeout sleeps */
static int g_lite_rounds = 5;   /* command rounds a lite session runs */
static int g_prev_cmd_k = -1;   /* rotation: last fired command edge */
static int g_traverse = 0;    /* 1: pure traversal -- no retransmits */

void proto_client_set_lite(int on) { g_lite_walk = on; }

/* mark a fired edge in the walk book: the handshake and traversal
 * fire spine edges WITHOUT the k-scan -- unmarked, every later k-scan
 * pass re-fires the advancing edge and breaks before the edges behind
 * it (the ping/stat self edges and the declared probes at spine states
 * were unreachable by construction)                          */
static void cli_book_mark(int st, int opcode, int nxt) {
    int k;
    for (k = 0; k < WK_MAX_EDGES; k++) {
        ps_fsm_edge_t e;
        if (ps_fsm_edge_at(st, k, &e) != 0) break;
        if (e.opcode == (uint8_t)opcode
            && (e.next == 0xFF ? st : e.next) == nxt) {
            g_book.edge[st][k] = 1;
            return;
        }
    }
}

/* traverse already-walked success edges from `from` to `target`
 * (pure traversal: fires each path edge but never touches the book) */
static int cli_traverse_to(int fd, proto_session_t *s,
                           proto_reader_t *rd, int from, int target,
                           uint32_t *flag_tok) {
    if (getenv("DBG_EVT"))
        fprintf(stderr, "TRAVERSE from=%d to=%d\n", from, target);
    int path[64];
    g_traverse = 1;   /* pure traversal: a slow ACK must not spawn a
                       * retransmit whose echo bounces as an ERR at the
                       * ARRIVED state and kills the navigation     */
    int len, i, st = from;
    if (target < 0 || target == from) return 0;
    len = cli_path_to(from, target, path, 64);
    if (len < 0) {
        if (getenv("DBG_EVT"))
            fprintf(stderr, "NAV-NOPATH from=%d to=%d\n", from, target);
        return -1;
    }
    for (i = 0; i < len; i++) {
        ps_fsm_edge_t ed;
        int k, rc = -1, tries2;
        for (k = 0; k < 32; k++) {
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if ((ed.next == 0xFF ? st : ed.next) != path[i]) continue;
            if (ed.cls == 3) continue;
            for (tries2 = 0; tries2 < 3; tries2++) {
                if (tries2 > 0 && !s->redirect_consumed)
                    s->suppress_seq_bump = 1;  /* retransmit: same
                                                * record number; a
                                                * redirect consume
                                                * rides a fresh one */
                rc = cli_fire_edge(fd, s, rd, &ed, 0, flag_tok);
                /* an early bail (ERR class paths) never sent: the
                 * flag must not leak onto the NEXT unrelated send */
                s->suppress_seq_bump = 0;
                if (getenv("DBG_EVT"))
                    fprintf(stderr, "NAV-HOP st=%d next=%d k=%d "
                            "try=%d rc=%d\n", st, path[i], k, tries2,
                            rc);
                if (rc != -2) break;  /* a slow ACK times out once;
                                       * give the hop two more turns
                                       * before declaring defeat   */
            }
            break;
        }
        if (rc != 0) { g_traverse = 0; return -1; }
        cli_book_mark(st, ed.opcode, path[i]);
        st = path[i];
        s->state = st;
    }
    g_traverse = 0;
    return 0;
}

static int cli_state_open(int st, int skipk);
static int cli_unwalked_open(void);

/* nearest state (BFS over success edges) holding an unmarked edge */
static int cli_nearest_unwalked(int from) {
    int q[64], qh = 0, qt = 0, prev[64], i, n = ps_fsm_n_states();
    if (n > 64) n = 64;
    for (i = 0; i < n; i++) prev[i] = -2;
    prev[from] = -1;
    q[qt++] = from;
    while (qh < qt) {
        int st = q[qh++], k;
        for (k = 0; k < WK_MAX_EDGES; k++) {
            ps_fsm_edge_t ed;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if (g_book.edge[st][k]) continue;
            if (g_book.att[st][k] >= 3) continue;
            /* closes are the close pass's domain: an ack answered
             * from the WRONG state (a recovery desync) marks this
             * edge done while the oracle logs another state's
             * transition -- the scorer then rightly counts the real
             * one missing. The comment sits on its own lines: the
             * fleet roll's comment-clean transform eats code that
             * shares its line with a trailing block comment.      */
            if (ed.opcode == OP_BYE)
                continue;
            return st;
        }
        for (k = 0; k < 32; k++) {
            ps_fsm_edge_t ed;
            int nx;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if (ed.cls == 3) continue;
            nx = ed.next == 0xFF ? st : ed.next;
            if (nx < n && prev[nx] == -2) {
                prev[nx] = st;
                q[qt++] = nx;
            }
        }
    }
    return -1;
}

/* error-state sweep: an error state's recovery edges are unreachable
 * once its ENTRY role's success edge is marked (the walk stops firing
 * it), so re-fire the downgrade entry deliberately, walk the error
 * state, and return to the caller for a fresh k-scan there        */
static int cli_sweep_errors(int fd, proto_session_t *s,
                            proto_reader_t *rd, int *st,
                            uint32_t *flag_tok) {
    int es, ek, ns = ps_fsm_n_states();
    for (es = 0; es < ns && es < WK_MAX_STATES; es++) {
        int need = 0, src = -1, sk = -1, k;
        ps_fsm_edge_t ent;
        memset(&ent, 0, sizeof ent);
        if (!ps_fsm_is_kind(es, 5)) continue;
        for (ek = 0; ek < WK_MAX_EDGES; ek++) {
            ps_fsm_edge_t ee;
            if (ps_fsm_edge_at(es, ek, &ee) != 0) break;
            if (ee.cls != 3 && !g_book.edge[es][ek]) { need = 1; break; }
        }
        if (!need) continue;
        for (k = 0; k < ns && src < 0; k++) {
            if (!ps_fsm_is_kind(k, 3)) continue;
            {
                int kk;
                for (kk = 0; kk < WK_MAX_EDGES; kk++) {
                    ps_fsm_edge_t ee;
                    if (ps_fsm_edge_at(k, kk, &ee) != 0) break;
                    if (g_book.edge[k][kk]) continue;
                    if (ee.cls == 3 && ee.next == es) {
                        src = k; sk = kk; ent = ee; break;
                    }
                }
            }
        }
        if (src < 0) continue;
        if (cli_traverse_to(fd, s, rd, *st, src, flag_tok))
            return -1;
        *st = src;
        s->state = src;
        {
            proto_msg_t m;
            int rc;
            cli_build_edge(s, ent.opcode, NULL, 0, &m, *flag_tok);
            s->chan = s->chan_active;
            rc = cli_txn(fd, s, rd, &m, ack_of(ent.opcode), &m, 0);
            if (rc == -1) return -1;
            g_book.edge[src][sk] = 1;
            if (rc == -3) {          /* the downgrade entered es */
                *st = es;
                s->state = es;
                s->authed = 0;   /* the server dropped authed with the
                                  * downgrade: mirror it or the masked
                                  * recovery frames die as forgeries  */
                s->tx_ctr = s->rx_ctr = 0;  /* ...and the C-layer
                                  * record counters restart at zero:
                                  * a ctr-only mirror halves the
                                  * desync into a tag-fail cascade */
            }
        }
        return 1;
    }
    return 0;
}

/* lite session: the SURVIVAL contract -- a compact linear client
 * (handshake spine -> commands at the first mode -> navigate to the
 * flag mode -> flag -> close), riding cli_txn's retransmit and the
 * class recovery (which re-ladders on RESYNC). The full-coverage
 * walker is the verifier's business, not the selftest's.          */
static int cli_lite_conn(int fd, char *flag_out, size_t flag_cap) {
    proto_session_t s;
    proto_reader_t rd;
    proto_msg_t m, r;
    uint32_t flag_tok = 0;
    int st;

    px_session_init(&s, 0);
    memset(&rd, 0, sizeof rd);
    s.is_udp = (PROTO_T_LEVEL == 1);
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    s.mux_opened = (PROTO_L_LEVEL < 2);
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30;

    if (cli_handshake(fd, &s, &rd, &flag_tok, 0))
        return -1;
    st = ps_fsm_find_kind(3);
    if (st < 0) st = ps_fsm_entry();

    /* command rounds at the first mode -- the survival contract is a
     * real session (handshake -> TALK -> flag -> close), and the
     * verifier's converse counter rides these exchanges. The mode's
     * self command edges rotate; an S6-bracketed edge opens a group
     * (TXN_BEGIN) and closes it (TXN_COMMIT) around the command   */
    {
        int nround;
        for (nround = 0; nround < g_lite_rounds; nround++) {
            ps_fsm_edge_t ce;
            int k, found = -1;
            for (k = 0; k < WK_MAX_EDGES; k++) {
                if (ps_fsm_edge_at(st, k, &ce) != 0) break;
                if (ce.cls != 0) continue;
                if (ce.opcode != OP_SET && ce.opcode != OP_GET
                    && ce.opcode != OP_SUM)
                    continue;
                if ((ce.next == 0xFF ? st : ce.next) != st)
                    continue;  /* rounds are TALK, not coverage: fire
                                * only HOLDING commands -- an advancing
                                * edge fired bare walks the server out
                                * from under the round loop       */
                if (nround && k == g_prev_cmd_k)
                    continue;      /* rotate: skip the previous one */
                found = k;
                break;
            }
            if (found < 0 && g_prev_cmd_k >= 0) {
                /* single-command mode: re-fire the previous edge    */
                for (k = 0; k < WK_MAX_EDGES; k++) {
                    if (ps_fsm_edge_at(st, k, &ce) != 0) break;
                    if (ce.cls == 0 && (ce.opcode == OP_SET
                                        || ce.opcode == OP_GET
                                        || ce.opcode == OP_SUM)
                        && (ce.next == 0xFF ? st : ce.next) == st) {
                        found = k;
                        break;
                    }
                }
            }
            if (found < 0) break;         /* the mode takes no talk */
            {
                ps_fsm_edge_t cmd;
                int crc, cretry;
                ps_fsm_edge_at(st, found, &cmd);
                if (cmd.flags & 2) {
                    proto_msg_t tb;
                    int bk;
                    ps_fsm_edge_t be;
                    memset(&tb, 0, sizeof tb);
                    tb.opcode = OP_TXN_BEGIN;
                    if (cli_txn(fd, &s, &rd, &tb, OP_OK, &r, 1) < 0)
                        break;            /* group refused: hold    */
                    /* a draw can declare the begin edge ADVANCING (the
                     * group opens at the NEXT mode, which carries its
                     * OWN round op): follow the landing so the round
                     * command fires where the server actually sits --
                     * the rounds then ride the mode chain       */
                    for (bk = 0; bk < WK_MAX_EDGES; bk++) {
                        if (ps_fsm_edge_at(st, bk, &be) != 0) break;
                        if (be.opcode == OP_TXN_BEGIN && be.cls != 3) {
                            int bn = be.next == 0xFF ? st : be.next;
                            if (bn != st) {
                                int rk;
                                ps_fsm_edge_t re;
                                st = bn;
                                s.state = st;
                                /* the landed mode carries ITS OWN round
                                 * op (single-command modes): re-pick or
                                 * the departed mode's op is refused  */
                                for (rk = 0; rk < WK_MAX_EDGES; rk++) {
                                    if (ps_fsm_edge_at(st, rk, &re) != 0)
                                        break;
                                    if (re.cls != 0) continue;
                                    if (re.opcode != OP_SET
                                        && re.opcode != OP_GET
                                        && re.opcode != OP_SUM)
                                        continue;
                                    if ((re.next == 0xFF ? st : re.next)
                                        != st)
                                        continue;
                                    cmd = re;
                                    found = rk;
                                    break;
                                }
                            }
                            break;
                        }
                    }
                }
                crc = cli_fire_edge(fd, &s, &rd, &cmd, 0, &flag_tok);
                if (crc == -1)
                    return -1;
                /* a fault can strike mid-rounds (the organic resync
                 * downgrade, or the C19 unknown-ERR in place of the
                 * reply): run the class recovery, and if it re-ladder
                 *ed us, resume the rounds from the first mode      */
                for (cretry = 0; cretry < 2 && crc == -3; cretry++) {
                    int cr;
                    /* the fire's ERR code lives in g_last_err: the
                     * outer reply slot is STALE here (the fire reads
                     * its own), and a class recovery keyed on a stale
                     * code matches no branch and skips the recovery
                     * entirely -- the conn then dies to the fault it
                     * should have survived                       */
                    memset(&r, 0, sizeof r);
                    r.opcode = OP_ERR;
                    r.ints[0] = g_last_err;
                    cr = cli_class_recover(fd, &s, &rd, &r,
                                           &flag_tok, 0);
                    if (cr < 0) return -1;
                    if (cr != 0) {
                        /* an UNHANDLED class (nothing downgraded, the
                         * server still stands at the mode state): the
                         * nuclear re-ladder mirrors a downgrade that
                         * never happened and kills the conn for every
                         * later round -- the round is best-effort
                         * talk, the flag attempt owns the recovery */
                        g_prev_cmd_k = found;
                        crc = -3;
                        break;
                    }
                    st = ps_fsm_find_kind(3);
                    if (st < 0) st = ps_fsm_entry();
                    s.state = st;
                    crc = cli_fire_edge(fd, &s, &rd, &cmd, 0,
                                        &flag_tok);
                    if (crc == -1) return -1;
                }
                if (crc != 0) {
                    /* the round burned and its recovery failed: the
                     * rounds are best-effort talk, retrying a failed
                     * recovery once per round burned minutes on the
                     * faulted draws (the flag retry owns recovery) */
                    g_prev_cmd_k = found;
                    break;
                }
                g_prev_cmd_k = found;
                if (cmd.flags & 2) {
                    proto_msg_t tc;
                    memset(&tc, 0, sizeof tc);
                    tc.opcode = OP_TXN_COMMIT;
                    (void)cli_txn(fd, &s, &rd, &tc, OP_OK, &r, 1);
                }
                g_book.rounds++;
            }
        }
    }

    /* navigate to the mode carrying the FLAG accept edge, fire it */
    {
        int ns = ps_fsm_n_states(), ss, kk, tgt = -1;
        for (ss = 0; ss < ns && tgt < 0; ss++)
            for (kk = 0; kk < WK_MAX_EDGES; kk++) {
                ps_fsm_edge_t ed;
                if (ps_fsm_edge_at(ss, kk, &ed) != 0) break;
                if (ed.cls == 1 && ed.opcode == OP_FLAG) {
                    tgt = ss;
                    break;
                }
            }
        if (tgt >= 0 && tgt != st) {
            if (cli_traverse_to(fd, &s, &rd, st, tgt, &flag_tok))
                return -1;
            st = tgt;
        }
    }
    memset(&m, 0, sizeof m);
    m.opcode = OP_FLAG;
    if (PROTO_S_LEVEL >= 2) {
        char lb[12];
        px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
        m.ints[0] = flag_tok ? flag_tok : px_flag_token(&s, lb);
    }
    {
        int frc = cli_txn(fd, &s, &rd, &m, OP_FLAG_RES, &r, 1);
        if (frc == -3)
            g_last_err = (int)(uint8_t)r.ints[0];  /* the class
                * recovery below keys on this: the direct txn bypasses
                * cli_fire_edge's recording, and a stale code matches
                * no branch -- the recovery silently never runs   */
        if (getenv("DBG_EVT"))
            fprintf(stderr, "FLAGFIRE op=%02x frc=%d err=%02x tok=%u\n",
                    m.opcode, frc,
                    (unsigned)(uint8_t)r.ints[0], flag_tok);
        if (frc == -3) {
            /* refused (or a downgrade rode the ERR): re-ladder for a
             * FRESH token, re-navigate to the FLAG mode, retry there.
             * Bounded re-drive: the FIRST retry takes the full ladder
             * (fresh token after a downgrade); later ERRs on the
             * re-fire are answered in place -- the server re-delivers
             * a flag whose reply a mid-session re-grant replaced   */
            int rtry;
            for (rtry = 0; rtry < 2 && frc == -3; rtry++) {
                if (getenv("DBG_EVT"))
                    fprintf(stderr, "RETRY-ENTER n=%d\n", rtry);
                if (rtry == 0) {
                    /* handled classes re-ladder inside; an UNHANDLED
                     * class keeps the conn -- the in-place re-fire
                     * below answers it (the nuclear ladder here
                     * mirrors a downgrade that never happened and
                     * kills the conn before the flag lands)      */
                    memset(&r, 0, sizeof r);
                    r.opcode = OP_ERR;
                    r.ints[0] = g_last_err;
                    (void)cli_class_recover(fd, &s, &rd, &r,
                                            &flag_tok, 0);
                    /* drain regardless of the outcome: a FAILED
                     * recovery leaves its bare-HELLO fallback's ERR
                     * replies queued, and the next cycle's ladder
                     * would misread one as its own hop's refusal */
                    cli_drain_replies(fd, &s, &rd, 30);
                    {
                        int ns2 = ps_fsm_n_states(), ss2, kk2;
                        int tgt2 = -1;
                        for (ss2 = 0; ss2 < ns2 && tgt2 < 0; ss2++)
                            for (kk2 = 0; kk2 < WK_MAX_EDGES; kk2++) {
                                ps_fsm_edge_t ed2;
                                if (ps_fsm_edge_at(ss2, kk2, &ed2) != 0)
                                    break;
                                if (ed2.cls == 1
                                    && ed2.opcode == OP_FLAG) {
                                    tgt2 = ss2;
                                    break;
                                }
                            }
                        if (tgt2 < 0)
                            return -1;
                        if (getenv("DBG_EVT"))
                            fprintf(stderr,
                                    "RETRY-NAV from=%d tgt=%d state=%d "
                                    "mux=%d chan=%d cred=%d\n",
                                    ps_fsm_find_kind(3), tgt2, s.state,
                                    s.mux_opened, s.chan_active,
                                    s.credit);
                        if (cli_traverse_to(fd, &s, &rd,
                                            ps_fsm_find_kind(3) >= 0
                                            ? ps_fsm_find_kind(3)
                                            : ps_fsm_entry(),
                                            tgt2, &flag_tok))
                            return -1;
                    }
                } else {
                    /* later ERRs: a class branch may still apply
                     * (credit refill / channel move); otherwise the
                     * re-fire lands on the idempotent server path   */
                    (void)cli_class_recover(fd, &s, &rd, &r,
                                            &flag_tok, 1);
                }
                if (PROTO_S_LEVEL >= 2) {
                    char lb[12];
                    px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
                    m.ints[0] = flag_tok ? flag_tok
                        : px_flag_token(&s, lb);
                }
                if (getenv("DBG_EVT"))
                    fprintf(stderr, "RETRY op=%02x tok=%u\n",
                            m.opcode, flag_tok);
                frc = cli_txn(fd, &s, &rd, &m, OP_FLAG_RES, &r, 1);
                if (frc == -3)
                    g_last_err = (int)(uint8_t)r.ints[0];
                if (getenv("DBG_EVT"))
                    fprintf(stderr, "RETRY-DONE frc=%d op=%02x "
                            "err=%02x\n",
                            frc, r.opcode,
                            (unsigned)(uint8_t)r.ints[0]);
            }
        }
        if (frc == 0 && flag_out && r.strs[0][0]) {
            snprintf(flag_out, flag_cap, "%s", r.strs[0]);
            s.chan = s.chan_active;
            memset(&m, 0, sizeof m);
            m.opcode = OP_BYE;
            (void)cli_txn(fd, &s, &rd, &m, OP_BYE_ACK, &r, 0);
            return 0;
        }
    }
    return -1;
}

/* one connection's contribution to the plan: walk greedily from the
 * entry, firing every unwalked edge reachable in this connection
 * (success edges advance, err edges probe in place, close edges end
 * the connection). Returns 0 done-for-now, -1 connection dead. */
/* at a clean walk exit: the current state's close may still be
 * unmarked (an advancing edge in pass 1 moved the dialog before pass
 * 2 could fire it). The close is by nature the conn's LAST act -- so
 * fire it here, when the state holds nothing else, and let the conn
 * end with it                                              */
static void cli_close_on_exit(int fd, proto_session_t *s,
                              proto_reader_t *rd, int st,
                              uint32_t *flag_tok) {
    int k;
    for (k = 0; k < WK_MAX_EDGES; k++) {
        ps_fsm_edge_t ed;
        if (ps_fsm_edge_at(st, k, &ed) != 0) break;
        if (ed.opcode != OP_BYE || g_book.edge[st][k]) continue;
        if (cli_state_open(st, k)) return;   /* still work left here */
        {
            proto_msg_t m;
            int rc;
            g_book.edge[st][k] = 1;
            cli_build_edge(s, ed.opcode, &ed, 0, &m, *flag_tok);
            s->chan = s->chan_active;
            rc = cli_txn(fd, s, rd, &m, OP_BYE_ACK, &m, 0);
            if (rc != 0)
                g_book.edge[st][k] = 0;      /* not covered then */
        }
        return;
    }
}

/* any unmarked non-close edge AT this state (k excluded)? */
static int cli_state_open(int st, int skipk) {
    int k;
    for (k = 0; k < WK_MAX_EDGES; k++) {
        ps_fsm_edge_t ed;
        if (ps_fsm_edge_at(st, k, &ed) != 0) break;
        if (k == skipk) continue;
        if (g_book.edge[st][k]) continue;
        if (ed.opcode == OP_BYE) continue;
        return 1;
    }
    return 0;
}

/* any unmarked non-close edge left in the whole table? (close edges
 * fire LAST -- one per connection -- so they never cut a walk short) */
static int cli_unwalked_open(void) {
    int st, k, n = ps_fsm_n_states();
    if (n > WK_MAX_STATES) n = WK_MAX_STATES;
    for (st = 0; st < n; st++)
        for (k = 0; k < WK_MAX_EDGES; k++) {
            ps_fsm_edge_t ed;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if (g_book.edge[st][k]) continue;
            if (g_book.att[st][k] >= 3) continue;
            if (ed.opcode == OP_BYE) continue;
            return 1;
        }
    return 0;
}

static int cli_book_complete(void) {
    int st, k, n = ps_fsm_n_states();
    if (n > WK_MAX_STATES) n = WK_MAX_STATES;
    for (st = 0; st < n; st++)
        for (k = 0; k < WK_MAX_EDGES; k++) {
            ps_fsm_edge_t ed;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if (ed.opcode == OP_BYE) continue;  /* the close pass owns them */
            if (!g_book.edge[st][k]) return 0;
        }
    return 1;
}

static int cli_walk_conn(int fd, proto_session_t *s,
                         proto_reader_t *rd, char *flag_out,
                         size_t flag_cap, uint8_t tok_out[16],
                         uint8_t sec_out[32], int *did_flag) {
    uint32_t flag_tok = 0;
    int st = ps_fsm_entry();
    int guard = 0;
    s->state = st;
    s->state_enter_ms = 0;
    if (g_lite_walk)
        /* survival contract: every connection is a FRESH full attempt.
         * The chaos one-shot bits are per-connection on the server, so
         * a conn that ate the fault is followed by a clean one; a
         * shared book would navigate around edges the faulted conn
         * half-walked and strand the walk without the flag        */
        memset(g_book.edge, 0, sizeof g_book.edge);
    else if (!g_book.edge[0][0] && !g_book.tmo[0]) {
        /* first full walk of this invocation: the S5-carrier edges
         * (cls-3 with the reauth flag) are answered by the once-per-
         * connection forced-reauth interception -- their declared
         * transitions are structurally unreachable (the hold keeps
         * the dialog in place), so the destination states' edges
         * would read as forever-unwalked: they starve the close
         * deferral and the sweep. Mark them walked up front    */
        int q, qk, n = ps_fsm_n_states();
        for (q = 0; q < WK_MAX_STATES && q < n; q++) {
            for (qk = 0; qk < WK_MAX_EDGES; qk++) {
                ps_fsm_edge_t qe;
                int dn;
                if (ps_fsm_edge_at(q, qk, &qe) != 0) break;
                if (!(qe.flags & 4) || qe.cls != 3) continue;
                dn = qe.next == 0xFF ? q : qe.next;
                if (dn != q && ps_fsm_is_kind(dn, 5)) {
                    int rk;
                    for (rk = 0; rk < WK_MAX_EDGES; rk++) {
                        ps_fsm_edge_t re;
                        if (ps_fsm_edge_at(dn, rk, &re) != 0) break;
                        g_book.edge[dn][rk] = 1;
                    }
                }
            }
        }
    }
    /* no pre-handshake: the walk itself fires the ladder edges from
     * the entry (HELLO / value-gated negotiation / AUTH all ride the
     * same k-loop), so the negotiation states' OTHER edges -- their
     * declared error probes -- get walked too, not just traversed  */
    for (;;) {
        int k, pass, fired = 0;
        if (++guard > 512) {
            if (getenv("DBG_EVT"))
                fprintf(stderr, "WALK-EXIT guard\n");
            cli_close_on_exit(fd, s, rd, st, &flag_tok);
            return 0;          /* bounded walk        */
        }
        for (pass = 0; pass < 3; pass++)
        for (k = 0; k < WK_MAX_EDGES; k++) {
            ps_fsm_edge_t ed;
            int rc, nxt;
            if (ps_fsm_edge_at(st, k, &ed) != 0) break;
            if (g_book.edge[st][k]) continue;
            if (g_book.att[st][k] >= 3)
                continue;   /* a chronically refused edge must not
                             * starve the rest of the plan       */
            nxt = ed.next == 0xFF ? st : ed.next;
            /* two-pass: fire everything that HOLDS the state first
             * (self edges, in-place probes), then the advancing ones.
             * A single pass that advances mid-scan breaks before the
             * holding edges behind the advancer, and returning to the
             * state later costs a whole reconnect                */
            if (ed.opcode == OP_FLAG) {
                /* the session's goal fires before everything: probes
                 * and timeouts in front of it would starve a bounded
                 * caller (the build's interop smoke allows 45s)   */
                if (pass != 0) continue;
            } else if (ed.opcode == OP_BYE) {
                /* the close is an ADVANCING edge too: in a two-pass
                 * scan the mode-entry edge (lower k) advanced first
                 * and the close never fired. Pass 2 is closes-only */
                if (pass != 2) continue;
            } else if (pass == 0 && nxt != st && ed.cls != 3) {
                continue;
            } else if (pass >= 1 && (nxt == st || ed.cls == 3)) {
                continue;
            }
            if (g_lite_walk && ed.cls == 3)
                continue;             /* survival: no error probes  */
            /* closes are the close pass's domain, full stop:
             * firing one here marks it on an ack that any state's
             * close satisfies, and a recovery desync strands the
             * real edge uncovered. Own-line comment for the same
             * transform-safety reason as the entry scan above.   */
            if (ed.opcode == OP_BYE)
                continue;
            g_book.edge[st][k] = 1;
            fired = 1;
            nxt = ed.next == 0xFF ? st : ed.next;
            if (ed.cls == 3) {
                /* declared error edge: expect the class-coded ERR (or
                 * the S5 reauth branch) and follow the transition.
                 * A RAW cycle -- the ERR is the expected outcome, so
                 * the recovery ladder must NOT fire (a re-ladder here
                 * would desync the proof counters)                 */
                proto_msg_t m;
                cli_build_edge(s, ed.opcode, NULL, 0, &m, flag_tok);
                s->chan = s->chan_active;
                rc = cli_txn(fd, s, rd, &m, ack_of(ed.opcode), &m, 0);
                if (rc == -2) {
                    /* one same-record retransmit before giving the
                     * conn up: a lost reply consumed a record on the
                     * sender only, and the peer's duplicate tolerance
                     * covers exactly this. A redirect consume rides a
                     * fresh record (the dup would not fire the edge) */
                    s->suppress_seq_bump = s->redirect_consumed ? 0 : 1;
                    s->redirect_consumed = 0;
                    rc = cli_txn(fd, s, rd, &m, ack_of(ed.opcode),
                                 &m, 0);
                    s->suppress_seq_bump = 0;
                }
                if (rc == -1) {
                    g_book.edge[st][k] = 0;  /* dead conn: retry the
                                              * edge on the next one */
                    return -1;
                }
                if (getenv("DBG_EVT") && rc == -3)
                    fprintf(stderr, "PROBE st=%d op=%02x got=%02x "
                            "want=%02x\n", st, ed.opcode,
                            (unsigned)(uint8_t)m.ints[0], ed.err_code);
                if (rc == -2) {
                    /* the probe's reply never parsed (a mask-state
                     * desync elsewhere dropped it): every later frame
                     * on this conn is suspect -- unmark and drop the
                     * connection instead of cascading         */
                    g_book.edge[st][k] = 0;
                    return -1;
                }
                if (rc == -3
                    && (uint8_t)m.ints[0] == PROTO_ERR_REAUTH
                    && ed.err_code != PROTO_ERR_REAUTH) {
                    /* the S5 reauth-force edge rides a WORKING op:
                     * probing any same-op declared edge trips the
                     * once-per-session forced re-auth instead. The
                     * server downgraded (authed=0, counters=0):
                     * mirror, re-auth in place, and mark the probe
                     * -- its answer demonstrated the wrongness    */
                    s->authed = 0;
                    if (getenv("DBG_EVT")) fprintf(stderr, "AUTH0 site%d\n", 4);
                    s->tx_ctr = s->rx_ctr = 0;
                    if (cli_auth_stage(fd, s, rd, &flag_tok) != 0)
                        return -1;
                    /* the forced-reauth edge may land on an ERROR
                     * state (not the self-hold the usual draw uses):
                     * follow the declared next like the server did,
                     * or the routing stays one state behind forever
                     * and every later fire eats wrong-state rejects */
                    if (nxt != st) {
                        st = nxt;
                        s->state = st;
                        break;
                    }
                    continue;
                }
                if (rc == -3
                    && (uint8_t)m.ints[0] == PROTO_ERR_RESYNC
                    && ed.err_code != PROTO_ERR_RESYNC) {
                    /* an error-state server answers EVERY op with
                     * RESYNC (the class-coded recovery hint), so a
                     * probe whose declared code differs still met a
                     * DOWNGRADED server -- the organic resync of a
                     * half-registered earlier transition. Mirror and
                     * re-ladder, or every later masked frame dies as
                     * forgery (gap=-1) and the conn burns for good */
                    s->authed = 0;
                    if (getenv("DBG_EVT"))
                        fprintf(stderr, "AUTH0 resync-preempt\n");
                    s->tx_ctr = s->rx_ctr = 0;
                    if (cli_resync_recover_code(fd, s, rd, &flag_tok,
                                                PROTO_ERR_RESYNC) != 0)
                        return -1;
                    continue;
                }
                if (rc == -3
                    && (uint8_t)m.ints[0] != ed.err_code) {
                    /* the ERR code is not this edge's declared code.
                     * If the same op ALSO has a non-error edge here,
                     * the precedence picked IT (a value gate's STATE
                     * reject is legitimate) -- keep the mark. Else
                     * the server was NOT at this state: the mark
                     * would be false, so unmark and let the next
                     * pass retry (a conn kill here starved the
                     * spine probes)                            */
                    int same_ok = 0, q;
                    for (q = 0; q < WK_MAX_EDGES; q++) {
                        ps_fsm_edge_t qe;
                        if (ps_fsm_edge_at(st, q, &qe) != 0) break;
                        if (qe.cls != 3 && qe.opcode == ed.opcode)
                            same_ok = 1;
                    }
                    if (!same_ok) {
                        g_book.edge[st][k] = 0;
                        continue;
                    }
                }
                if ((ed.flags & 1) && rc == -3) {
                    st = nxt;                 /* downgrade entered   */
                    s->state = st;
                    s->authed = 0;            /* the downgrade drops it */
                    s->tx_ctr = s->rx_ctr = 0; /* and resets the C-layer
                                                 * record counters    */
                    break;   /* the remaining k indices belong to the
                               * DEPARTED state: firing them there
                               * marks probes the server answered from
                               * a whole other state            */
                }
                continue;
            }
            if (ed.cls == 2) {
                /* VALUE edge: fail-probe first (ERR + stay -- RAW, no
                 * recovery), then satisfy the gate and advance. A gate
                 * whose sem does not resolve in the schema is
                 * unconditionally true: there is nothing to violate */
                proto_msg_t m;
                const proto_schema_t *vsc = ps_schema_for(ed.opcode);
                int probeable = (ed.cond_sem != 0 && vsc != NULL
                                 && ps_sem_slot(vsc, ed.cond_sem, 0)
                                    >= 0);
                if (probeable) {
                    cli_build_edge(s, ed.opcode, &ed, 1, &m, flag_tok);
                    s->chan = s->chan_active;
                    (void)cli_txn(fd, s, rd, &m, ack_of(ed.opcode),
                                  &m, 0);
                }
                rc = cli_fire_edge(fd, s, rd, &ed, 0, &flag_tok);
                if (rc == -1) {
                    g_book.edge[st][k] = 0;
                    return -1;
                }
                if (rc == -2) {
                    g_book.edge[st][k] = 0;
                    continue;       /* interrupted: retry the edge
                                     * later (see the k-scan guard)  */
                }
                if (rc == -3) continue;       /* gate refused: hold  */
                st = nxt;
                s->state = st;   /* keep the L-dance/channel filters
                                  * reading the TRUE current state */
                break;      /* state ADVANCED: restart the k-scan at
                             * k=0 for the new state (continuing the
                             * k-loop would probe the new state with
                             * stale indices and skip its k=0 edge) */
            }
            /* accept / self */
            if (ed.opcode == OP_BYE) {
                proto_msg_t r;
                cli_build_edge(s, ed.opcode, &ed, 0, &r, flag_tok);
                rc = cli_txn(fd, s, rd, &r, OP_BYE_ACK, &r, 0);
                if (rc == 0 && PROTO_S_LEVEL >= 7) {
                    const proto_schema_t *bs = ps_schema_for(OP_BYE_ACK);
                    int t = ps_sem_slot(bs, PSEM_TOKEN, 0);
                    if (t >= 0) {
                        uint8_t nz = 0, j;
                        for (j = 0; j < 16; j++)
                            if (r.blobs[t][j]) nz = 1;
                        if (nz) {
                            memcpy(s->resume_token, r.blobs[t], 16);
                            px_resume_material(s, s->resume_secret,
                                               s->resume_token);
                            s->has_resume = 1;
                            if (tok_out)
                                memcpy(tok_out, s->resume_token, 16);
                            if (sec_out)
                                memcpy(sec_out, s->resume_secret, 32);
                        }
                    }
                }
                if (rc != 0)
                    g_book.edge[st][k] = 0;  /* failed close: retry
                                              * on a later connection */
                return rc == -1 ? -1 : 0;    /* conn over either way */
            }
            if (ed.opcode == OP_FLAG) {
                proto_msg_t r;
                int frc;
                cli_build_edge(s, ed.opcode, &ed, 0, &r, flag_tok);
                frc = cli_cmd(s, fd, rd, &r, OP_FLAG_RES, &r,
                              &flag_tok);
                if (frc == 0 && flag_out && r.strs[0][0]) {
                    snprintf(flag_out, flag_cap, "%s", r.strs[0]);
                    *did_flag = 1;
                }
                if (frc == -1) return -1;
                st = nxt;
                s->state = st;
                if (g_lite_walk && *did_flag)
                    return 0;   /* survival contract met: stop here */
                break;      /* advanced (FLAGPORT): fresh k-scan */
            }
            rc = cli_fire_edge(fd, s, rd, &ed, 0, &flag_tok);
            if (rc == -1) {
                g_book.edge[st][k] = 0;
                return -1;
            }
            if (rc == -3 && ed.cls != 3)
                g_book.edge[st][k] = 0;  /* a SUCCESS edge answered by
                                          * an ERR is NOT covered (the
                                          * false marks filled the book
                                          * and starved the sweep)   */
            if (rc == -2) {
                /* interrupted (a control frame absorbed, or the reply
                 * never parsed): the edge did not complete. Unmark,
                 * then DROP THE CONNECTION -- if the reply was lost,
                 * every later record on this conn is suspect (the
                 * peer's counter does not match ours); a fresh conn
                 * re-enters with clean counters and the book intact */
                g_book.edge[st][k] = 0;
                return -1;
            }
            if (rc == -3 && ps_fsm_find_kind(3) >= 0
                && (g_last_err == PROTO_ERR_RESYNC
                    || g_last_err == PROTO_ERR_REAUTH
                    || g_last_err == PROTO_ERR_AUTH
                    || g_last_err == PROTO_ERR_TOKEN
                    || g_last_err == PROTO_ERR_UNKNOWN)) {
                /* a DOWNGRADE-class ERR can leave the server in an
                 * error state: mirror mode0 AND re-ladder now, or
                 * every later fire eats error-state rejects. An
                 * organic STATE/CREDIT reject holds the state: the
                 * nuclear ladder here fails against the healthy
                 * server, resets the routing anyway, and the walk
                 * re-fires the same edges forever (the churn)    */
                if (cli_resync_recover(fd, s, rd, &flag_tok) == 0) {
                    int m0 = ps_fsm_find_kind(3);
                    st = m0 >= 0 ? m0 : ps_fsm_entry();
                    s->state = st;
                } else {
                    st = ps_fsm_find_kind(3);
                    s->state = st;
                }
                if (ed.cls != 3)
                    g_book.att[st < 0 ? 0 : st][k]++;  /* budget the
                             * downgrade cycle too: a per-conn carrier
                             * is exempt, but a REFUSED edge that keeps
                             * meeting downgrade answers must retire or
                             * the walk re-targets it forever (the
                             * 9000-fire stall on the heavy graphs) */
                break;
            }
            if (rc == -3) {
                /* an ERR answer: three organic refusals retire the
                 * edge (the DOWNGRADE classes broke out above and are
                 * exempt -- they are once per connection); error-state
                 * recovery edges stay unmarked so the error sweep and
                 * the close deferral can still see them open     */
                if (ed.cls != 3)
                    g_book.att[st][k]++;
                continue;
            }
            if (ed.opcode == OP_SET || ed.opcode == OP_GET
                || ed.opcode == OP_SUM)
                g_book.rounds++;
            if (nxt != st) {
                st = nxt;
                s->state = st;   /* mirror (see the value branch) */
                break;      /* advanced: fresh k-scan at the new state */
            }
            /* self edge: stay in the k-scan */
        }
        if (!fired) {
            /* state exhausted: try the timeout edge once by idling
             * past the deadline, then walk the recovery; else done  */
            uint32_t tmo = ps_fsm_timeout_ms(st);
            int te = ps_fsm_timeout_edge(st);
            if (tmo && te >= 0 && !g_book.tmo[st] && !g_lite_walk
                && !cli_unwalked_open()) {
                /* the deliberate deadline sleeps come LAST: they idle
                 * past every negotiation deadline at once and would
                 * delay the first flag past a bounded caller's window
                 * (the build's interop smoke) if they fired mid-walk */
                g_book.tmo[st] = 1;
                {
                    struct timespec ts = { (time_t)(tmo / 1000 + 1), 0 };
                    nanosleep(&ts, NULL);     /* deadline passes      */
                    st = te;                  /* mirror the timeout   */
                    s->state = st;
                    continue;
                }
            }
            {
                int sw = g_lite_walk ? 0
                    : cli_sweep_errors(fd, s, rd, &st, &flag_tok);
                if (sw < 0) return -1;
                if (sw > 0) continue;    /* now inside an error state */
                {
                    int tgt;
                    if (g_lite_walk) {
                        int ss, kk, ns = ps_fsm_n_states();
                        tgt = -1;
                        for (ss = 0; ss < ns && tgt < 0; ss++)
                            for (kk = 0; kk < WK_MAX_EDGES; kk++) {
                                ps_fsm_edge_t ee;
                                if (ps_fsm_edge_at(ss, kk, &ee) != 0)
                                    break;
                                if (ee.cls == 1 && ee.opcode == OP_FLAG
                                    && !*did_flag) {
                                    tgt = ss;
                                    break;
                                }
                            }
                        if (tgt < 0) tgt = cli_nearest_unwalked(st);
                    } else {
                        tgt = cli_nearest_unwalked(st);
                    }
                    if (tgt < 0) {
                        if (getenv("DBG_EVT"))
                            fprintf(stderr, "WALK-EXIT done\n");
                        cli_close_on_exit(fd, s, rd, st, &flag_tok);
                        return 0;
                    }
                    if (tgt == st) {
                        /* unwalked edges AT the current state (their
                         * fires timed out): a fresh k-scan retries --
                         * exiting here read "nothing left" while the
                         * book still had open items            */
                        guard--;          /* do not burn the budget  */
                        continue;
                    }
                    if (cli_traverse_to(fd, s, rd, st, tgt, &flag_tok))
                        return -1;
                    st = tgt;
                    s->state = st;
                    continue;
                }
            }
        }
        if (ps_fsm_is_kind(st, 5)) {
            /* inside an error state: fire its recovery edge now     */
            int k2;
            for (k2 = 0; k2 < WK_MAX_EDGES; k2++) {
                ps_fsm_edge_t e2;
                int rc2;
                if (ps_fsm_edge_at(st, k2, &e2) != 0) break;
                if (e2.cls == 3) continue;
                g_book.edge[st][k2] = 1;
                if (cli_fire_edge(fd, s, rd, &e2, 0, &flag_tok) == -1)
                    return -1;
                st = e2.next == 0xFF ? st : e2.next;
                break;
            }
        }
    }
}

/* one connection's walk (the multi-connection plan lives in
 * proto_client_session, which owns the host/port dialer) */
static int cli_session_inner(int fd, int rounds, char *flag_out,
                             size_t flag_cap,
                             uint8_t tok_out[16], uint8_t sec_out[32]) {
    proto_session_t s;
    proto_reader_t rd;
    int did_flag = 0;
    (void)rounds;
    px_session_init(&s, 0);
    memset(&rd, 0, sizeof rd);
    s.is_udp = (PROTO_T_LEVEL == 1);
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    s.mux_opened = (PROTO_L_LEVEL < 2);
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30;
    if (cli_walk_conn(fd, &s, &rd, flag_out, flag_cap, tok_out,
                      sec_out, &did_flag) < 0 && !did_flag)
        return 0;
    return did_flag ? 1 : 0;
}

/* S7: one abbreviated (resumed) session -- token rides HELLO, PARAMS
 * is skipped, AUTH rides the resumption secret (PSK; C in {3,7,8}
 * still performs a fresh ECDH on top, TLS-1.3 PSK+DHE shape).     */
static int cli_resume_session(int fd, char *flag_out, size_t flag_cap,
                              const uint8_t token[16],
                              const uint8_t secret[32]) {
    proto_session_t s;
    proto_reader_t rd;
    proto_msg_t m, r;
    uint32_t flag_tok = 0;

    px_session_init(&s, 0);
    memset(&rd, 0, sizeof rd);
    s.is_udp = (PROTO_T_LEVEL == 1);
    memcpy(s.resume_token, token, 16);
    memcpy(s.resume_secret, secret, 32);
    s.has_resume = 1;
    s.state = ps_fsm_entry();
    s.chan = s.chan_active =
        (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
    s.mux_opened = (PROTO_L_LEVEL < 2);
    if (PROTO_L_LEVEL < 3) s.credit = 1 << 30;

    if (cli_handshake(fd, &s, &rd, &flag_tok, 1)) return -1;
    /* the flag token at S3 came from the FIRST session's PARAMS_ACK;
     * a resumed session skips PARAMS, so derive it locally (the GT
     * contract: the label HMAC over the fresh nonce)               */
    cli_heartbeat(&s, fd);
    if (PROTO_S_LEVEL >= 6) {
        memset(&m, 0, sizeof m);
        m.opcode = OP_TXN_BEGIN;
        m.ints[0] = 0xFE;
        if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
    }
    {
        char lb[12];
        int rc;
        memset(&m, 0, sizeof m);
        m.opcode = OP_FLAG;
        px_strdec(lb, LIT_FLAGTOK, sizeof LIT_FLAGTOK);
        m.ints[0] = flag_tok ? flag_tok : px_flag_token(&s, lb);
        /* full recovery ladder (an ERR answer re-establishes position
         * via a plain re-ladder -- the resume token is spent)      */
        rc = cli_cmd(&s, fd, &rd, &m, OP_FLAG_RES, &r, &flag_tok);
        if (rc != 0)
            return -1;
        snprintf(flag_out, flag_cap, "%s", r.strs[0]);
    }
    if (PROTO_S_LEVEL >= 6) {
        memset(&m, 0, sizeof m);
        m.opcode = OP_TXN_COMMIT;
        m.ints[0] = 0;
        if (cli_txn(fd, &s, &rd, &m, OP_OK, &r, 1) != 0) return -1;
    }
    memset(&m, 0, sizeof m);
    m.opcode = OP_BYE;
    m.ints[0] = 0;
    (void)cli_txn(fd, &s, &rd, &m, OP_BYE_ACK, &r, 0);
    return 0;
}

/* T seam: the session's transport dialer -- T3 binds the seeded unix
 * path, T4 rides TCP but completes the RFC 6455 upgrade first; the
 * T0/T1 dials stay the plain inet ones                            */
static int cli_connect(const char *host, int port) {
    if (PROTO_T_LEVEL == 3) return pc_unix_connect(PROTO_UNIX_PATH);
    if (PROTO_T_LEVEL == 4) return pc_ws_connect(host, port);
    return PROTO_T_LEVEL == 1 ? pc_udp_connect(host, port)
                              : pc_full_tcp_connect(host, port);
}

/* the timeout-edge pass: the deliberate deadline sleeps are the
 * deterministic cover for every timed state's idle-timeout item.
 * PROTO_TMO_PASS=1 (the verifier's deep clean runs set it) runs
 * it BEFORE the main loop, where a heavy graph's walk would
 * otherwise consume the whole wall clock; short fault runs leave
 * it unset and get the old pass-last behavior instead        */
static void cli_timeout_pass(const char *host, int port) {
        /* the timeout-edge pass runs FIRST: the main loop on a heavy
         * graph can consume the whole wall clock, and the deliberate
         * deadline sleeps (one per timed state) are cheap, bounded and
         * cover items nothing else reaches organically.
         * One conn per timed state: ladder there, sleep past the state's
         * deadline, then a cheap inbound makes the server fire the edge;
         * the walk continues into the timeout target, which also covers
         * the E_RETRY recovery edge and its point            */
        int conn;
    for (conn = 0; conn < 64 && !g_lite_walk; conn++) {
            int ts, tk, n = ps_fsm_n_states();
            int target = -1;
            for (ts = 0; ts < n && ts < WK_MAX_STATES; ts++) {
                if (!g_book.tmo[ts] && !g_tmo_tried[ts]
                    && ps_fsm_timeout_ms(ts)
                    && ps_fsm_timeout_edge(ts) >= 0) {
                    target = ts;
                    break;
                }
            }
            if (target < 0) break;
            {
                int fd2 = cli_connect(host, port);
                proto_session_t s2;
                proto_reader_t rd2;
                uint32_t ft2 = 0;
                uint8_t tk2[16]; uint8_t sk2[32];
                uint32_t tmo = ps_fsm_timeout_ms(target);
                int st2 = ps_fsm_find_kind(3), rcc;
                g_tmo_tried[target] = 1;   /* one attempt per state per
                                             * session: a failing ladder
                                             * must not starve the later
                                             * states' timeout edges   */
                if (fd2 < 0) break;
                if (st2 < 0) st2 = ps_fsm_entry();
                px_session_init(&s2, 0);
                memset(&rd2, 0, sizeof rd2);
                s2.is_udp = (PROTO_T_LEVEL == 1);
                s2.chan = s2.chan_active =
                    (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
                s2.mux_opened = (PROTO_L_LEVEL < 2);
                if (PROTO_L_LEVEL < 3) s2.credit = 1 << 30;
                /* a DIRECTED ladder: the path entry->target (the NEG
                 * states sit ON the ladder path, so a mode0 handshake
                 * plus a traverse cannot reach them -- the BFS never
                 * walks backward)                                   */
                {
                    int path[64];
                    int plen = cli_path_to(ps_fsm_entry(), target,
                                           path, 64);
                    int pi, pst = ps_fsm_entry();
                    s2.state = pst;
                    rcc = 0;
                    for (pi = 0; pi < plen && rcc == 0; pi++) {
                        int kk, done = 0;
                        for (kk = 0; kk < WK_MAX_EDGES && !done; kk++) {
                            ps_fsm_edge_t he;
                            int hd;
                            if (ps_fsm_edge_at(pst, kk, &he) != 0) break;
                            if ((he.next == 0xFF ? pst : he.next)
                                != path[pi] || he.cls == 3)
                                continue;
                            for (hd = 0; hd < 3; hd++) {
                                rcc = cli_fire_edge(fd2, &s2, &rd2, &he,
                                                    0, &ft2);
                                if (rcc != -2) break;
                            }
                            done = 1;
                        }
                        if (!done) { rcc = -1; break; }
                        pst = path[pi];
                        s2.state = pst;
                    }
                }
                if (rcc == 0) {
                    struct timespec tsp = { (time_t)(tmo / 1000 + 1), 0 };
                    proto_msg_t p;
                    nanosleep(&tsp, NULL);     /* the deadline passes    */
                    g_book.tmo[target] = 1;
                    memset(&p, 0, sizeof p);   /* any inbound trips the
                                                 * server's gap check   */
                    p.opcode = OP_PING;
                    s2.chan = s2.chan_active;
                    (void)send_msg(&s2, fd2, &p);
                    /* fire the timeout target's non-error edges (an
                     * error state's recovery edge lives there; the
                     * walker proper would restart from the entry)   */
                    {
                        int q;
                        s2.state = ps_fsm_timeout_edge(target);
                        for (q = 0; q < WK_MAX_EDGES; q++) {
                            ps_fsm_edge_t qe;
                            if (ps_fsm_edge_at(s2.state, q, &qe) != 0)
                                break;
                            if (qe.cls == 3) continue;
                            if (cli_fire_edge(fd2, &s2, &rd2, &qe, 0,
                                              &ft2) == -1)
                                break;
                            s2.state = qe.next == 0xFF
                                ? s2.state : qe.next;
                            break;
                        }
                    }
                }
                close(fd2);
            }
        }
}

int proto_client_session(const char *host, int port,
                         char *flag_out, size_t flag_cap) {
    uint8_t tok[16], sec[32];
    int conn, got_flag = 0;
    memset(tok, 0, sizeof tok);
    memset(&g_book, 0, sizeof g_book);
    if (g_lite_walk) {
        for (conn = 0; conn < 14 && !got_flag; conn++) {
            int fd = cli_connect(host, port);
            if (fd < 0) break;
            if (cli_lite_conn(fd, flag_out, flag_cap) == 0)
                got_flag = 1;
            close(fd);
        }
        return got_flag ? 0 : -1;
    }
    /* the conn budget dominates the deep-walk plan: short-lived conns
     * (deliberate timeout sleeps end them by design) still each cover
     * a slice of the graph, so the cap must be generous -- the WALL
     * clock is the real bound                              */
    if (!g_lite_walk && getenv("PROTO_TMO_PASS"))
        cli_timeout_pass(host, port);
    for (conn = 0; conn < 400 && !cli_book_complete(); conn++) {
        int fd = cli_connect(host, port);
        int rc;
        if (fd < 0) break;
        rc = cli_session_inner(fd, 0, flag_out, flag_cap, tok, sec);
        close(fd);
        if (rc == 1) got_flag = 1;
    }
    if (!g_lite_walk && !getenv("PROTO_TMO_PASS"))
        cli_timeout_pass(host, port);
    /* the close pass: every state's close edge is a conn's natural
     * LAST act, but the walker advances past mid-spine modes before
     * their closes can fire (the advancing edge has the lower k).
     * One directed conn per unmarked close                       */
    for (conn = 0; conn < 64 && !g_lite_walk; conn++) {
        int cs, target = -1;
        int n2 = ps_fsm_n_states();
        for (cs = 0; cs < n2 && cs < WK_MAX_STATES; cs++) {
            int q;
            if (g_close_tried[cs]) continue;
            for (q = 0; q < WK_MAX_EDGES; q++) {
                ps_fsm_edge_t ce;
                if (ps_fsm_edge_at(cs, q, &ce) != 0) break;
                if (ce.opcode == OP_BYE && !g_book.edge[cs][q]) {
                    target = cs;
                    break;
                }
            }
            if (target >= 0) break;
        }
        if (target < 0) break;
        /* one attempt per close: a failing close must not starve
         * its siblings. Retries were tried and dropped: they never
         * fired in the verified cases (each close landed first try)
         * and a heavy graph's close set times the budget out -- the
         * S7 graph's plan truncated at MODE2 and lost 8.5 credits to
         * them. Own-line comment, transform-safety.                  */
        g_close_tried[target] = 1;
        {
            int fd3 = cli_connect(host, port);
            proto_session_t s3;
            proto_reader_t rd3;
            uint32_t ft3 = 0;
            int path[64];
            int plen = cli_path_to(ps_fsm_entry(), target, path, 64);
            int pi, pst = ps_fsm_entry(), rcc = 0;
            if (fd3 < 0) break;
            px_session_init(&s3, 0);
            memset(&rd3, 0, sizeof rd3);
            s3.is_udp = (PROTO_T_LEVEL == 1);
            s3.chan = s3.chan_active =
                (PROTO_L_LEVEL >= 1) ? PROTO_L_CHAN_BASE : 0;
            s3.mux_opened = (PROTO_L_LEVEL < 2);
            if (PROTO_L_LEVEL < 3) s3.credit = 1 << 30;
            s3.state = pst;
            for (pi = 0; pi < plen && rcc == 0; pi++) {
                int kk, done = 0;
                for (kk = 0; kk < WK_MAX_EDGES && !done; kk++) {
                    ps_fsm_edge_t he;
                    if (ps_fsm_edge_at(pst, kk, &he) != 0) break;
                    if ((he.next == 0xFF ? pst : he.next) != path[pi]
                        || he.cls == 3)
                        continue;
                    rcc = cli_fire_edge(fd3, &s3, &rd3, &he, 0, &ft3);
                    done = 1;
                }
                if (!done) { rcc = -1; break; }
                pst = path[pi];
                s3.state = pst;
            }
            if (rcc == 0) {
                int q;
                for (q = 0; q < WK_MAX_EDGES; q++) {
                    ps_fsm_edge_t ce;
                    proto_msg_t cm;
                    int rc3;
                    if (ps_fsm_edge_at(target, q, &ce) != 0) break;
                    if (ce.opcode != OP_BYE || g_book.edge[target][q])
                        continue;
                    g_book.edge[target][q] = 1;
                    cli_build_edge(&s3, ce.opcode, &ce, 0, &cm, ft3);
                    s3.chan = s3.chan_active;
                    rc3 = cli_txn(fd3, &s3, &rd3, &cm, OP_BYE_ACK,
                                  &cm, 0);
                    if (rc3 != 0)
                        g_book.edge[target][q] = 0;
                    break;
                }
            }
            close(fd3);
        }
    }
    if (got_flag && PROTO_S_LEVEL >= 7) {
        uint8_t j, nz = 0;
        for (j = 0; j < 16; j++) if (tok[j]) nz = 1;
        if (nz) {
            int fd2 = cli_connect(host, port);
            if (fd2 >= 0) {
                int r2 = cli_resume_session(fd2, flag_out, flag_cap,
                                            tok, sec);
                close(fd2);
                if (r2 != 0 && !got_flag) return -1;
            }
        }
    }
    return got_flag ? 0 : -1;
}

int proto_client_converse(const char *host, int port, int rounds) {
    int rc = 0, try;
    /* every conversation starts its rotation fresh: the lite rounds
     * rotate off the GLOBAL previous-command index earlier sessions
     * in this process left behind                      */
    g_prev_cmd_k = -1;
    /* one conn on the heaviest graphs can die mid-ladder before any
     * command round fires (a -2 eats it): the counter is cumulative,
     * so a bounded retry until a round lands is the honest converse */
    for (try = 0; try < 8; try++) {
        int fd = cli_connect(host, port);
        if (fd < 0) return -1;
        rc = cli_session_inner(fd, rounds, NULL, 0, NULL, NULL);
        close(fd);
        if (g_book.rounds > 0) break;
    }
    if (rc > 0) return (int)rounds;      /* flag reached: rounds done */
    return g_book.rounds > 0 ? (int)rounds : rc;
}
