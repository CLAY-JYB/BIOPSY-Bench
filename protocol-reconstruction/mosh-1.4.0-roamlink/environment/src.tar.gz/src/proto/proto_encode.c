/* proto_encode.c -- encoding axis (E): schema-driven payload codec.
 *
 * Static asset, level-switched via proto_config.h:
 *   E0  ASCII tokens ("NAME arg arg ...")        [requires F1]
 *   E1  fixed-width ints (seed-chosen endianness), NUL-padded strings
 *   E2  per-field endianness + 4-byte alignment padding
 *   E3  flags byte + LEB128 varints + length-prefixed strings
 *   E4  TLV records (tag varint, len varint, value)
 *   E5  bit-packed LSB-first stream (sub-byte fields)
 *
 * The same walker produces the wire form and the per-field span table
 * (byte offsets, or bit offsets at E5) so the ground-truth examples in
 * meta.json can never drift from the actual codec.
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* ------------------------------------------------------------------ */
/* writer / reader cursors                                             */
/* ------------------------------------------------------------------ */
typedef struct {
    uint8_t *buf;
    size_t   cap, pos;
    int      bitbuf, bitcnt;          /* E5 bit accumulator           */
    int      spans[PROTO_MAX_FIELDS][2]; /* [start, len) per field;
                                          * E5: bit span, else bytes   */
    int      span_i;
    int      failed;
} pe_w;

typedef struct {
    const uint8_t *buf;
    size_t   n, pos;
    int      bitbuf, bitcnt;
    int      failed;
} pe_r;

static void w_fail(pe_w *w) { w->failed = 1; }

static void w_u8(pe_w *w, uint8_t v) {
    if (w->pos + 1 > w->cap) return w_fail(w);
    w->buf[w->pos++] = v;
}

static void w_mem(pe_w *w, const void *p, size_t n) {
    if (w->pos + n > w->cap) return w_fail(w);
    memcpy(w->buf + w->pos, p, n);
    w->pos += n;
}

static void w_align(pe_w *w, int a) {
    while (w->pos % a) w_u8(w, 0);
}

static void w_uint(pe_w *w, uint64_t v, int nbytes, int little) {
    uint8_t tmp[8];
    int i;
    for (i = 0; i < nbytes; i++)
        tmp[i] = little ? (uint8_t)(v >> (8 * i))
                        : (uint8_t)(v >> (8 * (nbytes - 1 - i)));
    w_mem(w, tmp, nbytes);
}

static void w_varint(pe_w *w, uint64_t v) {
    uint8_t tmp[10];
    int n = 0;
    do {
        uint8_t b;
        if (PROTO_E3_VARINT_MSB) {         /* LEB128: bit7 continues  */
            b = (uint8_t)(v & 0x7F);
            v >>= 7;
            if (v) b |= 0x80;
        } else {                           /* variant: bit0 continues */
            b = (uint8_t)((v & 0x7F) << 1);
            v >>= 7;
            if (v) b |= 0x01;
        }
        tmp[n++] = b;
    } while (v && n < 10);
    w_mem(w, tmp, n);
}

/* bit writer (E5): bit order is the seeded knob (LSB- or MSB-first) */
static void w_bits(pe_w *w, uint32_t v, int nbits) {
    int i;
    for (i = 0; i < nbits; i++) {
        if (PROTO_E5_BITORDER_MSB)
            w->bitbuf |= ((v >> i) & 1) << (7 - w->bitcnt);
        else
            w->bitbuf |= ((v >> i) & 1) << w->bitcnt;
        w->bitcnt++;
        if (w->bitcnt == 8) {
            w_u8(w, (uint8_t)w->bitbuf);
            w->bitbuf = 0; w->bitcnt = 0;
        }
    }
}

static void w_bits_flush(pe_w *w) {
    if (w->bitcnt) {
        w_u8(w, (uint8_t)w->bitbuf);
        w->bitbuf = 0; w->bitcnt = 0;
    }
}

static int  r_u8(pe_r *r, uint8_t *v) {
    if (r->pos + 1 > r->n) return r->failed = 1, -1;
    *v = r->buf[r->pos++];
    return 0;
}

static int r_mem(pe_r *r, void *p, size_t n) {
    if (r->pos + n > r->n) return r->failed = 1, -1;
    memcpy(p, r->buf + r->pos, n);
    r->pos += n;
    return 0;
}

static int r_uint(pe_r *r, uint64_t *v, int nbytes, int little) {
    uint8_t tmp[8];
    int i;
    if (r_mem(r, tmp, nbytes)) return -1;
    *v = 0;
    for (i = 0; i < nbytes; i++)
        *v |= little ? ((uint64_t)tmp[i] << (8 * i))
                     : ((uint64_t)tmp[i] << (8 * (nbytes - 1 - i)));
    return 0;
}

static int r_varint(pe_r *r, uint64_t *v) {
    uint64_t acc = 0;
    int shift = 0;
    for (;;) {
        uint8_t b;
        if (r_u8(r, &b)) return -1;
        if (PROTO_E3_VARINT_MSB) {
            acc |= (uint64_t)(b & 0x7F) << shift;
            if (!(b & 0x80)) break;
        } else {
            acc |= (uint64_t)(b >> 1) << shift;
            if (!(b & 0x01)) break;
        }
        shift += 7;
        if (shift > 63) return r->failed = 1, -1;
    }
    *v = acc;
    return 0;
}

static int r_bits(pe_r *r, uint32_t *v, int nbits) {
    uint32_t acc = 0;
    int i;
    for (i = 0; i < nbits; i++) {
        if (r->bitcnt == 0) {
            uint8_t b;
            if (r_u8(r, &b)) return -1;
            r->bitbuf = b; r->bitcnt = 8;
        }
        if (PROTO_E5_BITORDER_MSB) {
            acc |= (uint32_t)((r->bitbuf & 0x80) ? (1u << i) : 0);
            r->bitbuf = (uint8_t)(r->bitbuf << 1);
        } else {
            acc |= (uint32_t)((r->bitbuf & 1) ? (1u << i) : 0);
            r->bitbuf >>= 1;
        }
        r->bitcnt--;
    }
    *v = acc;
    return 0;
}

/* ------------------------------------------------------------------ */
/* int width by ftype                                                  */
/* ------------------------------------------------------------------ */
static int ft_nbytes(int ftype) {
    switch (ftype) {
    case PFT_U8: return 1;
    case PFT_U16: return 2;
    case PFT_U32: return 4;
    case PFT_U64: return 8;
    default: return 0;
    }
}

/* ------------------------------------------------------------------ */
/* encode one message payload per E level                              */
/* ------------------------------------------------------------------ */
int pe_encode(const proto_schema_t *sch, const proto_msg_t *m,
              uint8_t *out, size_t cap, int spans[PROTO_MAX_FIELDS][2]) {
    pe_w w;
    int i;
    memset(&w, 0, sizeof w);
    w.buf = out; w.cap = cap;

    if (PROTO_E_LEVEL >= 1) {
        /* opcode lead byte rides the payload (header-less F levels
         * rely on it; F3+ carry it in the header too and the reader
         * cross-checks). Not a schema field -- takes no span slot.   */
        w_u8(&w, (uint8_t)sch->opcode);
        if (w.failed) return -1;
    }

    if (PROTO_E_LEVEL == 0) {
        /* ASCII tokens: NAME arg1 arg2 */
        char tok[PROTO_STR_MAX + 16];
        int n = snprintf(tok, sizeof tok, "%s", sch->name);
        if (n < 0) return -1;
        w_mem(&w, tok, strlen(tok));
        for (i = 0; i < sch->nfields; i++) {
            const proto_field_t *f = &sch->fields[i];
            size_t fstart = w.pos;
            if (f->ftype == PFT_STR) {
                w_u8(&w, ' ');
                w_mem(&w, m->strs[i], strlen(m->strs[i]));
            } else if (f->ftype == PFT_BSTR) {
                int k;                     /* binary blob as hex token */
                w_u8(&w, ' ');
                for (k = 0; k < f->width; k++) {
                    int n2 = snprintf(tok, sizeof tok, "%02x",
                                      m->blobs[i][k]);
                    if (n2 < 0) return -1;
                    w_mem(&w, tok, strlen(tok));
                }
            } else {
                n = snprintf(tok, sizeof tok, " %llu",
                             (unsigned long long)m->ints[i]);
                if (n < 0) return -1;
                w_mem(&w, tok, strlen(tok));
            }
            if (w.failed) return -1;
            /* span excludes the separating space */
            w.spans[w.span_i][0] = (int)fstart + 1;
            w.spans[w.span_i][1] = (int)(w.pos - fstart - 1);
            w.span_i++;
        }
        if (spans) memcpy(spans, w.spans, sizeof w.spans);
        return w.failed ? -1 : (int)w.pos;
    }

    for (i = 0; i < sch->nfields; i++) {
        const proto_field_t *f = &sch->fields[i];
        size_t start = w.pos;
        int bstart = (int)(w.pos * 8 + w.bitcnt);

        if (PROTO_E_LEVEL == 1) {
            if (f->ftype == PFT_BSTR) {
                w_mem(&w, m->blobs[i], f->width);
            } else if (f->ftype == PFT_STR) {
                char pad[PROTO_STR_MAX];
                size_t sl = strlen(m->strs[i]);
                if (sl > (size_t)f->width) sl = f->width;
                memset(pad, PROTO_E1_PAD, sizeof pad);   /* seeded pad */
                memcpy(pad, m->strs[i], sl);
                w_mem(&w, pad, f->width);
            } else {
                w_uint(&w, m->ints[i], ft_nbytes(f->ftype),
                       PROTO_E1_ENDIAN);   /* independent of the header */
            }
        } else if (PROTO_E_LEVEL == 2) {
            if (f->ftype == PFT_BSTR) {
                w_mem(&w, m->blobs[i], f->width);
            } else if (f->ftype == PFT_STR) {
                char pad[PROTO_STR_MAX] = {0};
                size_t sl = strlen(m->strs[i]);
                if (sl > (size_t)f->width) sl = f->width;
                memcpy(pad, m->strs[i], sl);
                w_mem(&w, pad, f->width);
            } else {
                if (ft_nbytes(f->ftype) >= 4) w_align(&w, 4);
                w_uint(&w, m->ints[i], ft_nbytes(f->ftype), f->endian);
            }
        } else if (PROTO_E_LEVEL == 3) {
            if (i == 0) w_u8(&w, PROTO_E3_FLAGS); /* presence byte */
            if (f->ftype == PFT_BSTR) {
                w_varint(&w, (uint64_t)f->width);
                w_mem(&w, m->blobs[i], f->width);
            } else if (f->ftype == PFT_STR) {
                size_t sl = strlen(m->strs[i]);
                w_varint(&w, sl);
                w_mem(&w, m->strs[i], sl);
            } else {
                w_varint(&w, m->ints[i]);
            }
        } else if (PROTO_E_LEVEL == 4) {
            int tag = f->bits ? f->bits : (2 * i + 1);
            /* tag width is a knob: 0 = varint (classic), 1/2 = fixed */
            #define W_TAG() do { \
                if (PROTO_E4_TAG_W) w_uint(&w, (uint64_t)tag, \
                                           PROTO_E4_TAG_W, \
                                           PROTO_ENDIAN_LITTLE); \
                else w_varint(&w, (uint64_t)tag); \
            } while (0)
            if (f->ftype == PFT_BSTR) {
                W_TAG();
                w_varint(&w, (uint64_t)f->width);
                w_mem(&w, m->blobs[i], f->width);
            } else if (f->ftype == PFT_STR) {
                size_t sl = strlen(m->strs[i]);
                W_TAG();
                w_varint(&w, sl);
                w_mem(&w, m->strs[i], sl);
            } else {
                uint8_t tmp[10];
                pe_w sub;
                memset(&sub, 0, sizeof sub);
                sub.buf = tmp; sub.cap = sizeof tmp;
                w_varint(&sub, m->ints[i]);
                W_TAG();
                w_varint(&w, sub.pos);
                w_mem(&w, tmp, sub.pos);
            }
            #undef W_TAG
        } else if (PROTO_E_LEVEL == 6) {
            /* E6: hex-ascii escaping -- binary blobs ride as 2x-width
             * hex text (legacy-safe transports); strings as-is with a
             * 0x00 terminator; ints fixed-width native            */
            if (f->ftype == PFT_BSTR) {
                char hex[2 * PROTO_STR_MAX + 1];
                int k;
                for (k = 0; k < f->width; k++)
                    snprintf(hex + 2 * k, 3, "%02x",
                             m->blobs[i][k]);
                w_mem(&w, hex, (size_t)f->width * 2);
            } else if (f->ftype == PFT_STR) {
                size_t sl = strlen(m->strs[i]);
                if (sl > (size_t)f->width) sl = (size_t)f->width;
                w_mem(&w, m->strs[i], sl);
                w_u8(&w, 0x00);          /* NUL-terminated          */
            } else {
                w_uint(&w, m->ints[i], ft_nbytes(f->ftype),
                       PROTO_E1_ENDIAN);
            }
        } else { /* E5: bit-packed */
            if (f->ftype == PFT_BITS) {
                w_bits(&w, (uint32_t)m->ints[i], f->bits);
            } else if (f->ftype == PFT_BSTR) {
                int k;
                for (k = 0; k < f->width; k++)
                    w_bits(&w, m->blobs[i][k], 8);
            } else if (f->ftype == PFT_STR) {
                size_t sl = strlen(m->strs[i]);
                size_t k;
                w_bits(&w, (uint32_t)sl, PROTO_E5_STRBITS);
                for (k = 0; k < sl; k++)
                    w_bits(&w, (uint8_t)m->strs[i][k], 8);
            } else {
                int nbits = f->bits ? f->bits : ft_nbytes(f->ftype) * 8;
                uint64_t v = m->ints[i];
                uint64_t mask = nbits >= 64
                    ? ~0ULL : ((1ULL << nbits) - 1);
                w_bits(&w, (uint32_t)(v & mask), nbits > 32 ? 32 : nbits);
                if (nbits > 32)
                    w_bits(&w, (uint32_t)((v >> 32) & mask), nbits - 32);
            }
        }

        if (!w.failed && w.span_i < PROTO_MAX_FIELDS) {
            if (PROTO_E_LEVEL == 5) {
                int bend = (int)(w.pos * 8 + w.bitcnt);
                w.spans[w.span_i][0] = bstart;
                w.spans[w.span_i][1] = bend - bstart;
            } else {
                w.spans[w.span_i][0] = (int)start;
                w.spans[w.span_i][1] = (int)(w.pos - start);
            }
            w.span_i++;
        }
        if (w.failed) return -1;
    }
    if (PROTO_E_LEVEL == 5) w_bits_flush(&w);
    if (spans && !w.failed)
        memcpy(spans, w.spans, sizeof w.spans);
    return w.failed ? -1 : (int)w.pos;
}

/* ------------------------------------------------------------------ */
/* decode one message payload per E level                              */
/* ------------------------------------------------------------------ */
int pe_decode(const proto_schema_t *sch, const uint8_t *in, size_t n,
              proto_msg_t *m) {
    pe_r r;
    int i;
    memset(&r, 0, sizeof r);
    r.buf = in; r.n = n;
    memset(m->strs, 0, sizeof m->strs);
    memset(m->blobs, 0, sizeof m->blobs);

    if (PROTO_E_LEVEL == 0) {
        /* payload "NAME a1 a2" -- split on spaces. The record pad byte
         * is a delimiter too (same convention as E1's pad trim): at F0
         * the record padding trails the last token, and a seeded pad of
         * 0xFF/0xA5 would otherwise glue itself onto the final field */
        char tmp[PROTO_FRAME_MAX];
        char delims[3] = {' ', (char)PROTO_F0_PAD, 0};
        char *tok, *save = NULL;
        size_t cp = n < sizeof tmp - 1 ? n : sizeof tmp - 1;
        memcpy(tmp, in, cp);
        tmp[cp] = 0;
        tok = strtok_r(tmp, delims, &save);
        if (!tok) return -1;
        if (strcmp(tok, sch->name)) return -1;   /* lead name token   */
        for (i = 0; i < sch->nfields; i++) {
            const proto_field_t *f = &sch->fields[i];
            tok = strtok_r(NULL, delims, &save);
            if (!tok) return -1;
            if (f->ftype == PFT_STR) {
                snprintf(m->strs[i], PROTO_STR_MAX, "%s", tok);
            } else if (f->ftype == PFT_BSTR) {
                int k;                       /* hex token -> raw bytes */
                if (strlen(tok) != (size_t)f->width * 2) return -1;
                for (k = 0; k < f->width; k++) {
                    unsigned v;
                    if (sscanf(tok + 2 * k, "%2x", &v) != 1) return -1;
                    m->blobs[i][k] = (uint8_t)v;
                }
            } else {
                m->ints[i] = strtoull(tok, NULL, 10);
            }
        }
        return 0;
    }

    /* E>=1: consume the opcode lead byte */
    {
        uint8_t lead;
        if (r_u8(&r, &lead)) return -1;
        if (lead != (uint8_t)sch->opcode) return -1;
    }

    for (i = 0; i < sch->nfields; i++) {
        const proto_field_t *f = &sch->fields[i];
        if (PROTO_E_LEVEL == 1) {
            if (f->ftype == PFT_BSTR) {
                if (r_mem(&r, m->blobs[i], f->width)) return -1;
            } else if (f->ftype == PFT_STR) {
                uint8_t pad[PROTO_STR_MAX];
                size_t sl;
                if (r_mem(&r, pad, f->width)) return -1;
                /* the pad byte is seeded (NUL or space): trim it from
                 * the tail, not by scanning for NUL                   */
                sl = (size_t)f->width;
                while (sl > 0 && pad[sl - 1] == PROTO_E1_PAD) sl--;
                if (sl >= PROTO_STR_MAX) sl = PROTO_STR_MAX - 1;
                memcpy(m->strs[i], pad, sl);
                m->strs[i][sl] = 0;
            } else if (r_uint(&r, &m->ints[i], ft_nbytes(f->ftype),
                              PROTO_E1_ENDIAN)) return -1;
        } else if (PROTO_E_LEVEL == 2) {
            if (f->ftype == PFT_BSTR) {
                if (r_mem(&r, m->blobs[i], f->width)) return -1;
            } else if (f->ftype == PFT_STR) {
                uint8_t pad[PROTO_STR_MAX];
                size_t sl;
                if (r_mem(&r, pad, f->width)) return -1;
                sl = strnlen((const char *)pad, f->width);
                if (sl >= PROTO_STR_MAX) sl = PROTO_STR_MAX - 1;
                memcpy(m->strs[i], pad, sl);
            } else {
                if (ft_nbytes(f->ftype) >= 4)
                    while (r.pos % 4) { uint8_t z; if (r_u8(&r, &z)) return -1; }
                if (r_uint(&r, &m->ints[i], ft_nbytes(f->ftype),
                           f->endian)) return -1;
            }
        } else if (PROTO_E_LEVEL == 3) {
            if (i == 0) { uint8_t fl; if (r_u8(&r, &fl)) return -1; }
            if (f->ftype == PFT_BSTR) {
                uint64_t sl;
                if (r_varint(&r, &sl)) return -1;
                if (sl != (uint64_t)f->width) return -1;
                if (r_mem(&r, m->blobs[i], sl)) return -1;
            } else if (f->ftype == PFT_STR) {
                uint64_t sl;
                if (r_varint(&r, &sl)) return -1;
                if (sl >= PROTO_STR_MAX) return -1;
                if (r_mem(&r, m->strs[i], sl)) return -1;
            } else if (r_varint(&r, &m->ints[i])) return -1;
        } else if (PROTO_E_LEVEL == 4) {
            uint64_t tag, len;
            int want = f->bits ? f->bits : (2 * i + 1);
            if (PROTO_E4_TAG_W) {
                if (r_uint(&r, &tag, PROTO_E4_TAG_W,
                           PROTO_ENDIAN_LITTLE)) return -1;
                if (r_varint(&r, &len)) return -1;
            } else if (r_varint(&r, &tag) || r_varint(&r, &len)) {
                return -1;
            }
            if ((int)tag != want) return -1;   /* strict order + tag check */
            if (f->ftype == PFT_BSTR) {
                if (len != (uint64_t)f->width || len > PROTO_STR_MAX)
                    return -1;
                if (r_mem(&r, m->blobs[i], len)) return -1;
            } else if (f->ftype == PFT_STR) {
                if (len >= PROTO_STR_MAX) return -1;
                if (r_mem(&r, m->strs[i], len)) return -1;
            } else {
                pe_r sub;
                uint8_t tmp[10];
                if (len > sizeof tmp) return -1;
                if (r_mem(&r, tmp, len)) return -1;
                memset(&sub, 0, sizeof sub);
                sub.buf = tmp; sub.n = len;
                if (r_varint(&sub, &m->ints[i])) return -1;
            }
        } else if (PROTO_E_LEVEL == 6) {
            if (f->ftype == PFT_BSTR) {
                char hex[2 * PROTO_STR_MAX + 1];
                int k;
                if (r_mem(&r, hex, (size_t)f->width * 2)) return -1;
                hex[f->width * 2] = 0;
                for (k = 0; k < f->width; k++) {
                    unsigned v;
                    if (sscanf(hex + 2 * k, "%2x", &v) != 1)
                        return -1;
                    m->blobs[i][k] = (uint8_t)v;
                }
            } else if (f->ftype == PFT_STR) {
                /* variable-length NUL-terminated: scan byte by byte
                 * (the encoder wrote strlen+1, NOT width+1)         */
                size_t sl = 0;
                for (;;) {
                    uint8_t c;
                    if (r_u8(&r, &c)) return -1;
                    if (c == 0x00) break;
                    if (sl >= (size_t)f->width
                        || sl + 1 >= PROTO_STR_MAX) return -1;
                    m->strs[i][sl++] = (char)c;
                }
                m->strs[i][sl] = 0;
            } else if (r_uint(&r, &m->ints[i], ft_nbytes(f->ftype),
                              PROTO_E1_ENDIAN)) return -1;
        } else { /* E5 */
            if (f->ftype == PFT_BITS) {
                uint32_t v;
                if (r_bits(&r, &v, f->bits)) return -1;
                m->ints[i] = v;
            } else if (f->ftype == PFT_BSTR) {
                uint32_t k;
                for (k = 0; k < (uint32_t)f->width; k++) {
                    uint32_t b;
                    if (r_bits(&r, &b, 8)) return -1;
                    m->blobs[i][k] = (uint8_t)b;
                }
            } else if (f->ftype == PFT_STR) {
                uint32_t sl, k;
                if (r_bits(&r, &sl, PROTO_E5_STRBITS)) return -1;
                if (sl >= PROTO_STR_MAX) return -1;
                for (k = 0; k < sl; k++) {
                    uint32_t ch;
                    if (r_bits(&r, &ch, 8)) return -1;
                    m->strs[i][k] = (char)ch;
                }
            } else {
                int nbits = f->bits ? f->bits : ft_nbytes(f->ftype) * 8;
                uint32_t lo = 0, hi = 0;
                if (r_bits(&r, &lo, nbits > 32 ? 32 : nbits)) return -1;
                if (nbits > 32 && r_bits(&r, &hi, nbits - 32)) return -1;
                m->ints[i] = nbits > 32
                    ? ((uint64_t)hi << 32) | lo : lo;
            }
        }
        if (r.failed) return -1;
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* canonical example + per-field spans (ground-truth dump)             */
/* ------------------------------------------------------------------ */
int pe_example(const proto_schema_t *sch, uint8_t *out, size_t cap,
               int spans[PROTO_MAX_FIELDS][2]) {
    proto_msg_t m;
    int i, rc;
    memset(&m, 0, sizeof m);
    m.opcode = sch->opcode;
    for (i = 0; i < sch->nfields; i++) {
        const proto_field_t *f = &sch->fields[i];
        if (f->ftype == PFT_STR || f->ftype == PFT_BSTR) {
            snprintf(m.strs[i], PROTO_STR_MAX, "ex%d", i);
            memset(m.blobs[i], (uint8_t)(0xA0 + i), f->width);
        } else {
            /* width-safe: u8 fields carry a small nonzero value
             * (0x1000 would truncate to 0x00 and misrepresent the
             * field in the GT example bytes)                           */
            m.ints[i] = (f->ftype == PFT_U8)
                ? (uint64_t)(0x40 + i) : (uint64_t)(0x1000 + i);
        }
    }
    rc = pe_encode(sch, &m, out, cap, spans);
    return rc;
}
