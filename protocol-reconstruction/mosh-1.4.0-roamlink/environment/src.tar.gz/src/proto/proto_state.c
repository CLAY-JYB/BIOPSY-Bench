/* proto_state.c -- state axis (S): schema registry + server FSM.
 *
 * Static asset, level-switched via proto_config.h:
 *   S0  stateless: every request answered in any order
 *   S1  HELLO/version gate, then a flat command session
 *   S2  + AUTH challenge-response, session id, per-message sequencing
 *   S3  + PARAMS negotiation stage, error/recovery (RESYNC -> HELLO),
 *       duplicate-sequence tolerance (retransmission)
 *
 * The transition table drives both server enforcement and the GT
 * state-machine dump in meta.json.
 *
 * SCHEMA REGISTRY ANTI-LEAK: the message table never rides as
 * readable structs in .data (field names, types, semantics, widths
 * would make a gdb/objdump dump of the challenge binary the answer
 * key). proto_config.h emits the registry XOR-masked
 * and SPLIT across two byte arrays; the accessors below decode ONE
 * schema at a time into scratch storage, so no complete readable
 * table exists anywhere in the image or in memory at rest. The
 * returned pointer is valid until the next ps_* call (no call site
 * holds two schema pointers; pe_encode/pe_decode never re-enter
 * ps_*).
 */

#include <string.h>

/* ------------------------------------------------------------------ */
/* encoded-registry reader                                             */
/* ------------------------------------------------------------------ */
/* stream layout (little records, all u8):
 *   message: opcode, dir, name_len, name[name_len], nfields
 *   field:   ftype, width, sem, endian, bits, name_len, name[name_len]
 */
static uint8_t sch_byte(size_t i) {
    /* halves are interleaved (split storage); the keystream is the
     * seeded base rolled per position. The half-array bound makes the
     * reader total: a truncated stream reads as zeros and the parser
     * above returns NULL instead of running off the tables.          */
    const uint8_t *arr = ((i & 1) != 0) ? PROTO_SCHEMA_B : PROTO_SCHEMA_A;
    size_t cap = ((i & 1) != 0) ? sizeof PROTO_SCHEMA_B
                                : sizeof PROTO_SCHEMA_A;
    uint8_t b;
    if ((i >> 1) >= cap) return 0;
    b = arr[i >> 1];
    return (uint8_t)(b ^ PROTO_SCHEMA_KS[i & 31]
                     ^ (uint8_t)((i * 41) & 0xFF));
}

/* one-schema scratch: the ONLY place a decoded schema ever exists.
 * Thread-local: the threaded oracle serves concurrent connections
 * (the C10 probe) and each thread decodes its own schemas; the
 * sequential carrier build has one thread, unchanged behavior.    */
static __thread proto_schema_t g_sch;
static __thread proto_field_t  g_fld[PROTO_MAX_FIELDS];
static __thread char           g_sch_name[32];
static __thread char           g_fld_name[PROTO_MAX_FIELDS][32];

/* parse record #idx into the scratch; NULL when out of range or the
 * stream is malformed (bounds-guarded: corrupt constants can never
 * crash the engine)                                              */
static const proto_schema_t *ps_load(int idx) {
    size_t pos = 0;
    int rec;
    uint8_t opcode, dir, name_len, nfields;
    uint8_t *u;
    char *c;
    int i;
    proto_schema_t *sch;
    if (idx < 0) return NULL;
    for (rec = 0; rec <= idx; rec++) {
        opcode   = sch_byte(pos++);
        dir      = sch_byte(pos++);
        name_len = sch_byte(pos++);
        if (name_len == 0 || name_len >= sizeof g_sch_name) return NULL;
        if (rec == idx) break;
        pos += name_len;                       /* skip this name     */
        nfields = sch_byte(pos++);
        if (nfields > PROTO_MAX_FIELDS) return NULL;
        for (i = 0; i < (int)nfields; i++) {
            uint8_t fn, fl[5];
            int k;
            for (k = 0; k < 5; k++) fl[k] = sch_byte(pos++);
            (void)fl;                          /* skip this field    */
            fn = sch_byte(pos++);
            pos += fn;
        }
    }
    if (rec != idx) return NULL;
    sch = &g_sch;
    memset(sch, 0, sizeof *sch);
    memset(g_fld, 0, sizeof g_fld);
    u = (uint8_t *)g_sch_name;
    for (i = 0; i < (int)name_len; i++) u[i] = sch_byte(pos++);
    u[name_len] = 0;
    sch->name = g_sch_name;
    sch->opcode = opcode;
    sch->dir = (dir == 1) ? PDIR_C2S : PDIR_S2C;
    nfields = sch_byte(pos++);
    if (nfields > PROTO_MAX_FIELDS) return NULL;
    sch->nfields = nfields;
    for (i = 0; i < (int)nfields; i++) {
        proto_field_t *f = &g_fld[i];
        c = g_fld_name[i];
        f->ftype  = (int)sch_byte(pos++);
        f->width  = (int)sch_byte(pos++);
        f->sem    = (int)sch_byte(pos++);
        f->endian = (int)sch_byte(pos++);
        f->bits   = (int)sch_byte(pos++);
        name_len  = sch_byte(pos++);
        if (name_len >= sizeof g_fld_name[0]) return NULL;
        {
            int k;
            for (k = 0; k < (int)name_len; k++)
                c[k] = (char)sch_byte(pos++);
            c[name_len] = 0;
        }
        f->name = c;
    }
    sch->fields = g_fld;
    return sch;
}

/* ------------------------------------------------------------------ */
/* schema registry (decoded on demand)                                 */
/* ------------------------------------------------------------------ */
const proto_schema_t *ps_schema_for(int opcode) {
    int i;
    for (i = 0; i < PROTO_SCHEMA_COUNT; i++) {
        const proto_schema_t *sch = ps_load(i);
        if (sch == NULL) return NULL;
        if (sch->opcode == opcode) return sch;
    }
    return NULL;
}

const proto_schema_t *ps_schema_by_index(int idx) {
    if (idx < 0 || idx >= PROTO_SCHEMA_COUNT) return NULL;
    return ps_load(idx);
}

/* identify a payload by its lead token (E0) -- the name check inside
 * pe_decode disambiguates; try every schema and keep the first that
 * parses cleanly                                                     */
const proto_schema_t *ps_schema_by_lead(const uint8_t *body, size_t n) {
    int i;
    for (i = 0; i < PROTO_SCHEMA_COUNT; i++) {
        const proto_schema_t *sch = ps_schema_by_index(i);
        proto_msg_t scratch;
        if (sch == NULL) return NULL;
        if (!pe_decode(sch, body, n, &scratch)) return sch;
    }
    return NULL;
}

int ps_sem_slot(const proto_schema_t *sch, int sem, int occurrence) {
    int i, seen = 0;
    if (sch == NULL) return -1;
    for (i = 0; i < sch->nfields; i++)
        if (sch->fields[i].sem == sem) {
            if (seen == occurrence) return i;
            seen++;
        }
    return -1;
}

/* ------------------------------------------------------------------ */
/* server-side FSM                                                     */
/* ------------------------------------------------------------------ */
static int st_is_command(int opcode) {
    return opcode == OP_GET || opcode == OP_SET || opcode == OP_SUM
        || opcode == OP_FLAG || opcode == OP_BYE;
}

/* ------------------------------------------------------------------ */
/* dialog-graph decoder: the serialized rich FSM, masked            */
/* and split exactly like the schema registry. One state's edge list  */
/* decodes into caller scratch per lookup -- no complete readable     */
/* table exists anywhere in the image or in memory at rest.           */
/*                                                                    */
/* stream layout (little records, mirrors gen_fsm.serialize_fsm):     */
/*   u8 n_states                                                       */
/*   per state: kind u8, timeout_ms u16le, n_edges u8, timeout_edge u8 */
/*   per edge: opcode, cls, cond_sem, cond_op, u32 operand, next,     */
/*             alt, err_code, flags, act                              */
/* ------------------------------------------------------------------ */
static uint8_t fsm_byte(size_t i) {
    const uint8_t *arr = ((i & 1) != 0) ? PROTO_FSM_B : PROTO_FSM_A;
    size_t cap = ((i & 1) != 0) ? sizeof PROTO_FSM_B
                                : sizeof PROTO_FSM_A;
    uint8_t x = (i >> 1) < cap ? arr[i >> 1] : 0;
    return (uint8_t)(x ^ PROTO_FSM_KS[i & 31]
                     ^ (uint8_t)((i * 41) & 0xFF));
}

static uint8_t fsm_hdr(void) { return fsm_byte(0); }

/* walk to state record -> byte offset of its kind field */
static size_t fsm_state_off(int state) {
    size_t off = 1;
    int i;
    for (i = 0; i < fsm_hdr(); i++) {
        if (i == state) return off;
        /* n_edges lives in THIS record's header (kind,tmo(2),n,tmo_e)
         * -- read it before advancing past the header             */
        {
            int k, n = fsm_byte(off + 3);
            off += 5;
            for (k = 0; k < n; k++)
                off += 13;
        }
    }
    return (size_t)-1;                  /* out of range: caller fails */
}

int ps_fsm_entry(void) {
    (void)fsm_hdr();
    return 0;                           /* entry is state 0 (LINK) */
}

int ps_fsm_n_states(void) { return fsm_hdr(); }

uint8_t ps_fsm_kind(int state) {
    size_t off = fsm_state_off(state);
    return off == (size_t)-1 ? 255 : fsm_byte(off);
}

uint32_t ps_fsm_timeout_ms(int state) {
    size_t off = fsm_state_off(state);
    if (off == (size_t)-1) return 0;
    return (uint32_t)fsm_byte(off + 1)
         | ((uint32_t)fsm_byte(off + 2) << 8);
}

int ps_fsm_timeout_edge(int state) {
    size_t off = fsm_state_off(state);
    if (off == (size_t)-1) return -1;
    {
        int t = fsm_byte(off + 4);
        return t == 0xFF ? -1 : t;
    }
}

int ps_fsm_find_kind(uint8_t kind) {
    int i;
    for (i = 0; i < fsm_hdr(); i++)
        if (ps_fsm_kind(i) == kind) return i;
    return -1;
}

int ps_fsm_is_kind(int state, uint8_t kind) {
    return ps_fsm_kind(state) == kind;
}

/* enumerate: edge #idx of state (table order) -- the walker's API */
int ps_fsm_edge_at(int state, int idx, ps_fsm_edge_t *out) {
    size_t off = fsm_state_off(state);
    int k, n;
    if (off == (size_t)-1) return 1;
    n = fsm_byte(off + 3);
    if (idx < 0 || idx >= n) return 1;
    off += 5 + (size_t)idx * 13;
    out->opcode = fsm_byte(off);
    out->cls = fsm_byte(off + 1);
    out->cond_sem = fsm_byte(off + 2);
    out->cond_op = fsm_byte(off + 3);
    out->cond_operand = (uint32_t)fsm_byte(off + 4)
        | ((uint32_t)fsm_byte(off + 5) << 8)
        | ((uint32_t)fsm_byte(off + 6) << 16)
        | ((uint32_t)fsm_byte(off + 7) << 24);
    out->next = fsm_byte(off + 8);
    out->alt = fsm_byte(off + 9);
    out->err_code = fsm_byte(off + 10);
    out->flags = fsm_byte(off + 11);
    out->act = fsm_byte(off + 12);
    return 0;
}

int ps_fsm_edge(int state, int opcode, ps_fsm_edge_t *out) {
    size_t off = fsm_state_off(state);
    int k, n;
    if (off == (size_t)-1) return 1;
    n = fsm_byte(off + 3);
    off += 5;
    for (k = 0; k < n; k++) {
        if (fsm_byte(off) == (uint8_t)opcode) {
            out->opcode = fsm_byte(off);
            out->cls = fsm_byte(off + 1);
            out->cond_sem = fsm_byte(off + 2);
            out->cond_op = fsm_byte(off + 3);
            out->cond_operand = (uint32_t)fsm_byte(off + 4)
                | ((uint32_t)fsm_byte(off + 5) << 8)
                | ((uint32_t)fsm_byte(off + 6) << 16)
                | ((uint32_t)fsm_byte(off + 7) << 24);
            out->next = fsm_byte(off + 8);
            out->alt = fsm_byte(off + 9);
            out->err_code = fsm_byte(off + 10);
            out->flags = fsm_byte(off + 11);
            out->act = fsm_byte(off + 12);
            return 0;
        }
        off += 13;
    }
    return 1;
}
