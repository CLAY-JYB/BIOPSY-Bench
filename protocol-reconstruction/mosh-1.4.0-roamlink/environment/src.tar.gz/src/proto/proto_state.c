/* proto_state.c -- state axis (S): schema registry + server FSM.
 *
 * Static asset, level-switched via proto_config.h:
 *   S0  stateless: every request answered in any order
 *   S1  HELLO/version gate, then a flat command session
 *   S2  + AUTH challenge-response, session id, per-message sequencing
 *   S3  + PARAMS negotiation stage, error/recovery (RESYNC -> HELLO),
 *       duplicate-sequence tolerance (retransmission)
 *
 * The transition table drives both server enforcement and the GT
 * state-machine dump in meta.json.
 *
 * SCHEMA REGISTRY ANTI-LEAK (2026-08 detour audit): the message table
 * used to live as readable structs in .data (field names, types,
 * semantics, widths -- a gdb/objdump dump of the challenge binary WAS
 * the answer key). proto_config.h now emits the registry XOR-masked
 * and SPLIT across two byte arrays; the accessors below decode ONE
 * schema at a time into scratch storage, so no complete readable
 * table exists anywhere in the image or in memory at rest. The
 * returned pointer is valid until the next ps_* call (no call site
 * holds two schema pointers; pe_encode/pe_decode never re-enter
 * ps_*).
 */

#include <string.h>

/* ------------------------------------------------------------------ */
/* encoded-registry reader                                             */
/* ------------------------------------------------------------------ */
/* stream layout (little records, all u8):
 *   message: opcode, dir, name_len, name[name_len], nfields
 *   field:   ftype, width, sem, endian, bits, name_len, name[name_len]
 */
static uint8_t sch_byte(size_t i) {
    /* halves are interleaved (split storage); the keystream is the
     * seeded base rolled per position. The half-array bound makes the
     * reader total: a truncated stream reads as zeros and the parser
     * above returns NULL instead of running off the tables.          */
    const uint8_t *arr = ((i & 1) != 0) ? PROTO_SCHEMA_B : PROTO_SCHEMA_A;
    size_t cap = ((i & 1) != 0) ? sizeof PROTO_SCHEMA_B
                                : sizeof PROTO_SCHEMA_A;
    uint8_t b;
    if ((i >> 1) >= cap) return 0;
    b = arr[i >> 1];
    return (uint8_t)(b ^ PROTO_SCHEMA_KS[i & 31]
                     ^ (uint8_t)((i * 41) & 0xFF));
}

/* one-schema scratch: the ONLY place a decoded schema ever exists.
 * Thread-local: the threaded oracle serves concurrent connections
 * (the C10 probe) and each thread decodes its own schemas; the
 * sequential carrier build has one thread, unchanged behavior.    */
static __thread proto_schema_t g_sch;
static __thread proto_field_t  g_fld[PROTO_MAX_FIELDS];
static __thread char           g_sch_name[32];
static __thread char           g_fld_name[PROTO_MAX_FIELDS][32];

/* parse record #idx into the scratch; NULL when out of range or the
 * stream is malformed (bounds-guarded: corrupt constants can never
 * crash the engine)                                              */
static const proto_schema_t *ps_load(int idx) {
    size_t pos = 0;
    int rec;
    uint8_t opcode, dir, name_len, nfields;
    uint8_t *u;
    char *c;
    int i;
    proto_schema_t *sch;
    if (idx < 0) return NULL;
    for (rec = 0; rec <= idx; rec++) {
        opcode   = sch_byte(pos++);
        dir      = sch_byte(pos++);
        name_len = sch_byte(pos++);
        if (name_len == 0 || name_len >= sizeof g_sch_name) return NULL;
        if (rec == idx) break;
        pos += name_len;                       /* skip this name     */
        nfields = sch_byte(pos++);
        if (nfields > PROTO_MAX_FIELDS) return NULL;
        for (i = 0; i < (int)nfields; i++) {
            uint8_t fn, fl[5];
            int k;
            for (k = 0; k < 5; k++) fl[k] = sch_byte(pos++);
            (void)fl;                          /* skip this field    */
            fn = sch_byte(pos++);
            pos += fn;
        }
    }
    if (rec != idx) return NULL;
    sch = &g_sch;
    memset(sch, 0, sizeof *sch);
    memset(g_fld, 0, sizeof g_fld);
    u = (uint8_t *)g_sch_name;
    for (i = 0; i < (int)name_len; i++) u[i] = sch_byte(pos++);
    u[name_len] = 0;
    sch->name = g_sch_name;
    sch->opcode = opcode;
    sch->dir = (dir == 1) ? PDIR_C2S : PDIR_S2C;
    nfields = sch_byte(pos++);
    if (nfields > PROTO_MAX_FIELDS) return NULL;
    sch->nfields = nfields;
    for (i = 0; i < (int)nfields; i++) {
        proto_field_t *f = &g_fld[i];
        c = g_fld_name[i];
        f->ftype  = (int)sch_byte(pos++);
        f->width  = (int)sch_byte(pos++);
        f->sem    = (int)sch_byte(pos++);
        f->endian = (int)sch_byte(pos++);
        f->bits   = (int)sch_byte(pos++);
        name_len  = sch_byte(pos++);
        if (name_len >= sizeof g_fld_name[0]) return NULL;
        {
            int k;
            for (k = 0; k < (int)name_len; k++)
                c[k] = (char)sch_byte(pos++);
            c[name_len] = 0;
        }
        f->name = c;
    }
    sch->fields = g_fld;
    return sch;
}

/* ------------------------------------------------------------------ */
/* schema registry (decoded on demand)                                 */
/* ------------------------------------------------------------------ */
const proto_schema_t *ps_schema_for(int opcode) {
    int i;
    for (i = 0; i < PROTO_SCHEMA_COUNT; i++) {
        const proto_schema_t *sch = ps_load(i);
        if (sch == NULL) return NULL;
        if (sch->opcode == opcode) return sch;
    }
    return NULL;
}

const proto_schema_t *ps_schema_by_index(int idx) {
    if (idx < 0 || idx >= PROTO_SCHEMA_COUNT) return NULL;
    return ps_load(idx);
}

/* identify a payload by its lead token (E0) -- the name check inside
 * pe_decode disambiguates; try every schema and keep the first that
 * parses cleanly                                                     */
const proto_schema_t *ps_schema_by_lead(const uint8_t *body, size_t n) {
    int i;
    for (i = 0; i < PROTO_SCHEMA_COUNT; i++) {
        const proto_schema_t *sch = ps_schema_by_index(i);
        proto_msg_t scratch;
        if (sch == NULL) return NULL;
        if (!pe_decode(sch, body, n, &scratch)) return sch;
    }
    return NULL;
}

int ps_sem_slot(const proto_schema_t *sch, int sem, int occurrence) {
    int i, seen = 0;
    if (sch == NULL) return -1;
    for (i = 0; i < sch->nfields; i++)
        if (sch->fields[i].sem == sem) {
            if (seen == occurrence) return i;
            seen++;
        }
    return -1;
}

/* ------------------------------------------------------------------ */
/* server-side FSM                                                     */
/* ------------------------------------------------------------------ */
static int st_is_command(int opcode) {
    return opcode == OP_GET || opcode == OP_SET || opcode == OP_SUM
        || opcode == OP_FLAG || opcode == OP_BYE;
}

int ps_server_allow(const proto_session_t *s, int opcode) {
    switch (PROTO_S_LEVEL) {
    case 0:
        return 1;
    case 1:
        if (s->state == PST_WAIT_HELLO)
            return opcode == OP_HELLO;
        return opcode != OP_HELLO;
    case 2:
        if (s->state == PST_WAIT_HELLO)  return opcode == OP_HELLO;
        if (s->state == PST_WAIT_AUTH)   return opcode == OP_AUTH;
        return st_is_command(opcode) || opcode == OP_PING
            || opcode == OP_STAT
            || (PROTO_L_LEVEL >= 2 && opcode == OP_MUX_OPEN)
            || (PROTO_S_LEVEL >= 6 && (opcode == OP_TXN_BEGIN
                                       || opcode == OP_TXN_COMMIT
                                       || opcode == OP_TXN_ROLLBACK));
    default: /* S3 */
        if (s->state == PST_WAIT_HELLO)  return opcode == OP_HELLO;
        if (s->state == PST_WAIT_PARAMS) return opcode == OP_PARAMS;
        if (s->state == PST_WAIT_AUTH)   return opcode == OP_AUTH;
        if (s->state == PST_RESYNC)      return opcode == OP_HELLO;
        return st_is_command(opcode) || opcode == OP_PING
            || opcode == OP_STAT
            || (PROTO_L_LEVEL >= 2 && opcode == OP_MUX_OPEN)
            || (PROTO_S_LEVEL >= 6 && (opcode == OP_TXN_BEGIN
                                       || opcode == OP_TXN_COMMIT
                                       || opcode == OP_TXN_ROLLBACK));
    }
}

int ps_server_step(proto_session_t *s, int opcode) {
    if (!ps_server_allow(s, opcode)) return -1;
    switch (opcode) {
    case OP_HELLO:
        s->state = (PROTO_S_LEVEL == 1) ? PST_SESSION
                 : (PROTO_S_LEVEL == 2) ? PST_WAIT_AUTH
                 :                         PST_WAIT_PARAMS;
        return 0;
    case OP_PARAMS:
        s->state = PST_WAIT_AUTH;
        return 0;
    case OP_AUTH:
        s->authed = 1;
        s->state = PST_SESSION;
        return 0;
    case OP_BYE:
        s->state = PST_CLOSED;
        return 0;
    default:
        return 0;                    /* commands stay in SESSION    */
    }
}
