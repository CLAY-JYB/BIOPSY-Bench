/* carrier-side defaults for the mosh carrier.
 *
 * Host-bound construction (reference/host-binding.md). mosh has NO
 * config-file subsystem; its real state surfaces are MOSH_* environment
 * variables (strtol-parsed, see MOSH_SERVER_NETWORK_TMOUT in
 * mosh-server.cc) and files it genuinely reads (/etc/motd via
 * print_motd). This unit materializes the engine's wire constants
 * through those two REAL mechanisms:
 *
 *   - MOSH_SERVER_UI_* environment values carry the framing constants
 *     (baked into the image environment, like every other MOSH_ var)
 *   - the /etc/motd text carries the key-exchange seed on a marked
 *     line, read exactly the way print_motd reads the file
 *   - the remaining secrets decode from masked tables below
 *
 * Any failure -- a tracer observed, a missing or tampered host state --
 * installs the DECOY material instead: the engine then speaks a
 * self-consistent but wrong dialect rather than crashing or refusing.
 *
 * Build note: compiled under a different obfuscation stack than the
 * engine (see the environment Dockerfile); never leaves the build.
 */

#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>          /* tigress InitTiming/opaque runtime needs it */

/* mosh reads its environment and files directly (no config API); the
 * glue uses the same libc surface mosh-server itself uses */

/* ---- engine storage (externs under PROTO_HOST_MATERIAL) ----------- */
uint8_t  PROTO_MAGIC[4];
uint32_t proto_version_value;
uint8_t  PROTO_XOR_KEY[32];
uint8_t  PROTO_RC4_KEY[16];
uint8_t  PROTO_AUTH_SECRET[16];
uint8_t  PROTO_SERVER_PRIV[32];
uint8_t  PROTO_HOST_KEX_SALT[16];
uint8_t  PROTO_CHACHA_KEY[32];
uint8_t  PROTO_AES_KEY[16];
uint8_t  PROTO_AES_IV[8];
uint8_t  PROTO_XTEA_KEY[16];
uint8_t  PROTO_XTEA_IV[8];

/* ---- masked site-B material ----------------------------------------
 * seed[i] = blob[i] ^ mask[i & 31] ^ ((i * 33) & 0xFF); adef_unmask
 * reverses it. The mask rides the construction seed and appears
 * nowhere else in the image.                                       */
static const unsigned char adef_blob_a[32 + 32] =
{0x18, 0xf5, 0xfa, 0xfc, 0x94, 0x59, 0xd2, 0xe9, 0xbd, 0x43, 0x6a, 0xe7,
 0xfa, 0x03, 0x47, 0x91, 0xfd, 0x7a, 0xb5, 0x99, 0x3e, 0xeb, 0xde, 0x35,
 0x29, 0x01, 0x9a, 0x90, 0xf3, 0x95, 0x7a, 0xb1, 0xb6, 0xb0, 0xf5, 0xe3,
 0xa8, 0x3a, 0xbc, 0xd8, 0x89, 0x50, 0xc3, 0xfb, 0x90, 0x5a, 0xdb, 0x74,
 0xc6, 0x54, 0xcd, 0x77, 0x6d, 0x30, 0x83, 0x47, 0x8e, 0x0b, 0xb7, 0xec,
 0x06, 0x68, 0x2a, 0x85};
static const unsigned char adef_blob_b[32] =
{0x40, 0x55, 0x00, 0x6f, 0xb5, 0x1d, 0x03, 0xd0, 0x91, 0x24, 0x87, 0xfc,
 0xa8, 0x94, 0x64, 0x88, 0x1f, 0x71, 0xb5, 0xa2, 0xf5, 0x72, 0xa5, 0x08,
 0x46, 0x91, 0x2e, 0xd2, 0xdb, 0xca, 0x54, 0x66};
static const unsigned char adef_blob_c[88] =
{0xbe, 0x44, 0xfe, 0x2f, 0x6d, 0x9d, 0x36, 0x97, 0x29, 0x53, 0xdc, 0xc3,
 0xb7, 0xfc, 0x23, 0xf4, 0x27, 0x0d, 0x1e, 0xab, 0xf4, 0x7a, 0xc5, 0x6c,
 0xcc, 0x2e, 0x3b, 0xf5, 0x09, 0x18, 0x41, 0x30, 0x45, 0x23, 0xd9, 0x07,
 0xc7, 0x88, 0xe6, 0xdd, 0xac, 0x31, 0xe3, 0x10, 0xcf, 0x56, 0x98, 0x7f,
 0x35, 0xa2, 0x41, 0x2a, 0xec, 0x1b, 0xe4, 0x5a, 0x1a, 0x1f, 0xc0, 0x63,
 0xfc, 0xc6, 0x99, 0x26, 0xb6, 0xab, 0x64, 0xa3, 0x6b, 0x05, 0xa3, 0x83,
 0x33, 0x79, 0xa8, 0x0e, 0x95, 0xe6, 0x90, 0xf1};
static const unsigned char adef_decoy[137] =
{0x2f, 0xe8, 0x6f, 0x16, 0x86, 0x3d, 0x7a, 0xb2, 0x75, 0x30, 0xf4, 0x4c,
 0x9d, 0xa0, 0xf1, 0x0c, 0x71, 0xbb, 0x12, 0xf6, 0x7f, 0x02, 0xf4, 0xe9,
 0x6b, 0x7e, 0x96, 0x65, 0xa8, 0xf0, 0x85, 0xc4, 0x02, 0xbd, 0xda, 0x1e,
 0xa6, 0x9d, 0xc4, 0xbb, 0x96, 0xd6, 0x49, 0xe8, 0x10, 0x5b, 0xb2, 0xfb,
 0x3c, 0xdb, 0xee, 0xd9, 0x16, 0xa9, 0x57, 0x02, 0x4b, 0x1e, 0xb6, 0x85,
 0x88, 0x90, 0xa5, 0x24, 0x62, 0x9d, 0x3a, 0x3e, 0xc6, 0xbd, 0x24, 0x9b,
 0xf6, 0xf6, 0xa9, 0xc8, 0x70, 0x7b, 0x52, 0xdb, 0x5c, 0xfb, 0x0e, 0xf9,
 0x76, 0x89, 0xb7, 0x22, 0x2b, 0x3e, 0x56, 0xa5, 0xe8, 0xb0, 0x45, 0x04,
 0x42, 0x7d, 0x1a, 0x5e, 0xe6, 0x5d, 0x04, 0xfb, 0xe6, 0x4e, 0x9c, 0x94,
 0xdd, 0xc0, 0x6e, 0x1b, 0x42, 0x7e, 0x68, 0x5b, 0x42, 0x5d, 0x84, 0x89,
 0x1d, 0x0e, 0x09, 0x5f, 0x9d, 0x31, 0x8c, 0x82, 0x80, 0xca, 0x41, 0x75,
 0xa8, 0x28, 0x99, 0x20, 0x08};

static const unsigned char adef_mask[32] =
{0x22, 0xfc, 0xb8, 0x9d, 0x02, 0x58, 0x22, 0xbc, 0xbe, 0x9f, 0x23, 0x63,
 0xbc, 0x96, 0x5c, 0xf4, 0x0c, 0x8a, 0x9c, 0x4a, 0xa2, 0x7c, 0xa1, 0x15,
 0x73, 0x47, 0xcc, 0x1e, 0x34, 0x4d, 0x5b, 0x3b};

static void adef_unmask(const unsigned char *in, unsigned char *out,
                        int n) {
    int i;
    for (i = 0; i < n; i++)
        out[i] = (unsigned char)(in[i] ^ adef_mask[i & 31]
                                 ^ ((i * 33) & 0xFF));
}

static int adef_hex(const char *s, unsigned char *out, int n) {
    int i;
    for (i = 0; i < n; i++) {
        unsigned v;
        char pair[3];
        pair[0] = s[2 * i];
        pair[1] = s[2 * i + 1];
        pair[2] = 0;
        if (!isxdigit((unsigned char)pair[0]) ||
            !isxdigit((unsigned char)pair[1]))
            return -1;
        v = (unsigned)strtoul(pair, NULL, 16);
        out[i] = (unsigned char)v;
    }
    return 0;
}

/* minimal, self-contained observation check: a TracerPid (or an
 * unreadable /proc) means this boot is being watched */
static int adef_observed(void) {
    FILE *f = fopen("/proc/self/status", "r");
    char line[160];
    if (!f)
        return 1;
    while (fgets(line, sizeof line, f)) {
        if (!strncmp(line, "TracerPid:", 10)) {
            int v = atoi(line + 10);
            fclose(f);
            return v != 0;
        }
    }
    fclose(f);
    return 1;
}

/* tigress Init* target: instrumented as a SEPARATE stub that runs FIRST
 * (same contract as the engine's init_tigress) -- instrumenting
 * ast_proto_boot itself lets Flatten hoist opaque predicates above their
 * own initialisation (SIGFPE, the documented chicken-and-egg).        */
static void adef_init(void) { }

/* tigress whole-program boot (the dummy main, renamed at link): CIL
 * relocates every non-constant initialiser -- including the opaque/
 * encoded-data seed tables -- into it. It MUST run before any encoded
 * data or opaque predicate is touched; the engine TU follows the same
 * contract with proto_tigress_boot.                              */
int adef_dummy_boot(int argc, char **argv, char **envp);

int ast_proto_boot(void) {

    unsigned char magic[4], salt[16], sec_a[32 + 32];
    unsigned char sec_b[32], sec_c[88];
    uint32_t version = 0;
    int ok = 1;

    adef_dummy_boot(0, 0, 0);
    adef_init();
    /* fail-closed: decoy first, commit only on a fully clean boot.
     * decoy layout: MAGIC(4) VERSION(4,BE) SALT(16) XOR(16) RC4(16)
     *               AUTH(16) PRIV(32) pad(33)                          */
    {
        unsigned char d[137];
        adef_unmask(adef_decoy, d, sizeof d);
        memcpy(PROTO_MAGIC, d, 4);
        proto_version_value = ((uint32_t)d[4]) | ((uint32_t)d[5] << 8)
            | ((uint32_t)d[6] << 16) | ((uint32_t)d[7] << 24);
        memcpy(PROTO_HOST_KEX_SALT, d + 8, 16);
        memcpy(PROTO_XOR_KEY, d + 24, sizeof PROTO_XOR_KEY);
        memcpy(PROTO_RC4_KEY, d + 40, 16);
        memcpy(PROTO_AUTH_SECRET, d + 56, 16);
        memcpy(PROTO_SERVER_PRIV, d + 72, 32);
        /* C-wave static cipher keys: all-zero in the decoy dialect
         * (deterministic; the decoy only needs self-consistency) */
        memset(PROTO_CHACHA_KEY, 0, 32);
        memset(PROTO_AES_KEY, 0, 16);
        memset(PROTO_AES_IV, 0, 8);
        memset(PROTO_XTEA_KEY, 0, 16);
        memset(PROTO_XTEA_IV, 0, 8);
    }

    if (adef_observed())
        return 0;                       /* watched boot: decoy stays */

    /* site C part 1 -- MOSH_* environment values (the carrier's native
     * configuration surface, cf. MOSH_SERVER_NETWORK_TMOUT) carry the
     * framing constants */
    {
        const char *ev;
        ev = getenv("MOSH_SERVER_UI_KEY");
        if (ev == NULL || strlen(ev) < 8 || adef_hex(ev, magic, 4) != 0)
            ok = 0;
        ev = getenv("MOSH_SERVER_UI_VER");
        if (ev != NULL && *ev)
            version = (uint32_t)strtoul(ev, NULL, 10);
        else
            ok = 0;
    }

    /* site C part 2 -- /etc/motd, read exactly the way the carrier's
     * print_motd() reads it, carries the KEX seed on a marked line */
    {
        char line[256];
        int found = 0;
        FILE *mf = fopen("/etc/motd", "r");
        if (mf == NULL) {
            ok = 0;
        } else {
            while (fgets(line, sizeof line, mf)) {
                if (!strncmp(line, "~~ ", 3) && strlen(line) >= 35) {
                    if (adef_hex(line + 3, salt, 16) == 0)
                        found = 1;
                    break;
                }
            }
            fclose(mf);
        }
        if (!found)
            ok = 0;
    }

    /* site B -- masked blobs decode locally */
    adef_unmask(adef_blob_a, sec_a, sizeof sec_a);
    adef_unmask(adef_blob_b, sec_b, sizeof sec_b);
    adef_unmask(adef_blob_c, sec_c, sizeof sec_c);

    if (!ok)
        return 0;                       /* tampered host: decoy stays */

    memcpy(PROTO_MAGIC, magic, 4);
    proto_version_value = version;
    memcpy(PROTO_HOST_KEX_SALT, salt, 16);
    memcpy(PROTO_XOR_KEY, sec_a, 32);
    memcpy(PROTO_RC4_KEY, sec_a + 32, 16);
    memcpy(PROTO_AUTH_SECRET, sec_a + 32 + 16, 16);
    memcpy(PROTO_SERVER_PRIV, sec_b, 32);
    memcpy(PROTO_CHACHA_KEY, sec_c, 32);
    memcpy(PROTO_AES_KEY, sec_c + 32, 16);
    memcpy(PROTO_AES_IV, sec_c + 48, 8);
    memcpy(PROTO_XTEA_KEY, sec_c + 56, 16);
    memcpy(PROTO_XTEA_IV, sec_c + 72, 8);
    return 0;
}
