/* proto_conceal.c -- protocol-native concealment axis (X).
 *
 * Static asset, level-switched via proto_config.h:
 *   X1  anti-replay: per-connection nonce + per-message proof
 *       (HMAC-SHA256(auth_secret, seq||body), truncated to 8 bytes)
 *   X2  session-keyed payload mask (HKDF off the nonce), chaff frames,
 *       decoy opcodes with plausible handlers   [requires F>=3]
 *   X3  transport fragmentation (reassembly headers) + protocol
 *       mimicry (fake HTTP wrapper)             [requires F>=3]
 *
 * Design precedents in SKILL.md: RFC 8446 key schedule / fresh nonces,
 * Rivest chaffing-and-winnowing, Tor obfs4 padding, meek mimicry.
 */

#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>

/* ------------------------------------------------------------------ */
/* engine-internal literals: XOR-obfuscated at rest                    */
/* ------------------------------------------------------------------ */
/* The entry flag, milestone env names, protocol tags and mimicry
 * templates are stored encoded so no grep-able plaintext rides in
 * .rodata (an analyst must read code, not run `strings`). Not seeded:
 * none of these is ground-truth material; the encoding only removes the
 * free fingerprint that used to hand over the hidden mode.           */
/* the X3 mimicry templates live in proto_config.h now: the generator
 * re-encodes them with the seeded HTTP verb/version (PROTO_X3_*_ENC),
 * so the fingerprint varies per task and no plaintext rides here    */

/* decode n bytes of an encoded literal into out (NUL-terminated);
 * callers pass a stack buffer, so the plaintext exists only for the
 * duration of one call                                            */
void px_strdec(char *out, const uint8_t *enc, size_t n) {
    static const uint8_t k[16] = {0x91, 0x3c, 0x5f, 0xc2, 0x2e,
                                  0xa4, 0x6d, 0x1b, 0x77, 0xe0,
                                  0x0a, 0x49, 0xd3, 0x36, 0xb8,
                                  0x65};
    size_t i;
    for (i = 0; i < n; i++)
        out[i] = (char)(enc[i] ^ k[i & 15] ^ (uint8_t)(i * 29));
    out[n] = 0;
}

/* ------------------------------------------------------------------ */
/* per-connection identity                                             */
/* ------------------------------------------------------------------ */
void px_session_init(proto_session_t *s, int is_server) {
    memset(s, 0, sizeof *s);
    s->is_server = is_server;
    prng_seed(s);
    if (is_server) {
        /* fresh nonce + session id per connection: recorded sessions
         * can never be replayed against a new connection. The ACTIVE
         * nonce width is the seeded C3/X1 knob (the array holds the
         * historical 16 so the struct layout stays stable).         */
        size_t i;
        for (i = 0; i < sizeof s->nonce; i++)
            s->nonce[i] = (uint8_t)prng_next(s);
        s->session_id = (uint32_t)prng_next(s);
        pc_prv_kdf(s->nonce, PROTO_NONCE_W, s->nonce, PROTO_NONCE_W,
                PROTO_HKDF_MASK_LABEL, s->mask_key);
    }
}

/* client side: adopt the server nonce (from HELLO_ACK) and derive the
 * session-keyed mask                                             */
void px_client_set_nonce(proto_session_t *s, const uint8_t *nonce) {
    memcpy(s->nonce, nonce, PROTO_NONCE_W);
    pc_prv_kdf(s->nonce, PROTO_NONCE_W, s->nonce, PROTO_NONCE_W,
            PROTO_HKDF_MASK_LABEL, s->mask_key);
    s->nonce_live = 1;         /* proofs bind the nonce from here on */
}

/* ------------------------------------------------------------------ */
/* X1: anti-replay proof                                               */
/* ------------------------------------------------------------------ */
void px_proof(const proto_session_t *s, uint64_t seq,
              const uint8_t *body, size_t n, uint8_t out[16]) {
    uint8_t mac[32];
    uint8_t buf[PROTO_FRAME_MAX + 8 + 16];
    /* nonce || seq || body: proofs are bound to THIS connection, so a
     * frame recorded on one connection cannot replay on another      */
    memcpy(buf, s->nonce, PROTO_NONCE_W);
    memcpy(buf + PROTO_NONCE_W, &seq, 8);
    if (n > PROTO_FRAME_MAX) n = PROTO_FRAME_MAX;
    memcpy(buf + PROTO_NONCE_W + 8, body, n);
    pc_prv_hash(PROTO_AUTH_SECRET, PROTO_AUTH_SECRET_LEN,
                   buf, PROTO_NONCE_W + 8 + n, mac);
    memcpy(out, mac, PROTO_PROOF_TRUNC);
}

int px_verify(const proto_session_t *s, uint64_t seq,
              const uint8_t *body, size_t n, const uint8_t proof[16]) {
    uint8_t want[16];
    px_proof(s, seq, body, n, want);
    return memcmp(want, proof, PROTO_PROOF_TRUNC) ? -1 : 0;
}

/* ------------------------------------------------------------------ */
/* X2: session-keyed payload mask                                      */
/* ------------------------------------------------------------------ */
void px_mask(uint8_t *buf, size_t n, const proto_session_t *s) {
    size_t off = 0;
    /* L6: the mask key is derived per (session, channel) -- traffic on
     * one channel cannot be unmasked with another channel's material */
    uint8_t key[32];
    memcpy(key, s->mask_key, 32);
    if (PROTO_L_LEVEL >= 6) {
        uint8_t seed[33], kb[32];
        memcpy(seed, s->mask_key, 32);
        seed[32] = (uint8_t)s->chan;
        pc_prv_hash(s->mask_key, 32, seed, 33, kb);
        memcpy(key, kb, 32);
    }
    while (off < n) {
        uint8_t ks[32];
        uint8_t ib[4] = {(uint8_t)(off / 32), (uint8_t)(off / 32 >> 8),
                         (uint8_t)(off / 32 >> 16), (uint8_t)(off / 32 >> 24)};
        size_t i;
        pc_prv_hash(key, 32, ib, 4, ks);
        for (i = 0; i < 32 && off + i < n; i++)
            buf[off + i] ^= ks[i];
        off += 32;
    }
}

void px_frame_material(const proto_session_t *s, uint8_t magic_out[4],
                       uint32_t *crc_seed, uint32_t *crc_post) {
    px_frame_material_dir(s, s->is_server, magic_out, crc_seed,
                          crc_post);
}

void px_frame_material_dir(const proto_session_t *s, int is_server,
                           uint8_t magic_out[4],
                           uint32_t *crc_seed, uint32_t *crc_post) {
    px_frame_material_seq(s, is_server, 0, magic_out, crc_seed,
                          crc_post);
}

/* seq > 0 (the header's per-channel sequence byte): the magic folds
 * the sequence in as well, so EVERY frame on the wire starts with a
 * different byte pattern -- a capture shows no repeating prefix to
 * eyeball frame boundaries from. The sequence byte itself sits at a
 * fixed header offset, so the reader derives the expected magic for
 * the candidate it is looking at exactly like the writer did. Only
 * the magic rides the seq fold; the CRC keying stays per-connection
 * (it must cover bootstrap frames, which have no sequence yet).   */
void px_frame_material_seq(const proto_session_t *s, int is_server,
                           unsigned seq, uint8_t magic_out[4],
                           uint32_t *crc_seed, uint32_t *crc_post) {
    uint8_t mac[32];
    int i;
    memcpy(magic_out, PROTO_MAGIC, 4);
    *crc_seed = PROTO_CRC_INIT;
    *crc_post = PROTO_CRC_XOROUT;
    if (!s->nonce_live)
        return;                     /* bootstrap: the static material */
    /* X7: the two directions roll their material SEPARATELY -- an
     * analyst must recover BOTH the c2s and the s2c identity, and a
     * capture of one direction cannot forge the other            */
    pc_prv_hash(s->mask_key, 32,
                   (const uint8_t *)PROTO_FM_MAGIC_LABEL,
                   sizeof(PROTO_FM_MAGIC_LABEL) - 1, mac);
    if (PROTO_X_LEVEL >= 7) mac[0] ^= (is_server ? 0x5A : 0xA5);
    for (i = 0; i < 4; i++) magic_out[i] ^= mac[i];
    if (seq != 0) {
        uint8_t sb[36];
        memcpy(sb, (const uint8_t *)PROTO_FM_SEQ_LABEL,
               sizeof(PROTO_FM_SEQ_LABEL) - 1);
        sb[sizeof(PROTO_FM_SEQ_LABEL) - 1] = (uint8_t)seq;
        sb[sizeof(PROTO_FM_SEQ_LABEL)] = (uint8_t)(is_server ? 0xA7 : 0x5A);
        pc_prv_hash(s->mask_key, 32, sb,
                    sizeof(PROTO_FM_SEQ_LABEL) + 1, mac);
        for (i = 0; i < 4; i++) magic_out[i] ^= mac[i];
    }
    pc_prv_hash(s->mask_key, 32,
                   (const uint8_t *)PROTO_FM_CRCI_LABEL,
                   sizeof(PROTO_FM_CRCI_LABEL) - 1, mac);
    if (PROTO_X_LEVEL >= 7) mac[0] ^= (is_server ? 0x5A : 0xA5);
    *crc_seed ^= (uint32_t)(mac[0] | (mac[1] << 8) | (mac[2] << 16)
                            | ((uint32_t)mac[3] << 24));
    pc_prv_hash(s->mask_key, 32,
                   (const uint8_t *)PROTO_FM_CRCP_LABEL,
                   sizeof(PROTO_FM_CRCP_LABEL) - 1, mac);
    if (PROTO_X_LEVEL >= 7) mac[0] ^= (is_server ? 0x5A : 0xA5);
    *crc_post ^= (uint32_t)(mac[0] | (mac[1] << 8) | (mac[2] << 16)
                            | ((uint32_t)mac[3] << 24));
}

/* ------------------------------------------------------------------ */
/* X2: chaff frames                                                    */
/* ------------------------------------------------------------------ */
/* Build a plausible-looking but invalid frame: right magic, wrong
 * CRC/opcode. Readers drop it at the CRC (F4/F5) or unknown-opcode
 * (F3) checkpoint.                                              */
static int px_build_chaff(proto_session_t *s, uint8_t *out, size_t cap) {
    size_t len = 8 + (size_t)(prng_next(s) % 24);
    size_t i;
    size_t cw = PROTO_F4_CRC_W / 8;
    if (PROTO_F_LEVEL == 5) {
        /* escaped FLAG wrapper with a corrupted inner CRC (the escape
         * family is the seeded F5 knob set, so decoys look native)   */
        uint8_t inner[64];
        size_t il = 0;
        if (len > 32) len = 32;
        inner[il++] = PROTO_MAGIC[0];
        inner[il++] = PROTO_MAGIC[1];
        inner[il++] = 0x01;
        inner[il++] = 0;
        if (PROTO_ENDIAN_LITTLE) {
            inner[il++] = (uint8_t)len; inner[il++] = 0;
        } else {
            inner[il++] = 0; inner[il++] = (uint8_t)len;
        }
        inner[il++] = (uint8_t)(0x60 + prng_next(s) % 40);
        for (i = 0; i < len; i++) inner[il++] = (uint8_t)prng_next(s);
        for (i = 0; i < cw; i++)
            inner[il++] = (uint8_t)~prng_next(s);  /* bad CRC on purpose */
        if (2 + 2 * il + 2 > cap) return 0;
        out[0] = PROTO_F5_FLAG;
        {
            size_t o = 1, k;
            for (k = 0; k < il; k++) {
                if (inner[k] == PROTO_F5_FLAG) {
                    out[o++] = PROTO_F5_ESC;
                    out[o++] = PROTO_F5_FLAG ^ PROTO_F5_ESC_XOR;
                } else if (inner[k] == PROTO_F5_ESC) {
                    out[o++] = PROTO_F5_ESC;
                    out[o++] = PROTO_F5_ESC ^ PROTO_F5_ESC_XOR;
                } else out[o++] = inner[k];
            }
            out[o++] = PROTO_F5_FLAG;
            return (int)o;
        }
    }
    if (PROTO_F_LEVEL <= 2) return 0;        /* no integrity point */
    if (PROTO_F_LEVEL == 6) {
        /* F6: the body region is COBS-stuffed and the frame carries the
         * CRC tail at F>=4 -- a decoy with a RAW body promises fewer
         * bytes than the reader's total, the phantom frame then eats
         * the real reply's lead bytes and the stream wedges. Build the
         * native shape: rolled magic, stuffed body, delimiter, bad CRC */
        size_t hdr = (size_t)pf_f3_hdrlen();
        uint8_t body[40], stuffed[160], fm[4];
        uint32_t fseed, fpost;
        size_t sn, o;
        if (len > 32) len = 32;
        for (i = 0; i < len; i++) body[i] = (uint8_t)prng_next(s);
        sn = pf_cobs_encode(body, len, stuffed, sizeof stuffed);
        if (sn == 0 || hdr + sn + cw > cap) return 0;
        px_frame_material(s, fm, &fseed, &fpost);
        memcpy(out, fm, PROTO_F3_MAGIC_LEN);
        pf_put_u(out + PROTO_F3_MAGIC_LEN, PROTO_VERSION, PROTO_F3_VER_W);
        out[pf_f3_op_off()] = (uint8_t)(0x60 + prng_next(s) % 40);
        for (o = 0; o < (size_t)pf_f3_chan_w(); o++)
            out[pf_f3_chan_off() + o] = 0;   /* native-looking L bytes */
        if (PROTO_L_LEVEL >= 1) out[pf_f3_seq_off()] = 0;
        pf_put_u(out + pf_f3_len_off(), sn, PROTO_F3_LEN_W);
        memcpy(out + hdr, stuffed, sn);
        for (i = 0; i < cw; i++)            /* wrong by construction */
            out[hdr + sn + i] = (uint8_t)~prng_next(s);
        return (int)(hdr + sn + cw);
    }
    {
        size_t hdrlen = (size_t)pf_f3_hdrlen();
        if (hdrlen + len + cw > cap) return 0;
        memcpy(out, PROTO_MAGIC, PROTO_F3_MAGIC_LEN);
        pf_put_u(out + PROTO_F3_MAGIC_LEN, PROTO_VERSION, PROTO_F3_VER_W);
        out[pf_f3_op_off()] = (uint8_t)(0x60 + prng_next(s) % 40);
        pf_put_u(out + pf_f3_len_off(), len, PROTO_F3_LEN_W);
        for (i = 0; i < len; i++)
            out[hdrlen + i] = (uint8_t)prng_next(s);
        if (PROTO_F_LEVEL == 4) {
            for (i = 0; i < cw; i++)           /* wrong by construction */
                out[hdrlen + len + i] = (uint8_t)(0xA5 ^ i);
            return (int)(hdrlen + len + cw);
        }
        return (int)(hdrlen + len);
    }
}

/* T seam: chaos/chaff emissions honor the session's transport (the
 * raw retry loop is the TCP fallback inside pf_send_raw's write path) */
static int px_write_all_raw(proto_session_t *s, int fd,
                            const uint8_t *buf, size_t n) {
    return pf_send_raw(s, fd, buf, n);
}

int px_maybe_chaff(proto_session_t *s, int fd) {
    uint8_t chaff[256];
    int n;
    if (PROTO_X_LEVEL < 2) return 0;
    if ((prng_next(s) & 7) >= PROTO_CHAFF_RATE) return 0;  /* p=rate/8 */
    n = px_build_chaff(s, chaff, sizeof chaff);
    if (n <= 0) return 0;
    if (PROTO_X_LEVEL >= 3)
        return px_frag_write(s, fd, chaff, (size_t)n);
    return px_write_all_raw(s, fd, chaff, (size_t)n);
}

/* ------------------------------------------------------------------ */
/* chaos registry + faulted server write path (verifier robustness    */
/* battery; reference/scoring.md). ONE fault per oracle run; mode     */
/* NONE never reaches this code.                                     */
/* ------------------------------------------------------------------ */
static int g_chaos_mode = PROTO_CHAOS_NONE;

int px_frag_write_sized(proto_session_t *s, int fd,
                        const uint8_t *buf, size_t n, size_t chunk_cap);

typedef struct { int mode; const char *name; } chaos_name_t;
static const chaos_name_t CHAOS_NAMES[] = {
    {PROTO_CHAOS_NONE,         "none"},
    {PROTO_CHAOS_CHAFFBURST,   "chaffburst"},
    {PROTO_CHAOS_CORRUPTREPLY, "corruptreply"},
    {PROTO_CHAOS_MINFRAG,      "minfrag"},
    {PROTO_CHAOS_ESCAPEDENSE,  "escapedense"},
    {PROTO_CHAOS_NOISE,        "noise"},
    {PROTO_CHAOS_RESYNC,       "resync"},
    {PROTO_CHAOS_DELAY,        "delay"},
    {PROTO_CHAOS_DRIP,         "drip"},
    {PROTO_CHAOS_ERRHELLO,     "errhello"},
    {PROTO_CHAOS_BADLEN,       "badlen"},
    {PROTO_CHAOS_DROP,         "drop"},
    {PROTO_CHAOS_DUPREPLY,     "dupreply"},
};

int proto_chaos_set(const char *name) {
    size_t i;
    if (name == NULL) { g_chaos_mode = PROTO_CHAOS_NONE; return 0; }
    for (i = 0; i < sizeof CHAOS_NAMES / sizeof CHAOS_NAMES[0]; i++)
        if (!strcmp(CHAOS_NAMES[i].name, name)) {
            g_chaos_mode = CHAOS_NAMES[i].mode;
            return 0;
        }
    return -1;
}

int proto_chaos_mode(void) { return g_chaos_mode; }

int proto_chaos_applicable(int mode) {
    switch (mode) {
    case PROTO_CHAOS_CHAFFBURST:  return PROTO_X_LEVEL >= 2;
    case PROTO_CHAOS_CORRUPTREPLY:
    case PROTO_CHAOS_NOISE:
    case PROTO_CHAOS_BADLEN:      return PROTO_F_LEVEL >= 3;
    case PROTO_CHAOS_MINFRAG:     return PROTO_X_LEVEL >= 3;
    case PROTO_CHAOS_ESCAPEDENSE: return PROTO_F_LEVEL == 5;
    case PROTO_CHAOS_RESYNC:      return PROTO_S_LEVEL >= 3;
    case PROTO_CHAOS_ERRHELLO:
    case PROTO_CHAOS_DROP:        return PROTO_S_LEVEL >= 1;
    default:                      return 1;   /* delay/drip/dupreply */
    }
}

const char *proto_chaos_name(int mode) {
    size_t i;
    for (i = 0; i < sizeof CHAOS_NAMES / sizeof CHAOS_NAMES[0]; i++)
        if (CHAOS_NAMES[i].mode == mode) return CHAOS_NAMES[i].name;
    return "?";
}

/* one-shot gate: fire exactly once per connection, at the FIRST
 * command reply of an authenticated session (works for any client's
 * command mix, not just the canonical SET/GET/SUM order)            */
static int chaos_once(proto_session_t *s, int bit) {
    if (!s->is_server) return 0;
    if ((s->chaos_once & bit) != 0) return 0;
    if (!s->authed || s->state != PST_SESSION) return 0;
    s->chaos_once |= bit;
    return 1;
}

/* escape-dense chaff: nothing but ESCAPE PAIRS between the flags --
 * maximum unescape workload with zero sentinel risk (a raw 0x7E in
 * the content would split the run and swallow a later real flag)   */
static int px_build_chaff_escape(proto_session_t *s, uint8_t *out,
                                 size_t cap) {
    size_t i, o = 1;
    (void)s;
    if (PROTO_F_LEVEL != 5) return 0;
    if (cap < 96) return 0;
    out[0] = PROTO_F5_FLAG;
    for (i = 0; i < 40 && o + 2 < cap - 1; i++) {
        out[o++] = PROTO_F5_ESC;
        out[o++] = PROTO_F5_FLAG ^ PROTO_F5_ESC_XOR;
        out[o++] = PROTO_F5_ESC;
        out[o++] = PROTO_F5_ESC ^ PROTO_F5_ESC_XOR;
    }
    out[o++] = PROTO_F5_FLAG;
    return (int)o;
}

/* hostile-length frame (the C11 contract): well-formed header whose
 * length field lies (0xFFFF) with only a few payload bytes behind it */
static int px_build_badlen(proto_session_t *s, uint8_t *out, size_t cap) {
    size_t o = 0;
    int i;
    if (cap < 32) return 0;
    if (PROTO_F_LEVEL == 5) {
        out[o++] = PROTO_F5_FLAG;
        /* inner: magic2 flags fragidx len16=0xFFFF opcode junk -- the
         * reader's hostile-length guard must reject and resync       */
        out[o++] = PROTO_MAGIC[0]; out[o++] = PROTO_MAGIC[1];
        out[o++] = 0x01; out[o++] = 0x00;
        if (PROTO_ENDIAN_LITTLE) { out[o++] = 0xFF; out[o++] = 0xFF; }
        else                     { out[o++] = 0xFF; out[o++] = 0xFF; }
        out[o++] = 0x10;
        for (i = 0; i < 8; i++) out[o++] = (uint8_t)prng_next(s);
        out[o++] = PROTO_F5_FLAG;
        return (int)o;
    }
    if (PROTO_F_LEVEL < 3) return 0;
    /* well-formed knob-shaped header whose length field lies (all
     * ones) with only a few payload bytes behind it                 */
    memcpy(out, PROTO_MAGIC, PROTO_F3_MAGIC_LEN);
    o = PROTO_F3_MAGIC_LEN;
    pf_put_u(out + o, PROTO_VERSION, PROTO_F3_VER_W); o += PROTO_F3_VER_W;
    out[o++] = 0x10;
    for (i = 0; i < PROTO_F3_LEN_W; i++) out[o++] = 0xFF;  /* lying len */
    for (i = 0; i < 8 && o < cap; i++) out[o++] = (uint8_t)prng_next(s);
    return (int)o;
}

/* serialize the reply exactly as the normal path would (X3 chunks or
 * raw) into buf; returns total length -- used by the drip mode       */
static size_t chaos_emit_buf(const uint8_t *wire, size_t n,
                             uint8_t *buf, size_t cap) {
    if (PROTO_X_LEVEL >= 3) {
        size_t off = 0, o = 0;
        do {
            size_t take = n - off;
            if (take > PROTO_X3_CHUNK) take = PROTO_X3_CHUNK;
            if (o + take + 2 > cap) return 0;
            buf[o++] = (uint8_t)(off + take >= n ? 0x80 : 0x00);
            buf[o++] = (uint8_t)take;
            memcpy(buf + o, wire + off, take); o += take;
            off += take;
        } while (off < n);
        return o;
    }
    if (n > cap) return 0;
    memcpy(buf, wire, n);
    return n;
}

/* the faulted server write path: pf_write_msg hands the BUILT frame
 * here when a chaos mode is active (server side only). Each mode
 * wraps the normal emission with its single fault.                  */
int px_chaos_wire(proto_session_t *s, int fd, const uint8_t *wire,
                  size_t n) {
    int mode = g_chaos_mode;
    uint8_t scratch[8192];

    /* normal emission: base X2 chaff, then X3 chunks or raw write    */
    #define CHAOS_EMIT() do { \
        if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1; \
        if (PROTO_X_LEVEL >= 3) \
            return px_frag_write_sized(s, fd, wire, n, PROTO_X3_CHUNK); \
        return px_write_all_raw(s, fd, wire, n); \
    } while (0)

    /* level-inapplicable probes are silent no-ops: emit normally (the
     * verifier never schedules them at these levels; the selftest
     * battery skips them; this keeps edge combinations clean)       */
    if (!proto_chaos_applicable(mode)) { CHAOS_EMIT(); }

    switch (mode) {
    case PROTO_CHAOS_CHAFFBURST: {
        int i;
        if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1;
        if (PROTO_X_LEVEL >= 3) {
            if (px_frag_write_sized(s, fd, wire, n, PROTO_X3_CHUNK))
                return -1;
        } else if (px_write_all_raw(s, fd, wire, n)) {
            return -1;
        }
        /* the burst: decoy traffic right on top of the real reply    */
        for (i = 0; i < 4; i++) {
            int c = px_build_chaff(s, scratch, sizeof scratch);
            if (c <= 0) continue;
            if (PROTO_X_LEVEL >= 3)
                px_frag_write_sized(s, fd, scratch, (size_t)c,
                                    PROTO_X3_CHUNK);
            else
                px_write_all_raw(s, fd, scratch, (size_t)c);
        }
        return 0;
    }
    case PROTO_CHAOS_ESCAPEDENSE: {
        int c;
        if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1;
        if (PROTO_X_LEVEL >= 3)
            px_frag_write_sized(s, fd, wire, n, PROTO_X3_CHUNK);
        else if (px_write_all_raw(s, fd, wire, n)) return -1;
        c = px_build_chaff_escape(s, scratch, sizeof scratch);
        if (c > 0) {
            if (PROTO_X_LEVEL >= 3)
                px_frag_write_sized(s, fd, scratch, (size_t)c,
                                    PROTO_X3_CHUNK);
            else
                px_write_all_raw(s, fd, scratch, (size_t)c);
        }
        return 0;
    }
    case PROTO_CHAOS_NOISE: {
        uint8_t junk[16];
        int i;
        for (i = 0; i < (int)sizeof junk; i++) {
            /* the |0x80 high bit kept junk clear of the historical
             * 0x7E/0x7D family; the seeded family can live at >=0x80,
             * so steer explicitly: junk must never eat a frame flag
             * or impersonate an escape byte                    */
            uint8_t b = (uint8_t)(prng_next(s) | 0x80);
            if (b == PROTO_F5_FLAG || b == PROTO_F5_ESC) b ^= 0x10;
            junk[i] = b;
        }
        if (PROTO_X_LEVEL >= 3) {
            px_frag_write_sized(s, fd, junk, sizeof junk, PROTO_X3_CHUNK);
        } else if (px_write_all_raw(s, fd, junk, sizeof junk)) {
            return -1;
        }
        CHAOS_EMIT();
        break;
    }
    case PROTO_CHAOS_CORRUPTREPLY: {
        uint8_t bad[8192];
        size_t bl;
        if (!chaos_once(s, PROTO_CHAOS_BIT_CORRUPT)) CHAOS_EMIT();
        memcpy(bad, wire, n);
        /* recoverable corruption: break the CHECKSUM region and a
         * mid-frame byte, never the framing delimiters -- the peer
         * must be able to drop this frame cleanly and resync on the
         * retransmission. Under the seeded F5 escape family a naive
         * XOR can MANUFACTURE a flag or escape byte and merge/split
         * frames (a stream wedge, not a checksum fault), so every
         * flipped byte is steered clear of the family.            */
        #define SAFE_FLIP(b) do { \
            uint8_t x_ = (b) ^ 0x5A; \
            if (x_ == PROTO_F5_FLAG || x_ == PROTO_F5_ESC) x_ = (b) ^ 0xA3; \
            if (x_ == PROTO_F5_FLAG || x_ == PROTO_F5_ESC) x_ = (b) ^ 0x3C; \
            (b) = x_; \
        } while (0)
        /* confine the corruption to the frame TAIL: the checksum
         * region and the auth tag behind it. The naive mid-frame
         * index (hdr + n/2) lands ON the length field once the X3
         * mimicry head widens the wire frame -- the reader then waits
         * for a phantom oversized frame, the buffer never drains, and
         * the retransmitted answers drift past the one-loss record
         * window (a session wedge, not a checksum fault). The last
         * bytes are always crc16/32 then tag across every F/C combo,
         * so n-2 and n-5 break integrity ONLY -- framing boundaries
         * and the length field stay intact, and the peer drops the
         * frame whole at its crc/tag checkpoint exactly as the C2
         * contract requires                                      */
        {   size_t hdr = (size_t)pf_f3_hdrlen();
            if (PROTO_F_LEVEL == 5) hdr += 2;      /* outer F5 flags */
            if (n > hdr + 8) {
                SAFE_FLIP(bad[n - 2]);             /* checksum byte   */
                SAFE_FLIP(bad[n - 5]);             /* auth-tag byte   */
            }
        }
        #undef SAFE_FLIP
        bl = chaos_emit_buf(bad, n, scratch, sizeof scratch);
        if (bl == 0) return -1;
        return px_write_all_raw(s, fd, scratch, bl);
    }
    case PROTO_CHAOS_MINFRAG: {
        if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1;
        if (PROTO_X_LEVEL >= 3)
            return px_frag_write_sized(s, fd, wire, n, 1);
        return px_write_all_raw(s, fd, wire, n);
    }
    case PROTO_CHAOS_DELAY: {
        if (chaos_once(s, PROTO_CHAOS_BIT_DELAY)) {
            struct timespec ts = {5, 0};
            nanosleep(&ts, NULL);        /* the patience test           */
        }
        CHAOS_EMIT();
        break;
    }
    case PROTO_CHAOS_DRIP: {
        size_t bl = chaos_emit_buf(wire, n, scratch, sizeof scratch);
        size_t i;
        struct timespec ts = {0, 10 * 1000 * 1000};   /* 10ms/byte     */
        if (bl == 0) return -1;
        for (i = 0; i < bl; i++) {
            if (px_write_all_raw(s, fd, scratch + i, 1)) return -1;
            nanosleep(&ts, NULL);
        }
        return 0;
    }
    case PROTO_CHAOS_BADLEN: {
        int bn;
        if (chaos_once(s, PROTO_CHAOS_BIT_BADLEN)) {
            bn = px_build_badlen(s, scratch, 64);
            if (bn > 0) {
                if (PROTO_X_LEVEL >= 3)
                    px_frag_write_sized(s, fd, scratch, (size_t)bn,
                                        PROTO_X3_CHUNK);
                else
                    px_write_all_raw(s, fd, scratch, (size_t)bn);
            }
        }
        CHAOS_EMIT();
        break;
    }
    case PROTO_CHAOS_DUPREPLY: {
        if (PROTO_X_LEVEL >= 2 && px_maybe_chaff(s, fd) < 0) return -1;
        if (PROTO_X_LEVEL >= 3) {
            if (px_frag_write_sized(s, fd, wire, n, PROTO_X3_CHUNK))
                return -1;
        } else if (px_write_all_raw(s, fd, wire, n)) {
            return -1;
        }
        if (chaos_once(s, PROTO_CHAOS_BIT_DUP)) {
            /* identical bytes twice: a tolerant reader absorbs the
             * duplicate (same record number) and moves on            */
            if (PROTO_X_LEVEL >= 3) {
                if (px_frag_write_sized(s, fd, wire, n, PROTO_X3_CHUNK))
                    return -1;
            } else if (px_write_all_raw(s, fd, wire, n)) {
                return -1;
            }
        }
        return 0;
    }
    default:
        /* semantic modes (errhello/resync/drop) act in the handlers;
         * the wire path itself stays normal                          */
        CHAOS_EMIT();
        break;
    }
    return 0;   /* unreachable                          */
    (void)fd; (void)wire; (void)n;
}

/* ------------------------------------------------------------------ */
/* X3: transport fragmentation                                         */
/* ------------------------------------------------------------------ */
/* Chunk format (self-describing, unambiguous):
 *     [flags u8][len u8][data len bytes]
 *   flags bit7 = LAST chunk of the frame; len <= PROTO_X3_CHUNK.
 * Frames never interleave, so reassembly is a simple run parser.   */
int px_frag_write(proto_session_t *s, int fd,
                  const uint8_t *buf, size_t n) {
    return px_frag_write_sized(s, fd, buf, n, PROTO_X3_CHUNK);
}

/* sized variant: chunk cap is a parameter (the C3 minfrag chaos mode
 * shrinks it to 1 byte -- reassembly correctness, not just parsing)  */
int px_frag_write_sized(proto_session_t *s, int fd,
                        const uint8_t *buf, size_t n, size_t chunk_cap) {
    size_t off = 0;
    (void)s;
    if (chunk_cap == 0) chunk_cap = 1;
    do {
        uint8_t chunk[PROTO_X3_CHUNK + 2];
        size_t take = n - off;
        if (take > chunk_cap) take = chunk_cap;
        if (take > PROTO_X3_CHUNK) take = PROTO_X3_CHUNK;
        chunk[0] = (uint8_t)(off + take >= n ? 0x80 : 0x00);
        chunk[1] = (uint8_t)take;
        memcpy(chunk + 2, buf + off, take);
        if (px_write_all_raw(s, fd, chunk, take + 2)) return -1;
        off += take;
    } while (off < n);
    return 0;
}

/* Accumulate raw stream bytes; when a full [flags len data]... run
 * ending in a LAST chunk is present, emit the reassembled frame into
 * chunk/chunk_len and consume the run. Returns 0 ok (complete may
 * still be 0), -1 on malformed/oversized input (accumulator reset). */
int px_defrag_feed(proto_reader_t *r, const uint8_t *data, size_t n,
                   int *complete, uint8_t *chunk, size_t *chunk_len) {
    *complete = 0;
    if (r->x3_len + n > sizeof r->x3) {
        r->x3_len = 0;                    /* overflow: drop and resync */
        if (n > sizeof r->x3) return -1;
    }
    if (n) memcpy(r->x3 + r->x3_len, data, n);
    r->x3_len += n;

    {
        size_t src = 0, dst = 0;
        int saw_last = 0;
        while (src + 2 <= r->x3_len) {
            uint8_t flags = r->x3[src];
            size_t len = r->x3[src + 1];
            if (len > PROTO_X3_CHUNK || src + 2 + len > r->x3_len)
                break;                    /* malformed or need bytes  */
            if (dst + len > 8192) { r->x3_len = 0; return -1; }
            memcpy(chunk + dst, r->x3 + src + 2, len);
            dst += len;
            src += 2 + len;
            if (flags & 0x80) { saw_last = 1; break; }
        }
        if (!saw_last) {
            /* stash partial parse state by keeping the bytes; the
             * caller waits for more data                            */
            return 0;
        }
        /* consume parsed bytes; keep the tail                        */
        memmove(r->x3, r->x3 + src, r->x3_len - src);
        r->x3_len -= src;
        *chunk_len = dst;
        *complete = 1;
        return 0;
    }
}

/* ------------------------------------------------------------------ */
/* X3: protocol mimicry (fake HTTP wrapper)                            */
/* ------------------------------------------------------------------ */
void px_wrap_mimicry(uint8_t *buf, size_t *n, size_t cap) {
    char head[128];
    char fmt[48];
    int hl;
    size_t need;
    px_strdec(fmt, PROTO_X3_HEAD_ENC, PROTO_X3_HEAD_LEN);
    hl = snprintf(head, sizeof head, fmt, PROTO_MIMIC_PATH, *n);
    need = (size_t)hl + *n;
    if (need > cap) {                     /* no room: truncate head */
        px_strdec(fmt, PROTO_X3_SHORT_ENC, PROTO_X3_SHORT_LEN);
        hl = snprintf(head, sizeof head, fmt, PROTO_MIMIC_PATH);
        need = (size_t)hl + *n;
        if (need > cap) return;
    }
    memmove(buf + hl, buf, *n);
    memcpy(buf, head, (size_t)hl);
    *n = need;
}

int px_unwrap_mimicry(uint8_t *buf, size_t *n) {
    /* Strip the fake HTTP header -- but only a COMPLETE one: the
     * boundary must be "POST <seeded path> HTTP/1.1 ... \r\n\r\n",
     * because the binary frame that follows may itself contain the
     * \r\n\r\n sequence (it is escaped only against 0x7E/0x7D).   */
    static const char marker[4] = {'\r', '\n', '\r', '\n'};
    char post[8];
    char httpver[16];
    size_t i;
    px_strdec(post, PROTO_X3_POST_ENC, PROTO_X3_POST_LEN);
    px_strdec(httpver, PROTO_X3_HTTPVER_ENC, PROTO_X3_HTTPVER_LEN);
    if (*n < 4) return 0;
    for (i = 0; i + 4 <= *n; i++) {
        if (memcmp(buf + i, marker, 4)) continue;
        /* candidate boundary at i: does the head look like ours? The
         * verb literal is variable-length ("PUT"/"POST"/...), so the
         * prefix check spans exactly its own bytes                */
        if (i < 5 || memcmp(buf, post, strlen(post))) break;
        {
            char head[128];
            size_t hl = i < sizeof head - 1 ? i : sizeof head - 1;
            memcpy(head, buf, hl);
            head[hl] = 0;
            if (strstr(head, PROTO_MIMIC_PATH) == NULL ||
                strstr(head, httpver) == NULL)
                break;                     /* stray sequence: stop    */
        }
        memmove(buf, buf + i + 4, *n - i - 4);
        *n -= i + 4;
        return 0;
    }
    /* No complete header. Two cases: a partial real header (starts
     * with "POST " -- wait for the rest), or UNWRAPPED content such
     * as an X2 chaff frame -- pass it through; the framing layer's
     * crc/magic checkpoints drop it as designed.                  */
    return 0;
}
