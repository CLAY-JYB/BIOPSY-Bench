/* selftest_main.c -- generated-protocol self-test + GT spec dump.
 *
 * Built and run by gen_protocol.py BEFORE injection (SKILL.md Step 3
 * gate). Modes:
 *   (default)   loopback session tests + crypto vectors; prints
 *               "SELFTEST failures: N" (exit code = N)
 *   --dump-spec print the JSON fragment (messages + field spans +
 *               example bytes) gen_protocol.py folds into meta.json
 */

#define _GNU_SOURCE
#include "proto_config.h"
#include "proto_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <signal.h>

static int g_failures = 0;

#define CHECK(cond, name) do { \
    if (cond) printf("  ok   %s\n", name); \
    else { printf("  FAIL %s\n", name); g_failures++; } \
} while (0)

/* ------------------------------------------------------------------ */
/* ephemeral-port server process                                       */
/* ------------------------------------------------------------------ */
/* The server runs in a FORKED CHILD, not a pthread: the schema registry
 * decodes one schema at a time into shared scratch (proto_state.c), a
 * per-process buffer -- two threads driving server+client in one
 * process would race on it. Separate processes also mirror how the
 * oracle and the analyzed client actually run.                       */
static int g_lfd = -1;
static pid_t g_srv_pid = -1;

static int start_server_mode(uint16_t *port_out, const char *chaos) {
    struct sockaddr_in a;
    socklen_t alen = sizeof a;
    g_lfd = PROTO_T_LEVEL == 1 ? pc_udp_listen(0)
        : PROTO_T_LEVEL == 3 ? pc_unix_listen(PROTO_UNIX_PATH)
        : pc_full_tcp_listen(0);
    if (g_lfd < 0) return -1;
    if (PROTO_T_LEVEL != 3) {
        if (getsockname(g_lfd, (struct sockaddr *)&a, &alen) < 0)
            return -1;
        *port_out = ntohs(a.sin_port);
    } else {
        *port_out = 1;              /* placeholder: path transport   */
    }
    fflush(stdout);
    g_srv_pid = fork();
    if (g_srv_pid < 0) return -1;
    if (g_srv_pid == 0) {
        if (chaos != NULL && proto_chaos_set(chaos) != 0) _exit(2);
        if (PROTO_T_LEVEL == 1)
            _exit(proto_serve_udp(g_lfd));
        for (;;) {
            int cfd = accept(g_lfd, NULL, NULL);
            if (cfd < 0) _exit(0);
            if (PROTO_T_LEVEL == 4
                && pc_ws_server_handshake(cfd) != 0) {
                close(cfd);
                continue;
            }
            proto_serve_connection(cfd);
        }
    }
    return 0;
}

/* T seam dialer for the two direct-socket tests below (the sessions
 * themselves go through proto_client_* in the client engine)        */
static int st_connect(uint16_t port) {
    if (PROTO_T_LEVEL == 3) return pc_unix_connect(PROTO_UNIX_PATH);
    if (PROTO_T_LEVEL == 4) return pc_ws_connect("127.0.0.1", (int)port);
    return PROTO_T_LEVEL == 1 ? pc_udp_connect("127.0.0.1", port)
                              : pc_full_tcp_connect("127.0.0.1", port);
}

static int start_server(uint16_t *port_out) {
    return start_server_mode(port_out, NULL);
}

static void stop_server(void) {
    if (g_srv_pid > 0) {
        kill(g_srv_pid, SIGKILL);
        waitpid(g_srv_pid, NULL, 0);
        g_srv_pid = -1;
    }
    if (g_lfd >= 0) {
        close(g_lfd);
        g_lfd = -1;
    }
}

/* ------------------------------------------------------------------ */
/* chaos battery: the robustness contract, gate-style. The reference
 * client implements every disclosed fault rule, so it must survive
 * each single-fault oracle (full session + flag). A failure here is
 * a contract regression -- in the client OR the fault injector.   */
/* ------------------------------------------------------------------ */
static int vec_chaos(void) {
    static const char *modes[] = {
        "chaffburst", "corruptreply", "minfrag", "escapedense",
        "noise", "resync", "delay", "drip", "errhello", "badlen",
        "drop", "dupreply",
    };
    size_t k;
    int fails_before;
    for (k = 0; k < sizeof modes / sizeof modes[0]; k++) {
        if (!proto_chaos_applicable(proto_chaos_set(modes[k]) == 0
                                    ? proto_chaos_mode()
                                    : PROTO_CHAOS_NONE)) {
            printf("  skip chaos %s (level-inapplicable)\n", modes[k]);
            proto_chaos_set(NULL);
            continue;
        }
        proto_chaos_set(NULL);   /* restore; the fork below re-sets it */
        uint16_t port = 0;
        char flag[PROTO_STR_MAX];
        char pref[PROTO_STR_MAX];
        int rc;
        size_t L;
        fails_before = g_failures;
        proto_session_flag_decode(pref, sizeof pref);
        if (start_server_mode(&port, modes[k])) {
            printf("  FAIL chaos %s: listen\n", modes[k]);
            g_failures++;
            continue;
        }
        rc = proto_client_session("127.0.0.1", (int)port, flag,
                                  sizeof flag);
        L = strlen(flag);
        CHECK(rc == 0 && L == 29 && !memcmp(flag, pref, 8)
              && flag[28] == '}',
              "chaos survival (full session + flag)");
        if (g_failures != fails_before)
            printf("        ^ faulted mode: %s\n", modes[k]);
        stop_server();
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* crypto vectors -- construction-level properties of the private
 * family (no public vectors exist by design)                          */
/* ------------------------------------------------------------------ */

static int vec_crypto(void) {
    uint8_t d[32];

    /* ---- private primitive family gates (2026-10-04): no public
     * vectors exist by design, so construction-level properties are
     * the gate -- determinism, avalanche, key sensitivity, roundtrip,
     * DH agreement, and stream distinctness across ctr/key       ---- */

    /* PRV_HASH determinism + avalanche */
    {
        uint8_t a[32], b[32], in[64];
        int i, flip, diff;
        for (i = 0; i < 64; i++) in[i] = (uint8_t)(i * 11 + 3);
        pc_prv_hash((const uint8_t *)"seed-A", 6, in, 64, a);
        pc_prv_hash((const uint8_t *)"seed-A", 6, in, 64, b);
        CHECK(!memcmp(a, b, 32), "prv_hash deterministic");
        in[33] ^= 0x01;
        pc_prv_hash((const uint8_t *)"seed-A", 6, in, 64, b);
        diff = 0;
        for (i = 0; i < 32; i++) {
            unsigned x = a[i] ^ b[i];
            while (x) { diff += x & 1; x >>= 1; }
        }
        CHECK(diff >= 32, "prv_hash avalanche (>=32/256 bits flip)");
        pc_prv_hash((const uint8_t *)"seed-B", 6, in, 64, b);
        CHECK(memcmp(a, b, 32) != 0, "prv_hash key sensitivity");
        (void)flip;
    }

    /* PRV_STREAM roundtrip + counter/key distinctness */
    {
        uint8_t buf[128], save[128], k1[32], k2[32], iv[8];
        int i;
        for (i = 0; i < 32; i++) { k1[i] = (uint8_t)(i); k2[i] = (uint8_t)(i + 1); }
        for (i = 0; i < 8; i++) iv[i] = (uint8_t)(0x40 + i);
        for (i = 0; i < 128; i++) buf[i] = (uint8_t)(i * 7 + 1);
        memcpy(save, buf, 128);
        pc_prv_stream(k1, iv, 0, buf, 128);
        CHECK(memcmp(buf, save, 128) != 0, "prv_stream changes data");
        pc_prv_stream(k1, iv, 0, buf, 128);
        CHECK(!memcmp(buf, save, 128), "prv_stream roundtrip (involution)");
        pc_prv_stream(k1, iv, 0, buf, 128);
        pc_prv_stream(k1, iv, 1, buf, 128);   /* decrypt with wrong ctr */
        CHECK(memcmp(buf, save, 128) != 0, "prv_stream counter sensitivity");
        pc_prv_stream(k1, iv, 0, buf, 128);
        pc_prv_stream(k2, iv, 0, buf, 128);   /* decrypt with wrong key */
        CHECK(memcmp(buf, save, 128) != 0, "prv_stream key sensitivity");
    }

    /* PRV_KDF: distinct labels diverge, same label agrees */
    {
        uint8_t a[32], b[32];
        pc_prv_kdf((const uint8_t *)"salt", 4, (const uint8_t *)"ikm", 3,
                   "label-one", a);
        pc_prv_kdf((const uint8_t *)"salt", 4, (const uint8_t *)"ikm", 3,
                   "label-one", b);
        CHECK(!memcmp(a, b, 32), "prv_kdf deterministic");
        pc_prv_kdf((const uint8_t *)"salt", 4, (const uint8_t *)"ikm", 3,
                   "label-two", b);
        CHECK(memcmp(a, b, 32) != 0, "prv_kdf label separation");
    }

    /* PRV DH: agreement both directions, pub depends on priv */
    {
        uint8_t alicep[32], bobp[32], sh1[32], sh2[32];
        uint8_t apriv[32], bpriv[32];
        int i;
        for (i = 0; i < 32; i++) { apriv[i] = (uint8_t)(0x30 + i); bpriv[i] = (uint8_t)(0x60 + i * 3); }
        apriv[0] &= 0x0F; bpriv[0] &= 0x0F;      /* 128-bit exponents   */
        pc_prv_pub(alicep, apriv, 32);
        pc_prv_pub(bobp, bpriv, 32);
        CHECK(memcmp(alicep, bobp, 32) != 0, "prv_dh pubs differ");
        pc_prv_shared(sh1, apriv, 32, bobp);
        pc_prv_shared(sh2, bpriv, 32, alicep);
        CHECK(!memcmp(sh1, sh2, 32), "prv_dh shared agreement");
    }

    /* PRV-CBC roundtrip + tamper rejection (private Feistel: no
     * public vectors exist -- construction-level check)             */
    {
        /* NOTE: XTEA-CBC encryption GROWS the body by up to one block
         * (PKCS#7) -- the working buffer carries that headroom      */
        uint8_t key[16], iv[8], buf[80], save[80];
        size_t i, n2, n3;
        for (i = 0; i < 16; i++) key[i] = (uint8_t)(0x10 + i);
        for (i = 0; i < 8; i++) iv[i] = (uint8_t)(0x20 + i);
        for (i = 0; i < 64; i++) buf[i] = (uint8_t)(i * 5 + 1);
        uint8_t orig[64];
        memcpy(orig, buf, 64);
        n2 = pc_prv_cbc(key, iv, 32, 1, buf, 64);
        CHECK(n2 != (size_t)-1 && n2 > 64, "prv-cbc encrypt grows");
        memcpy(save, buf, n2);
        save[n2 - 3] ^= 0x40;          /* corrupt the LAST block: the
                                        * whole plaintext block turns
                                        * to garbage                */
        n3 = pc_prv_cbc(key, iv, 32, 0, save, n2);
        {   /* CBC is not an authenticating mode: a garbage block
             * whose final bytes happen to parse as a valid pad can
             * slip the length check (the wire integrity gate is the
             * keyed tag pf_crypt adds over the ciphertext). The
             * deterministic property tested here: tampering is
             * either rejected outright or NEVER silently yields
             * the original plaintext                     */
            int caught = n3 == (size_t)-1;
            if (!caught)
                caught = !(n3 == 64 && !memcmp(save, orig, 64));
            CHECK(caught, "prv-cbc never accepts tampered plaintext");
        }
        memcpy(save, buf, n2);          /* fresh copy for the roundtrip */
        n3 = pc_prv_cbc(key, iv, 32, 0, save, n2);
        CHECK(n3 == 64, "prv-cbc roundtrip");
        { int eq = 1;
          for (i = 0; i < 64; i++) if (save[i] != (uint8_t)(i * 5 + 1))
              eq = 0;
          CHECK(eq, "prv-cbc roundtrip bytes"); }
    }

    /* proof verify rejects wrong sequence (X1) */
    {
        proto_session_t s;
        uint8_t proof[16];
        px_session_init(&s, 1);
        px_proof(&s, 7, (const uint8_t *)"body", 4, proof);
        CHECK(px_verify(&s, 7, (const uint8_t *)"body", 4, proof) == 0,
              "proof accepts correct seq");
        CHECK(px_verify(&s, 8, (const uint8_t *)"body", 4, proof) != 0,
              "proof rejects wrong seq");
    }
    (void)d;
    return 0;
}


/* ------------------------------------------------------------------ */
/* session tests                                                       */
/* ------------------------------------------------------------------ */
static int vec_session(void) {
    uint16_t port = 0;
    char flag[PROTO_STR_MAX];
    int rc, i;

    if (start_server(&port)) {
        printf("  FAIL listen\n");
        g_failures++;
        return -1;
    }

    /* full session retrieves the session flag: per-connection derived
     * (prefix from the static material + HMAC(nonce) body), so the
     * check is prefix + shape + ACROSS-RUN DISTINCTNESS -- a constant
     * flag would mean the derivation is not riding the nonce       */
    {
        char first[PROTO_STR_MAX];
        int distinct = 0;
        memset(first, 0, sizeof first);
        for (i = 0; i < 3; i++) {           /* repeat: chaff paths vary */
            char pref[PROTO_STR_MAX];
            size_t L;
            proto_session_flag_decode(pref, sizeof pref);
            memset(flag, 0, sizeof flag);
            rc = proto_client_session("127.0.0.1", (int)port, flag,
                                      sizeof flag);
            L = strlen(flag);
            CHECK(rc == 0 && L == 29 && !memcmp(flag, pref, 8)
                  && flag[28] == '}',
                  "session flag roundtrip (prefix + shape)");
            if (rc != 0) break;
            if (i == 0) snprintf(first, sizeof first, "%s", flag);
            else if (strcmp(first, flag) != 0) distinct = 1;
        }
        CHECK(distinct, "per-connection flag derivation");
    }

    /* conversation mode counts completed round trips */
    rc = proto_client_converse("127.0.0.1", (int)port, 5);
    CHECK(rc == 5, "converse 5 rounds");

    /* S3 retransmission tolerance: replaying the exact wire bytes of
     * an accepted message must be re-answered, not dropped (the GT
     * state machine declares duplicate_sequence -> retransmit)      */
    if (PROTO_S_LEVEL >= 3 && PROTO_X_LEVEL == 0) {
        int fd = st_connect(port);
        if (fd >= 0) {
            proto_session_t s;
            proto_reader_t rd;
            proto_msg_t m, r;
            uint8_t wire[8192];
            int n, got = 0, tries;
            px_session_init(&s, 0);
            memset(&rd, 0, sizeof rd);
            s.state = PST_WAIT_HELLO;
            memset(&m, 0, sizeof m);
            m.opcode = OP_HELLO;
            m.ints[0] = PROTO_VERSION;
            m.ints[1] = 3;
            n = pf_build(&s, &m, wire, sizeof wire);
            if (n > 0) {
                s.my_seq++;
                /* write the SAME frame twice (a retransmission)     */
                if (write(fd, wire, (size_t)n) == n &&
                    write(fd, wire, (size_t)n) == n) {
                    for (tries = 0; tries < 8 && got < 2; tries++) {
                        uint8_t buf[4096];
                        ssize_t rn = read(fd, buf, sizeof buf);
                        if (rn <= 0) break;
                        if (pf_reader_feed(&s, &rd, buf, (size_t)rn,
                                           &r) == 1)
                            got++;
                        /* replies may coalesce into one read: drain
                         * everything already buffered before blocking
                         * on the next read (else deadlock)           */
                        while (got < 2 &&
                               pf_reader_feed(&s, &rd, NULL, 0,
                                              &r) == 1)
                            got++;
                    }
                }
            }
            CHECK(got == 2, "S3 duplicate HELLO re-answered");
            close(fd);
        }
    }

    /* wrong-version HELLO is rejected (S>=1) */
    if (PROTO_S_LEVEL >= 1) {
        int fd = st_connect(port);
        proto_session_t s;
        proto_reader_t rd;
        proto_msg_t m, r;
        if (fd >= 0) {
            px_session_init(&s, 0);
            memset(&rd, 0, sizeof rd);
            memset(&m, 0, sizeof m);
            m.opcode = OP_HELLO;
            m.ints[0] = PROTO_VERSION ^ 0xFFFF0000u;   /* bad version */
            m.ints[1] = 3;
            if (pf_write_msg(&s, fd, &m) == 0) {
                /* cli-style read of the reply */
                int got = -1, tries;
                for (tries = 0; tries < 8 && got < 0; tries++) {
                    uint8_t buf[4096];
                    ssize_t n = read(fd, buf, sizeof buf);
                    if (n <= 0) break;
                    if (pf_reader_feed(&s, &rd, buf, (size_t)n, &r) == 1)
                        got = r.opcode;
                    while (got < 0 &&
                           pf_reader_feed(&s, &rd, NULL, 0, &r) == 1)
                        got = r.opcode;
                }
                CHECK(got == OP_ERR, "bad version -> ERR");
            }
            close(fd);
        }
    }
    stop_server();
    return 0;
}

/* ------------------------------------------------------------------ */
/* GT spec dump                                                        */
/* ------------------------------------------------------------------ */
static const char *ft_name(int ft) {
    switch (ft) {
    case PFT_U8: return "u8";
    case PFT_U16: return "u16";
    case PFT_U32: return "u32";
    case PFT_U64: return "u64";
    case PFT_VARINT: return "varint";
    case PFT_STR: return "str";
    case PFT_BSTR: return "bstr";
    default: return "bits";
    }
}

static void dump_spec(void) {
    int i;
    printf("{\n  \"messages\": [\n");
    for (i = 0;; i++) {
        const proto_schema_t *sch = ps_schema_by_index(i);
        uint8_t ex[PROTO_FRAME_MAX];
        int spans[PROTO_MAX_FIELDS][2];
        int n, k;
        if (!sch) break;
        n = pe_example(sch, ex, sizeof ex, spans);
        printf("    {\"name\": \"%s\", \"opcode\": \"0x%02x\", "
               "\"dir\": \"%s\", \"fields\": [",
               sch->name, (unsigned)sch->opcode,
               sch->dir == PDIR_C2S ? "c2s" : "s2c");
        for (k = 0; k < sch->nfields; k++) {
            const proto_field_t *f = &sch->fields[k];
            printf("%s\n      {\"name\": \"%s\", \"type\": \"%s\", "
                   "\"width\": %d, \"sem\": \"%s\", "
                   "\"span\": [%d, %d], \"endian\": %s, \"bits\": %d}",
                   k ? "," : "",
                   f->name, ft_name(f->ftype), f->width,
                   f->sem == PSEM_VERSION ? "version"
                   : f->sem == PSEM_LENGTH ? "length"
                   : f->sem == PSEM_SEQ ? "seq"
                   : f->sem == PSEM_NONCE ? "nonce"
                   : f->sem == PSEM_CHECKSUM ? "checksum"
                   : f->sem == PSEM_KEY ? "key"
                   : f->sem == PSEM_VALUE ? "value"
                   : f->sem == PSEM_NAME ? "name"
                   : f->sem == PSEM_STATUS ? "status"
                   : f->sem == PSEM_TOKEN ? "token"
                   : f->sem == PSEM_FLAG ? "flag"
                   : f->sem == PSEM_REASON ? "reason"
                   : f->sem == PSEM_TYPE ? "type" : "none",
                   spans[k][0], spans[k][1],
                   f->endian ? "\"little\"" : "\"big\"", f->bits);
        }
        printf("],\n     \"example_payload_hex\": \"");
        for (k = 0; k < n; k++) printf("%02x", ex[k]);
        printf("\"}%s\n", ps_schema_by_index(i + 1) ? "," : "");
    }
    printf("  ]\n}\n");
}

/* ------------------------------------------------------------------ */
/* codec round-trip: encode -> decode must reproduce every schema's
 * example message exactly (guards all E levels against asymmetry)  */
/* ------------------------------------------------------------------ */
static int vec_roundtrip(void) {
    int i;
    for (i = 0;; i++) {
        const proto_schema_t *sch = ps_schema_by_index(i);
        proto_msg_t a, b;
        uint8_t wire[PROTO_FRAME_MAX];
        int spans[PROTO_MAX_FIELDS][2];
        int n, k;
        if (!sch) break;
        memset(&a, 0, sizeof a);
        a.opcode = sch->opcode;
        for (k = 0; k < sch->nfields; k++) {
            const proto_field_t *f = &sch->fields[k];
            if (f->ftype == PFT_STR) snprintf(a.strs[k], PROTO_STR_MAX,
                                              "ex%d", k);
            else if (f->ftype == PFT_BSTR) memset(a.blobs[k],
                                                  (uint8_t)(0xA0 + k),
                                                  f->width);
            else a.ints[k] = (f->ftype == PFT_U8)
                ? (uint64_t)(0x40 + k) : (uint64_t)(0x1000 + k);
        }
        n = pe_encode(sch, &a, wire, sizeof wire, spans);
        if (n < 0 || pe_decode(sch, wire, (size_t)n, &b)) {
            printf("  FAIL roundtrip %s (encode %d)\n", sch->name, n);
            g_failures++;
            continue;
        }
        {
            int bad = 0;
            for (k = 0; k < sch->nfields; k++) {
                const proto_field_t *f = &sch->fields[k];
                if (f->ftype == PFT_STR)
                    bad |= strcmp(a.strs[k], b.strs[k]) != 0;
                else if (f->ftype == PFT_BSTR)
                    bad |= memcmp(a.blobs[k], b.blobs[k], f->width) != 0;
                else
                    bad |= a.ints[k] != b.ints[k];
            }
            if (bad) {
                printf("  FAIL roundtrip %s (value mismatch)\n", sch->name);
                g_failures++;
            }
        }
    }
    printf("  ok   codec roundtrip (all schemas)\n");
    return 0;
}

/* ------------------------------------------------------------------ */
/* compression round-trip (M axis): three payload shapes -- long runs */
/* (RLE's specialty), repetitive text (LZSS/DEFLATE matches), and     */
/* incompressible-looking bytes (raw-passthrough guard)               */
/* ------------------------------------------------------------------ */
static int vec_compress(void) {
    if (PROTO_M_LEVEL == 0) {
        printf("  skip compression (M0)\n");
        return 0;
    }
    uint8_t in[600], comp[2048], back[2048];
    size_t i, cases = 0;
    /* case 1: runs */
    for (i = 0; i < sizeof in; i++)
        in[i] = (uint8_t)((i / 40) & 0xFF);
    /* case 2: repetitive text */
    { size_t k = 0;
      const char *txt = "the quick brown fox jumps over the lazy dog ";
      for (i = 0; i < 400; i++) {
          in[i] = (uint8_t)txt[k++];
          if (!txt[k]) k = 0;
      } }
    /* case 3: pseudo-random (xorshift, deterministic) */
    { uint32_t xs = 0x12345678;
      for (i = 0; i < sizeof in; i++) {
          xs ^= xs << 13; xs ^= xs >> 17; xs ^= xs << 5;
          in[i] = (uint8_t)(xs >> 24);
      } }
    for (cases = 0; cases < 3; cases++) {
        size_t n = cases == 2 ? 300 : (cases == 1 ? 400 : sizeof in);
        size_t cl, bl;
        /* rotate the input per case so the shapes are distinct */
        if (cases) {
            for (i = 0; i < n; i++)
                in[i] = (uint8_t)(in[i] + cases * 37);
        }
        cl = pm_compress(in, n, comp, sizeof comp);
        if (cl == (size_t)-1) {
            printf("  FAIL compress case %d (overflow)\n", (int)cases);
            g_failures++;
            continue;
        }
        bl = pm_decompress(comp, cl, back, sizeof back);
        if (bl != n || memcmp(in, back, n)) {
            printf("  FAIL compress roundtrip case %d (%zu -> %zu -> %zu)"
                   "\n", (int)cases, n, cl, bl);
            g_failures++;
        }
    }
    printf("  ok   compression roundtrip (all payload shapes)\n");
    return 0;
}

int main(int argc, char **argv) {
    /* faulted-server runs write into dropped sockets constantly */
    signal(SIGPIPE, SIG_IGN);
    if (argc > 1 && !strcmp(argv[1], "--dump-spec")) {
        dump_spec();
        return 0;
    }
    vec_crypto();
    vec_compress();
    vec_roundtrip();
    vec_session();
    vec_chaos();
    printf("SELFTEST failures: %d\n", g_failures);
    return g_failures;
}
