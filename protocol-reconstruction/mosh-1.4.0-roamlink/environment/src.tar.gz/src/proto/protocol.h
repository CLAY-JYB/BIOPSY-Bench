/* protocol.h -- public API of the generated custom protocol engine.
 *
 * Static asset: the level-dependent behavior is driven entirely by the
 * generated proto_config.h (see gen_protocol.py). This file never varies
 * per task, so the injection surface (one #include + one call) is uniform
 * across all level combinations.
 *
 * Integration (SKILL.md Step 4):
 *   #include "protocol.h"        at the carrier's I/O entry source
 *   proto_server_entry(argc, argv, "applet-name")
 *        -- a hidden --proto-server PORT mode attached to a genuine
 *           I/O path of the carrier program.
 */

#ifndef BENCH_PROTO_H
#define BENCH_PROTO_H

#include <stddef.h>
#include <stdint.h>

/* Engine-internal linkage: every engine symbol is compiled hidden so a
 * carrier linked with -rdynamic / a module loader (smbd, asterisk, ...)
 * never carries px_/pf_/pc_/ps_/proto_* names into .dynsym. Hidden
 * visibility keeps the symbols resolvable inside the one executable the
 * carrier links (static-link scope), just not exported. The challenge
 * Dockerfiles additionally compile the engine TU with -fvisibility=hidden
 * (covers toolchains that strip attributes) and assert the final binary
 * exports none of them. */
#if defined(__GNUC__) && !defined(PROTO_API)
#define PROTO_API __attribute__((visibility("hidden")))
#endif
#ifndef PROTO_API
#define PROTO_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ */
/* limits (shared with proto_config.h)                                 */
/* ------------------------------------------------------------------ */
#define PROTO_FRAME_MAX   4096
#define PROTO_STR_MAX     64
#define PROTO_MAX_FIELDS  8

/* ------------------------------------------------------------------ */
/* message model                                                       */
/* ------------------------------------------------------------------ */
/* field types (encoding axis decides the wire form) */
enum {
    PFT_U8 = 0,   /* fixed 1-byte int      */
    PFT_U16,      /* fixed 2-byte int      */
    PFT_U32,      /* fixed 4-byte int      */
    PFT_U64,      /* fixed 8-byte int      */
    PFT_VARINT,   /* LEB128 varint  (E>=3) */
    PFT_STR,      /* string                */
    PFT_BSTR,     /* byte string, len-prefixed (fixed width in schema) */
    PFT_BITS      /* sub-byte bitfield (E>=5, schema .bits = width)     */
};

/* field semantics (drives Spec Accuracy ground truth) */
enum {
    PSEM_NONE = 0,
    PSEM_VERSION,
    PSEM_LENGTH,
    PSEM_TYPE,
    PSEM_SEQ,
    PSEM_NONCE,
    PSEM_CHECKSUM,
    PSEM_KEY,
    PSEM_VALUE,
    PSEM_NAME,
    PSEM_STATUS,
    PSEM_TOKEN,
    PSEM_FLAG,
    PSEM_REASON
};

typedef struct {
    const char *name;
    int         ftype;
    int         width;   /* bytes (PFT_STR: padded width; PFT_BSTR: fixed
                          * length; PFT_BITS: BIT width) */
    int         sem;     /* PSEM_*                                */
    int         endian;  /* 0 = big, 1 = little (E2 mixes these)  */
    int         bits;    /* PFT_BITS only: bit count (1..8)       */
} proto_field_t;

enum { PDIR_C2S = 1, PDIR_S2C = 2 };

typedef struct {
    int                opcode;
    const char        *name;
    int                dir;      /* PDIR_*                          */
    const proto_field_t *fields;
    int                nfields;
} proto_schema_t;

/* a decoded/encodable message: schema-indexed value slots */
typedef struct {
    int      opcode;                              /* OP_* from config    */
    int      chan;      /* L>=1: channel id the frame rode (0 at L0)    */
    int      chan_seq;  /* L>=1: per-channel sequence byte              */
    uint64_t ints[PROTO_MAX_FIELDS];              /* non-string slots    */
    char     strs[PROTO_MAX_FIELDS][PROTO_STR_MAX];
    uint8_t  blobs[PROTO_MAX_FIELDS][PROTO_STR_MAX];
} proto_msg_t;

/* ------------------------------------------------------------------ */
/* engine API                                                          */
/* ------------------------------------------------------------------ */

/* Serve the protocol on loopback until the connection closes. Used by
 * the injected --proto-server mode and by the verifier oracle.
 * Returns 0 on clean session end, non-zero on transport error. */
PROTO_API int proto_serve_connection(int fd);

/* Reference client: performs the full session the state machine allows
 * (handshake -> [params ->] auth -> N round trips -> FLAG -> BYE) and
 * fills `flag_out` with the session flag on success.
 * Returns 0 on success (flag retrieved), non-zero otherwise.
 *
 * LINKAGE: the client engine lives in proto_client.c, a SEPARATE
 * translation unit that only the solve-side builds link (oracle pair,
 * selftest). protocol.c (the carrier-linked amalgamation) carries the
 * server path only -- a challenge binary contains no client code to
 * MITM or reuse (leak-audit fix: reference client stays out of the
 * analyzed image). */
PROTO_API int proto_client_session(const char *host, int port,
                                   char *flag_out, size_t flag_cap);

/* Reference client, conversation mode: perform `rounds` GET/SET/SUM
 * exchanges after auth (used by the scoring ladder). Returns the number
 * of successful round trips, or -1 on transport failure. */
PROTO_API int proto_client_converse(const char *host, int port, int rounds);

/* Hidden carrier entry: intercepts "--proto-server PORT" and serves the
 * protocol on 127.0.0.1:PORT. Returns 1 if it handled the invocation
 * (caller must exit with its exit code), 0 if argv is not a proto
 * invocation (caller continues normally). `applet` names the genuine
 * I/O path the engine is attached to (diagnostics only). */
PROTO_API int proto_server_entry(int argc, char **argv, const char *applet);

/* decode the obfuscated session flag into out (NUL-terminated); the
 * flag never exists as a plaintext string in the binary */
PROTO_API void proto_session_flag_decode(char *out, size_t cap);

#ifdef __cplusplus
}
#endif

#endif /* BENCH_PROTO_H */
