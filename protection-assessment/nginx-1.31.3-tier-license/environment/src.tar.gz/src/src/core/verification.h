#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void stage_probe_1(void);
void stage_probe_2(void);
void stage_probe_3(void);

int validate_input(const char* input);

#ifdef __cplusplus
}
#endif