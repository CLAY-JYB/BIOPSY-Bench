
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/* the emitted entry points are declared in verification.h; include it so
   -Werror=missing-prototypes carrier builds (ffmpeg) see a prior
   prototype for validate_input */
#include "verification.h"

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif

#define ROTL32(x,n) (((x) << (n)) | ((x) >> (32 - (n))))
#define ROTR32(x,n) (((x) >> (n)) | ((x) << (32 - (n))))
// Helper macros for big-endian operations
#define READ_BE32(p) (((uint32_t)(p)[0]<<24)|((uint32_t)(p)[1]<<16)|((uint32_t)(p)[2]<<8)|(uint32_t)(p)[3])

// ============ Checksum Functions ============
// CRC32 (standard implementation)
static uint32_t crc32(const uint8_t* data,int len){
    static const uint32_t table[256]={
        0x00000000,0x77073096,0xEE0E612C,0x990951BA,0x076DC419,0x706AF48F,0xE963A535,0x9E6495A3,
        0x0EDB8832,0x79DCB8A4,0xE0D5E91E,0x97D2D988,0x09B64C2B,0x7EB17CBD,0xE7B82D07,0x90BF1D91,
        0x1DB71064,0x6AB020F2,0xF3B97148,0x84BE41DE,0x1ADAD47D,0x6DDDE4EB,0xF4D4B551,0x83D385C7,
        0x136C9856,0x646BA8C0,0xFD62F97A,0x8A65C9EC,0x14015C4F,0x63066CD9,0xFA0F3D63,0x8D080DF5,
        0x3B6E20C8,0x4C69105E,0xD56041E4,0xA2677172,0x3C03E4D1,0x4B04D447,0xD20D85FD,0xA50AB56B,
        0x35B5A8FA,0x42B2986C,0xDBBBC9D6,0xACBCF940,0x32D86CE3,0x45DF5C75,0xDCD60DCF,0xABD13D59,
        0x26D930AC,0x51DE003A,0xC8D75180,0xBFD06116,0x21B4F4B5,0x56B3C423,0xCFBA9599,0xB8BDA50F,
        0x2802B89E,0x5F058808,0xC60CD9B2,0xB10BE924,0x2F6F7C87,0x58684C11,0xC1611DAB,0xB6662D3D,
        0x76DC4190,0x01DB7106,0x98D220BC,0xEFD5102A,0x71B18589,0x06B6B51F,0x9FBFE4A5,0xE8B8D433,
        0x7807C9A2,0x0F00F934,0x9609A88E,0xE10E9818,0x7F6A0DBB,0x086D3D2D,0x91646C97,0xE6635C01,
        0x6B6B51F4,0x1C6C6162,0x856530D8,0xF262004E,0x6C0695ED,0x1B01A57B,0x8208F4C1,0xF50FC457,
        0x65B0D9C6,0x12B7E950,0x8BBEB8EA,0xFCB9887C,0x62DD1DDF,0x15DA2D49,0x8CD37CF3,0xFBD44C65,
        0x4DB26158,0x3AB551CE,0xA3BC0074,0xD4BB30E2,0x4ADFA541,0x3DD895D7,0xA4D1C46D,0xD3D6F4FB,
        0x4369E96A,0x346ED9FC,0xAD678846,0xDA60B8D0,0x44042D73,0x33031DE5,0xAA0A4C5F,0xDD0D7CC9,
        0x5005713C,0x270241AA,0xBE0B1010,0xC90C2086,0x5768B525,0x206F85B3,0xB966D409,0xCE61E49F,
        0x5EDEF90E,0x29D9C998,0xB0D09822,0xC7D7A8B4,0x59B33D17,0x2EB40D81,0xB7BD5C3B,0xC0BA6CAD,
        0xEDB88320,0x9ABFB3B6,0x03B6E20C,0x74B1D29A,0xEAD54739,0x9DD277AF,0x04DB2615,0x73DC1683,
        0xE3630B12,0x94643B84,0x0D6D6A3E,0x7A6A5AA8,0xE40ECF0B,0x9309FF9D,0x0A00AE27,0x7D079EB1,
        0xF00F9344,0x8708A3D2,0x1E01F268,0x6906C2FE,0xF762575D,0x806567CB,0x196C3671,0x6E6B06E7,
        0xFED41B76,0x89D32BE0,0x10DA7A5A,0x67DD4ACC,0xF9B9DF6F,0x8EBEEFF9,0x17B7BE43,0x60B08ED5,
        0xD6D6A3E8,0xA1D1937E,0x38D8C2C4,0x4FDFF252,0xD1BB67F1,0xA6BC5767,0x3FB506DD,0x48B2364B,
        0xD80D2BDA,0xAF0A1B4C,0x36034AF6,0x41047A60,0xDF60EFC3,0xA867DF55,0x316E8EEF,0x4669BE79,
        0xCB61B38C,0xBC66831A,0x256FD2A0,0x5268E236,0xCC0C7795,0xBB0B4703,0x220216B9,0x5505262F,
        0xC5BA3BBE,0xB2BD0B28,0x2BB45A92,0x5CB36A04,0xC2D7FFA7,0xB5D0CF31,0x2CD99E8B,0x5BDEAE1D,
        0x9B64C2B0,0xEC63F226,0x756AA39C,0x026D930A,0x9C0906A9,0xEB0E363F,0x72076785,0x05005713,
        0x95BF4A82,0xE2B87A14,0x7BB12BAE,0x0CB61B38,0x92D28E9B,0xE5D5BE0D,0x7CDCEFB7,0x0BDBDF21,
        0x86D3D2D4,0xF1D4E242,0x68DDB3F8,0x1FDA836E,0x81BE16CD,0xF6B9265B,0x6FB077E1,0x18B74777,
        0x88085AE6,0xFF0F6A70,0x66063BCA,0x11010B5C,0x8F659EFF,0xF862AE69,0x616BFFD3,0x166CCF45,
        0xA00AE278,0xD70DD2EE,0x4E048354,0x3903B3C2,0xA7672661,0xD06016F7,0x4969474D,0x3E6E77DB,
        0xAED16A4A,0xD9D65ADC,0x40DF0B66,0x37D83BF0,0xA9BCAE53,0xDEBB9EC5,0x47B2CF7F,0x30B5FFE9,
        0xBDBDF21C,0xCABAC28A,0x53B39330,0x24B4A3A6,0xBAD03605,0xCDD70693,0x54DE5729,0x23D967BF,
        0xB3667A2E,0xC4614AB8,0x5D681B02,0x2A6F2B94,0xB40BBE37,0xC30C8EA1,0x5A05DF1B,0x2D02EF8D
    };
    uint32_t crc=0xFFFFFFFFu;
    for(int i=0;i<len;i++){
        crc=(crc>>8)^table[(crc^data[i])&0xFF];
    }
    return ~crc;
}

// ADLER32 (used in ZLIB)
static uint32_t adler32(const uint8_t* data,int len){
    const uint32_t MOD_ADLER=65521;
    uint32_t a=1,b=0;
    for(int i=0;i<len;i++){
        a=(a+data[i])%MOD_ADLER;
        b=(b+a)%MOD_ADLER;
    }
    return (b<<16)|a;
}

// FNV-1a hash (32-bit)
static uint32_t fnv1a_hash(const uint8_t* data,int len){
    const uint32_t FNV_PRIME=16777619u;
    const uint32_t FNV_OFFSET_BASIS=2166136261u;
    uint32_t hash=FNV_OFFSET_BASIS;
    for(int i=0;i<len;i++){
        hash^=data[i];
        hash*=FNV_PRIME;
    }
    return hash;
}

// MurmurHash3 32-bit
static uint32_t murmurhash3_32(const uint8_t* data,int len,uint32_t seed){
    const uint32_t c1=0xCC9E2D51;
    const uint32_t c2=0x1B873593;
    const uint32_t r1=15;
    const uint32_t r2=13;
    const uint32_t m=5;
    const uint32_t n=0xE6546B64;
    uint32_t h=seed;
    const int nblocks=len/4;
    const uint32_t* blocks=(const uint32_t*)data;
    for(int i=0;i<nblocks;i++){
        uint32_t k=blocks[i];
        k=ROTL32(k*c1,r1);
        k*=c2;
        h^=k;
        h=ROTL32(h,r2);
        h=h*m+n;
    }
    const uint8_t* tail=data+nblocks*4;
    uint32_t k1=0;
    switch(len&3){
        case 3: k1^=tail[2]<<16; /* fallthrough */
        case 2: k1^=tail[1]<<8;  /* fallthrough */
        case 1: k1^=tail[0];
            k1=ROTL32(k1*c1,r1);
            k1*=c2;
            h^=k1;
    }
    h^=len;
    h^=h>>16;
    h*=0x85EBCA6B;
    h^=h>>13;
    h*=0xC2B2AE35;
    h^=h>>16;
    return h;
}

// XXHash 32-bit
static uint32_t xxhash32(const uint8_t* data,int len,uint32_t seed){
    const uint32_t PRIME32_1=2654435761U;
    const uint32_t PRIME32_2=2246822507U;
    const uint32_t PRIME32_3=3266489917U;
    const uint32_t PRIME32_4=668265263U;
    const uint32_t PRIME32_5=374761393U;
    uint32_t h32=seed+PRIME32_5;
    const int nblocks=len/16;
    const uint32_t* blocks=(const uint32_t*)data;
    for(int i=0;i<nblocks;i++){
        uint32_t k1=blocks[i*4+0];
        uint32_t k2=blocks[i*4+1];
        uint32_t k3=blocks[i*4+2];
        uint32_t k4=blocks[i*4+3];
        k1=ROTL32(k1*PRIME32_2,13)*PRIME32_1;
        h32=ROTL32(h32+k1,17)*PRIME32_4;
        k2=ROTL32(k2*PRIME32_2,13)*PRIME32_1;
        h32=ROTL32(h32+k2,17)*PRIME32_4;
        k3=ROTL32(k3*PRIME32_2,13)*PRIME32_1;
        h32=ROTL32(h32+k3,17)*PRIME32_4;
        k4=ROTL32(k4*PRIME32_2,13)*PRIME32_1;
        h32=ROTL32(h32+k4,17)*PRIME32_4;
    }
    uint32_t h32_copy=h32;
    const uint8_t* tail=data+nblocks*16;
    int remaining=len%16;
    for(int i=0;i<remaining;i+=4){
        uint32_t k1=0;
        int bytes_left=remaining-i;
        if(bytes_left>=4){
            k1=*((const uint32_t*)(tail+i));
        }else{
            memcpy(&k1,tail+i,bytes_left);
        }
        k1=ROTL32(k1*PRIME32_2,13)*PRIME32_1;
        h32_copy=ROTL32(h32_copy+k1,17)*PRIME32_4;
    }
    h32^=h32_copy;
    h32^=len;
    h32^=h32>>15;
    h32*=PRIME32_2;
    h32^=h32>>13;
    h32*=PRIME32_3;
    h32^=h32>>16;
    return h32;
}

// ============ Hash Functions ============

// Helper macro to read big-endian 32-bit value
#define READ_BE32(p) (((uint32_t)(p)[0]<<24)|((uint32_t)(p)[1]<<16)|((uint32_t)(p)[2]<<8)|(uint32_t)(p)[3])
// Helper macro to write big-endian 32-bit value
#define WRITE_BE32(p, v) do {(p)[0]=(v)>>24;(p)[1]=(v)>>16;(p)[2]=(v)>>8;(p)[3]=(v);} while(0)

// MD5 (RFC 1321)
static const uint32_t MD5_K[64]={
    0xD76AA478,0xE8C7B756,0x242070DB,0xC1BDCEEE,0xF57C0FAF,0x4787C62A,0xA8304613,0xFD469501,
    0x698098D8,0x8B44F7AF,0xFFFF5BB1,0x895CD7BE,0x6B901122,0xFD987193,0xA679438E,0x49B40821,
    0xF61E2562,0xC040B340,0x265E5A51,0xE9B6C7AA,0xD62F105D,0x02441453,0xD8A1E681,0xE7D3FBC8,
    0x21E1CDE6,0xC33707D6,0xF4D50D87,0x455A14ED,0xA9E3E905,0xFCEFA3F8,0x676F02D9,0x8D2A4C8A,
    0xFFFA3942,0x8771F681,0x6D9D6122,0xFDE5380C,0xA4BEEA44,0x4BDECFA9,0xF6BB4B60,0xBEBFBC70,
    0x289B7EC6,0xEAA127FA,0xD4EF3085,0x04881D05,0xD9D4D039,0xE6DB99E5,0x1FA27CF8,0xC4AC5665,
    0xF4292244,0x432AFF97,0xAB9423A7,0xFC93A039,0x655B59C3,0x8F0CCC92,0xFFEFF47D,0x85845DD1,
    0x6FA87E4F,0xFE2CE6E0,0xA3014314,0x4E0811A1,0xF7537E82,0xBD3AF235,0x2AD7D2BB,0xEB86D391,
};
static const uint8_t MD5_SHIFT[64]={7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
                                   5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
                                   4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
                                   6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};
static uint32_t md5_f(uint32_t x,uint32_t y,uint32_t z){return (x&y)|(~x&z);}
static uint32_t md5_g(uint32_t x,uint32_t y,uint32_t z){return (x&z)|(y&~z);}
static uint32_t md5_h(uint32_t x,uint32_t y,uint32_t z){return x^y^z;}
static uint32_t md5_i(uint32_t x,uint32_t y,uint32_t z){return y^(x|~z);}
static void md5_transform(uint32_t state[4],const uint8_t block[64]){
    uint32_t a=state[0],b=state[1],c=state[2],d=state[3];
    uint32_t m[16];
    for(int i=0;i<16;i++) m[i]=*((const uint32_t*)(block+i*4));
    for(int i=0;i<64;i++){
        uint32_t f=0,g=0;
        if(i<16){f=md5_f(b,c,d);g=i;}
        else if(i<32){f=md5_g(b,c,d);g=(5*i+1)&15;}
        else if(i<48){f=md5_h(b,c,d);g=(3*i+5)&15;}
        else{f=md5_i(b,c,d);g=(7*i)&15;}
        uint32_t temp=d;
        d=c;
        c=b;
        b=b+ROTL32(a+f+MD5_K[i]+m[g],MD5_SHIFT[i]);
        a=temp;
    }
    state[0]+=a;state[1]+=b;state[2]+=c;state[3]+=d;
}
static void md5_hash(const uint8_t* data,int len,uint8_t out[16]){
    uint32_t state[4]={0x67452301,0xEFCDAB89,0x98BADCFE,0x10325476};
    uint64_t bitlen=(uint64_t)len*8;
    const uint8_t* p=data;
    int full=len&~0x3F;
    for(int i=0;i<full;i+=64,p+=64) md5_transform(state,p);
    int block_len=len-full;
    uint8_t block[64];
    memcpy(block,p,block_len);
    block[block_len]=0x80;
    if(block_len<=55){
        memset(block+block_len+1,0,55-block_len);
    }else{
        memset(block+block_len+1,0,63-block_len);
        md5_transform(state,block);
        memset(block,0,64);
    }
    for(int i=0;i<8;i++) block[56+i]=(bitlen>>(i*8))&0xFF;
    md5_transform(state,block);
    for(int i=0;i<16;i++) out[i]=(state[i>>2]>>((3-(i&3))*8))&0xFF;
}

// SHA-1 (RFC 6234 - deprecated but widely used)
static const uint32_t SHA1_K[4]={
    0x5A827999,0x6ED9EBA1,0x8F1BBCDC,0xCA62C1D6
};
static void sha1_transform(uint32_t state[5],const uint8_t block[64]){
    uint32_t w[80];
    for(int i=0;i<16;i++) w[i]=((uint32_t)block[i*4]<<24)|((uint32_t)block[i*4+1]<<16)|((uint32_t)block[i*4+2]<<8)|(uint32_t)block[i*4+3];
    for(int i=16;i<80;i++) w[i]=ROTL32(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);
    uint32_t a=state[0],b=state[1],c=state[2],d=state[3],e=state[4];
    for(int i=0;i<80;i++){
        uint32_t f=0,k=0;
        if(i<20){f=(b&c)|((~b)&d);k=SHA1_K[0];}
        else if(i<40){f=b^c^d;k=SHA1_K[1];}
        else if(i<60){f=(b&c)|(b&d)|(c&d);k=SHA1_K[2];}
        else{f=b^c^d;k=SHA1_K[3];}
        uint32_t temp=ROTL32(a,5)+f+e+k+w[i];
        e=d;d=c;c=ROTL32(b,30);b=a;a=temp;
    }
    state[0]+=a;state[1]+=b;state[2]+=c;state[3]+=d;state[4]+=e;
}
static void sha1_hash(const uint8_t* data,int len,uint8_t out[20]){
    uint32_t state[5]={0x67452301,0xEFCDAB89,0x98BADCFE,0x10325476,0xC3D2E1F0};
    uint64_t bitlen=(uint64_t)len*8;
    const uint8_t* p=data;
    int full=len&~0x3F;
    for(int i=0;i<full;i+=64,p+=64) sha1_transform(state,p);
    int block_len=len-full;
    uint8_t block[64];
    memcpy(block,p,block_len);
    block[block_len]=0x80;
    if(block_len<=55){
        memset(block+block_len+1,0,55-block_len);
    }else{
        memset(block+block_len+1,0,63-block_len);
        sha1_transform(state,block);
        memset(block,0,64);
    }
    for(int i=0;i<8;i++) block[56+i]=(bitlen>>(56-i*8))&0xFF;
    sha1_transform(state,block);
    for(int i=0;i<20;i++) out[i]=(state[i>>2]>>((3-(i&3))*8))&0xFF;
}

// SHA-256 implementation - simple and correct
static const uint32_t SHA256_K[64]={
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};
/* the file header already defines ROTR32 (identical expansion); guard so
   -Werror carrier builds (ffmpeg) do not see a redefinition */
#ifndef ROTR32
#define ROTR32(x,n) (((x)>>(n))|((x)<<(32-(n))))
#endif
static uint32_t rotr32(uint32_t x,int n){return ROTR32(x,n);}
static uint32_t shr32(uint32_t x,int n){return x>>n;}
static uint32_t sha256_ch(uint32_t x,uint32_t y,uint32_t z){return z^((x)&(y^z));}
static uint32_t sha256_maj(uint32_t x,uint32_t y,uint32_t z){return ((x)&(y))|((z)&(x|y));}
static uint32_t sha256_ep0(uint32_t x){return rotr32(x,2)^rotr32(x,13)^rotr32(x,22);}
static uint32_t sha256_ep1(uint32_t x){return rotr32(x,6)^rotr32(x,11)^rotr32(x,25);}
static uint32_t sha256_s0(uint32_t x){return rotr32(x,7)^rotr32(x,18)^shr32(x,3);}
static uint32_t sha256_s1(uint32_t x){return rotr32(x,17)^rotr32(x,19)^shr32(x,10);}
static void sha256_transform(uint32_t state[8],const uint8_t* data){
    uint32_t w[64];
    for(int i=0;i<16;i++){
        w[i]=((uint32_t)data[i*4]<<24)|((uint32_t)data[i*4+1]<<16)|
             ((uint32_t)data[i*4+2]<<8)|((uint32_t)data[i*4+3]);
    }
    for(int i=16;i<64;i++){
        uint32_t s0=sha256_s0(w[i-15]);
        uint32_t s1=sha256_s1(w[i-2]);
        w[i]=w[i-16]+s0+w[i-7]+s1;
    }
    uint32_t a=state[0],b=state[1],c=state[2],d=state[3],e=state[4],f=state[5],g=state[6],h=state[7];
    for(int i=0;i<64;i++){
        uint32_t t1=h+sha256_ep1(e)+sha256_ch(e,f,g)+SHA256_K[i]+w[i];
        uint32_t t2=sha256_ep0(a)+sha256_maj(a,b,c);
        h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
    }
    state[0]+=a;state[1]+=b;state[2]+=c;state[3]+=d;state[4]+=e;state[5]+=f;state[6]+=g;state[7]+=h;
}
static void sha256_hash(const uint8_t* msg,int len,uint8_t* hash){
    uint32_t state[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    uint64_t mlen=(uint64_t)len*8;
    uint8_t buf[128];
    int i;
    for(i=0;i+64<=len;i+=64, msg+=64) sha256_transform(state,msg);
    int remaining=len-i;
    memcpy(buf,msg,remaining);
    buf[remaining]=0x80;
    if(remaining<=55){
        memset(buf+remaining+1,0,64-(remaining+1));
        for(i=0;i<8;i++) buf[56+i]=(mlen>>(56-(i*8)))&0xff;
        sha256_transform(state,buf);
    }else{
        memset(buf+remaining+1,0,128-(remaining+1));
        sha256_transform(state,buf);
        memset(buf,0,64);
        for(i=0;i<8;i++) buf[56+i]=(mlen>>(56-(i*8)))&0xff;
        sha256_transform(state,buf);
    }
    for(i=0;i<32;i++) hash[i]=(state[i>>2]>>((3-(i&3))*8))&0xff;
}

// SHA-512 (FIPS 180-4 - 64-bit variant)
static const uint64_t SHA512_K[80]={
    0x428A2F98D728AE22ULL,0x7137449123EF65CDULL,0xB5C0FBCFEC4F3E5FULL,0xE9B5DBA58C89B0BDULL,
    0x3956C25BF348B538ULL,0x59F111F1B605D019ULL,0x923F82A4AF194F9BULL,0xAB1C5ED5DA6D8118ULL,
    0xD807AA98A3030242ULL,0x12835B0145706FBEULL,0x243185BE4EE4B28CULL,0x550C7DC3A5FF44E2ULL,
    0x72BE5D74F27B896FULL,0x80DEB1FE3B1696B1ULL,0x9BDC06A725C71235ULL,0xC19BF27CF8986ADFULL,
    0xE49B69C19F14CDDFULL,0xEFBE4786384F25E3ULL,0x0FC19DC68B8CD5B5ULL,0x240CA1CC77AC9C65ULL,
    0x2DE92C6FC59BF66BULL,0x4A7484AA6EA6E483ULL,0x5CB0A9DCBD41FBD4ULL,0x76F988DA831153B5ULL,
    0x983E5152EE66DFABULL,0xA831C66D2DB43210ULL,0xB00327C898FB213FULL,0xBF597FC7BEEF0EE4ULL,
    0xC6E00BF33DA88FC2ULL,0xD5A79147930AA725ULL,0x06CA6351E003826FULL,0x142929670A0E6E70ULL,
    0x27B70A8546D22FFCULL,0x2E1B21385C26C926ULL,0x4D2C6DFC5AC42AEDULL,0x53380D139D95B3DFULL,
    0x650A73548BAF63DEULL,0x766A0ABB3C77B2A8ULL,0x81C2C92E47EDAEE6ULL,0x92722C851482353BULL,
    0xA2BFE8A14CF10364ULL,0xA81A664BBC423001ULL,0xC24B8B70D0F89791ULL,0xC76C51A30654BE30ULL,
    0xD192E819D6EF5218ULL,0xD69906245565A910ULL,0xF40E35855771202AULL,0x106AA07032BBD1B8ULL,
    0x19A4C116B8D2D0C8ULL,0x1E376C085141AB53ULL,0x2748774CDF8EEB99ULL,0x34B0BCB5E19B48A8ULL,
    0x391C0CB3C5C95A63ULL,0x4ED8AA4AE3418ACBULL,0x5B9CCA4F7763E373ULL,0x682E6FF3D6B2B8A3ULL,
    0x748F82AE5DEFB2FCULL,0x78A5636F43172F60ULL,0x84C87814A0F0B413ULL,0x8CC702081A6439ECULL,
    0x90BEFFFA23631E28ULL,0xA4506CEBDE82BDE9ULL,0xBEF9A3F7B2C67915ULL,0xC67178F2E372532BULL,
    0xCA273ECEEA26619CULL,0xD186B8C721C0C207ULL,0xEADA7DD6CDE0EB1EULL,0xF57D4F7FEE6ED178ULL,
    0x06F067AA72176FBAULL,0x0A637DC5A2C898A6ULL,0x113F9804BEF90DAEULL,0x1B710B35131C471BULL,
    0x28DB77F523047D84ULL,0x32CAAB7B40C72493ULL,0x3C9BE0A15C9BEBC9ULL,0x431D67C49C100D4CULL,
    0x4CC5D4BECB3E42B6ULL,0x597F299CFC657E2AULL,0x5FCB6FAB3AD6FAECULL,0x6C44198C4A475817ULL
};
#define ROTR64(x,n) (((x) >> (n)) | ((x) << (64 - (n))))
static uint64_t sha512_ch(uint64_t x,uint64_t y,uint64_t z){return (x&y)^(~x&z);}
static uint64_t sha512_maj(uint64_t x,uint64_t y,uint64_t z){return (x&y)^(x&z)^(y&z);}
static uint64_t sha512_ep0(uint64_t x){return ROTR64(x,28)^ROTR64(x,34)^ROTR64(x,39);}
static uint64_t sha512_ep1(uint64_t x){return ROTR64(x,14)^ROTR64(x,18)^ROTR64(x,41);}
static uint64_t sha512_s0(uint64_t x){return ROTR64(x,1)^ROTR64(x,8)^(x>>7);}
static uint64_t sha512_s1(uint64_t x){return ROTR64(x,19)^ROTR64(x,61)^(x>>6);}
static void sha512_transform(uint64_t state[8],const uint8_t block[128]){
    uint64_t w[80];
    for(int i=0;i<16;i++) w[i]=*((const uint64_t*)(block+i*8));
    for(int i=16;i<80;i++) w[i]=sha512_s1(w[i-2])+w[i-7]+sha512_s0(w[i-15])+w[i-16];
    uint64_t a=state[0],b=state[1],c=state[2],d=state[3],e=state[4],f=state[5],g=state[6],h=state[7];
    for(int i=0;i<80;i++){
        uint64_t t1=h+sha512_ep1(e)+sha512_ch(e,f,g)+SHA512_K[i]+w[i];
        uint64_t t2=sha512_ep0(a)+sha512_maj(a,b,c);
        h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;
    }
    state[0]+=a;state[1]+=b;state[2]+=c;state[3]+=d;state[4]+=e;state[5]+=f;state[6]+=g;state[7]+=h;
}
static void sha512_hash(const uint8_t* data,int len,uint8_t out[64]){
    uint64_t state[8]={
        0x6A09E667F3BCC908ULL,0xBB67AE8584CAA73BULL,0x3C6EF372FE94F82BULL,0xA54FF53A5F1D36F1ULL,
        0x510E527FADE682D1ULL,0x9B05688C2B3E6C1FULL,0x1F83D9ABFB41BD6BULL,0x5BE0CD19137E2179ULL
    };
    uint64_t bitlen=(uint64_t)len*8;
    int block_len=len&0x7F;
    uint8_t block[128];
    memcpy(block,data,block_len);
    block[block_len]=0x80;
    if(block_len<=111){
        memset(block+block_len+1,0,111-block_len);
    }else{
        memset(block+block_len+1,0,127-block_len);
        sha512_transform(state,block);
        memset(block,0,128);
    }
    for(int i=0;i<16;i++) block[112+i]=(bitlen>>(120-i*8))&0xFF;
    sha512_transform(state,block);
    for(int i=0;i<64;i++) out[i]=(state[i>>3]>>((7-(i&7))*8))&0xFF;
}

// BLAKE2b: removed — implementation was broken (constant output) and no stage
// code called it. V3.3 embeds the BLAKE2 MAC as a constant (Python-side).

// RIPEMD-160: not implemented in C — V2.5 embeds the hash as a
// compile-time constant (computed Python-side); no C-side call sites.

// ============ Cipher Functions ============

// TEA (Tiny Encryption Algorithm)
static void tea_encrypt(const uint32_t key[4],uint32_t v[2]){
    const uint32_t delta=0x9E3779B9;
    uint32_t sum=0;
    for(int i=0;i<32;i++){
        sum+=delta;
        v[0]+=((v[1]<<4)+key[0])^(v[1]+sum)^((v[1]>>5)+key[1]);
        v[1]+=((v[0]<<4)+key[2])^(v[0]+sum)^((v[0]>>5)+key[3]);
    }
}
static void tea_decrypt(const uint32_t key[4],uint32_t v[2]){
    const uint32_t delta=0x9E3779B9;
    uint32_t sum=delta*32;
    for(int i=0;i<32;i++){
        v[1]-=((v[0]<<4)+key[2])^(v[0]+sum)^((v[0]>>5)+key[3]);
        v[0]-=((v[1]<<4)+key[0])^(v[1]+sum)^((v[1]>>5)+key[1]);
        sum-=delta;
    }
}

// XTEA (eXtended TEA)
static void xtea_encrypt(const uint32_t key[4],uint32_t v[2]){
    const uint32_t delta=0x9E3779B9;
    uint32_t sum=0;
    for(int i=0;i<32;i++){
        v[0]+=(((v[1]<<4)^(v[1]>>5))+v[1])^(sum+key[sum&3]);
        sum+=delta;
        v[1]+=(((v[0]<<4)^(v[0]>>5))+v[0])^(sum+key[(sum>>11)&3]);
    }
}
static void xtea_decrypt(const uint32_t key[4],uint32_t v[2]){
    const uint32_t delta=0x9E3779B9;
    uint32_t sum=delta*32;
    for(int i=0;i<32;i++){
        v[1]-=(((v[0]<<4)^(v[0]>>5))+v[0])^(sum+key[(sum>>11)&3]);
        sum-=delta;
        v[0]-=(((v[1]<<4)^(v[1]>>5))+v[1])^(sum+key[sum&3]);
    }
}

// DES/3DES: removed — the implementation was broken (type confusion) and no
// stage code called it. V2.7 embeds 3DES results as constants (Python-side).

// Blowfish (simplified - educational)
static const uint32_t BLOWFISH_P[18]={
    0x243F6A88,0x85A308D3,0x13198A2E,0x03707344,0xA4093822,0x299F31D0,
    0x082EFA98,0xEC4E6C89,0x452821E6,0x38D01377,0xBE5466CF,0x34E90C6C,
    0xC0AC29B7,0xC97C50DD,0x3F84D5B5,0xB5470917,0x9216D5D9,0x8979FB1B
};
static uint32_t blowfish_f(uint32_t x){
    const uint32_t sbox[4][256]={
        {0xD1310BA6,0x98DFB5AC,/*... full S-box would be here ...*/0x7D24CC80},
        {0x67C5A3A4,0xB5F4C72F,/*...*/0x2A99D484},
        {0x1E9A4C5B,0x6F72D5C3,/*...*/0x85E5A8D6},
        {0x4A8D9C2E,0xF2B39741,/*...*/0xC8D9B6A5}
    };
    return ((sbox[0][(x>>24)&0xFF]+sbox[1][(x>>16)&0xFF])^sbox[2][(x>>8)&0xFF])+sbox[3][x&0xFF];
}
static void blowfish_encrypt(const uint32_t* P,uint32_t* left,uint32_t* right){
    uint32_t l=*left,r=*right;
    for(int i=0;i<16;i++){
        l^=P[i];r^=blowfish_f(l);r^=P[i+1];
        uint32_t t=l;l=r;r=t;
    }
    r^=P[16];l^=P[17];
    *left=l;*right=r;
}

// ChaCha20 (RFC 8439)
static const uint32_t CHACHA20_SIGMA[4]={
    0x61707865,0x3320646E,0x79622D32,0x6B206574
};
static uint32_t chacha20_rotl(uint32_t x,int n){return (x<<n)|(x>>(32-n));}
static void chacha20_quarterround(uint32_t* a,uint32_t* b,uint32_t* c,uint32_t* d){
    *a+=*d;*d=chacha20_rotl(*d,16);*d^=*a;
    *b+=*a;*a=chacha20_rotl(*a,20);*a^=*b;
    *c+=*b;*b=chacha20_rotl(*b,24);*b^=*c;
    *d+=*c;*c=chacha20_rotl(*c,12);*c^=*d;
}
static void chacha20_block(const uint32_t key[8],uint32_t counter,const uint32_t nonce[3],uint8_t out[64]){
    uint32_t state[16];
    memcpy(state,CHACHA20_SIGMA,16);
    memcpy(state+4,key,32);
    state[12]=counter;
    memcpy(state+13,nonce,12);
    uint32_t working[16];
    memcpy(working,state,64);
    for(int i=0;i<10;i++){
        for(int j=0;j<4;j++) chacha20_quarterround(&working[j],&working[j+4],&working[j+8],&working[j+12]);
        for(int j=0;j<4;j++) chacha20_quarterround(&working[j*4],&working[(j+1)%4+4],&working[(j+2)%4+8],&working[(j+3)%4+12]);
    }
    for(int i=0;i<16;i++){
        uint32_t result=state[i]+working[i];
        out[i*4+0]=result&0xFF;out[i*4+1]=(result>>8)&0xFF;
        out[i*4+2]=(result>>16)&0xFF;out[i*4+3]=(result>>24)&0xFF;
    }
}
static void chacha20_encrypt(const uint32_t key[8],uint32_t counter,const uint32_t nonce[3],uint8_t* data,int len){
    uint8_t keystream[64];
    for(int offset=0;offset<len;offset+=64){
        chacha20_block(key,counter++,nonce,keystream);
        int block_len=(len-offset<64)?len-offset:64;
        for(int i=0;i<block_len;i++) data[offset+i]^=keystream[i];
    }
}

// Salsa20 (reduced to 20 rounds)
static const uint32_t SALSA20_SIGMA[4]={
    0x61707865,0x3120646E,0x79622D32,0x6B206574
};
static uint32_t salsa20_rotl(uint32_t x,int n){return (x<<n)|(x>>(32-n));}
static void salsa20_quarterround(uint32_t* a,uint32_t* b,uint32_t* c,uint32_t* d){
    *b^=salsa20_rotl(*a+*d,7);*c^=salsa20_rotl(*b+*a,9);
    *d^=salsa20_rotl(*c+*b,13);*a^=salsa20_rotl(*d+*c,18);
}
static void salsa20_block(const uint32_t key[8],uint64_t counter,const uint64_t nonce,uint8_t out[64]){
    uint32_t state[16];
    memcpy(state,SALSA20_SIGMA,16);
    memcpy(state+4,key,32);
    memcpy(state+6,(uint32_t*)&nonce,8);
    memcpy(state+8,(uint32_t*)&counter,8);
    memcpy(state+10,key+4,16);
    memcpy(state+14,SALSA20_SIGMA+3,4);
    uint32_t working[16];
    memcpy(working,state,64);
    for(int i=0;i<10;i++){
        for(int j=0;j<4;j++) salsa20_quarterround(&working[j*4],&working[(j+1)%4+4],&working[(j+2)%4+8],&working[(j+3)%4+12]);
        for(int j=0;j<4;j++) salsa20_quarterround(&working[j*4],&working[(j+4)%4],&working[(j+8)%4],&working[(j+12)%4]);
    }
    for(int i=0;i<16;i++){
        uint32_t result=state[i]+working[i];
        out[i*4+0]=result&0xFF;out[i*4+1]=(result>>8)&0xFF;
        out[i*4+2]=(result>>16)&0xFF;out[i*4+3]=(result>>24)&0xFF;
    }
}
static void salsa20_encrypt(const uint32_t key[8],uint64_t counter,const uint64_t nonce,uint8_t* data,int len){
    uint8_t keystream[64];
    for(int offset=0;offset<len;offset+=64){
        salsa20_block(key,counter++,nonce,keystream);
        int block_len=(len-offset<64)?len-offset:64;
        for(int i=0;i<block_len;i++) data[offset+i]^=keystream[i];
    }
}

// RC4 (already defined, adding reference for completeness)
static void rc4_crypt(const uint8_t* key,int key_len,uint8_t* data,int data_len){
    if(key_len<=0||data_len<=0) return;
    uint8_t S[256];
    for(int i=0;i<256;i++) S[i]=(uint8_t)i;
    int j=0;
    for(int i=0;i<256;i++){
        j=(j+S[i]+key[i%key_len])&0xFF;
        uint8_t t=S[i];S[i]=S[j];S[j]=t;
    }
    int i=0;j=0;
    for(int k=0;k<data_len;k++){
        i=(i+1)&0xFF;
        j=(j+S[i])&0xFF;
        uint8_t t=S[i];S[i]=S[j];S[j]=t;
        data[k]^=S[(S[i]+S[j])&0xFF];
    }
}

// ============ MAC Functions (removed) ============
// hmac_* helpers were broken (buffer overflow for long inputs) and unused —
// A3_V31/A5_V51 embed HMAC values as compile-time compare constants.

// Poly1305 (RFC 7539)
static void poly1305_auth(const uint8_t* key,const uint8_t* data,int len,uint8_t out[16]){
    uint32_t r0=*((const uint32_t*)(key+0))&0x03FFFFFF;
    uint32_t r1=*((const uint32_t*)(key+4))&0x03FFFF03;
    uint32_t r2=*((const uint32_t*)(key+8))&0x00FCFFFC;
    uint32_t r3=*((const uint32_t*)(key+12))&0x030FFFFF;
    uint32_t r4=*((const uint32_t*)(key+16))&0x03FFFFFF;
    uint32_t s0=*((const uint32_t*)(key+20));
    uint32_t s1=*((const uint32_t*)(key+24));
    uint32_t s2=*((const uint32_t*)(key+28));
    uint32_t s3=*((const uint32_t*)(key+32));
    uint32_t h0=0,h1=0,h2=0,h3=0,h4=0;
    const int block_size=16;
    for(int offset=0;offset<=len;offset+=block_size){
        int chunk_len=(len-offset<block_size)?len-offset:block_size;
        uint8_t chunk[16];
        memset(chunk,0,16);
        memcpy(chunk,data+offset,chunk_len);
        if(offset+block_size>=len) chunk[chunk_len]|=0x01;
        uint32_t d0=*((const uint32_t*)(chunk+0));
        uint32_t d1=*((const uint32_t*)(chunk+4));
        uint32_t d2=*((const uint32_t*)(chunk+8));
        uint32_t d3=*((const uint32_t*)(chunk+12));
        h0+=d0;h1+=d1;h2+=d2;h3+=d3;h4+=((offset+block_size>=len)?1:0);
        uint64_t d=(uint64_t)r0*h0+((uint64_t)r4*h1<<2)+((uint64_t)r3*h2<<2)+((uint64_t)r2*h3<<4)+((uint64_t)r1*h4<<2);
        uint32_t c=d&0xFFFFFFFF;
        d>>=32;
        h0=c&0x3FFFFFF;c=(d+=h1)>>30;h1=c&0x3FFFFFF;c=(d+=h2)>>30;h2=c&0x03FFFF03;c=(d+=h3)>>30;h3=c&0x030FFFFF;c=(d+=h4)>>26;h4=c&0x03FFFFFF;
    }
    uint64_t d=((uint64_t)h0<<2)+h1*5+s0;uint32_t g0=d&0xFFFFFFFF;d>>=32;
    d+=((uint64_t)h1<<2)+h2*5+s1;uint32_t g1=d&0xFFFFFFFF;d>>=32;
    d+=((uint64_t)h2<<2)+h3*5+s2;uint32_t g2=d&0xFFFFFFFF;d>>=32;
    d+=((uint64_t)h3<<2)+h4*5+s3;uint32_t g3=d&0xFFFFFFFF;
    memcpy(out+0,&g0,4);memcpy(out+4,&g1,4);memcpy(out+8,&g2,4);memcpy(out+12,&g3,4);
}

// AES-128 ECB mode (single block encryption)
static const uint8_t AES_SBOX[256]={
    0x63,0x7C,0x77,0x7B,0xF2,0x6B,0x6F,0xC5,0x30,0x01,0x67,0x2B,0xFE,0xD7,0xAB,0x76,
    0xCA,0x82,0xC9,0x7D,0xFA,0x59,0x47,0xF0,0xAD,0xD4,0xA2,0xAF,0x9C,0xA4,0x72,0xC0,
    0xB7,0xFD,0x93,0x26,0x36,0x3F,0xF7,0xCC,0x34,0xA5,0xE5,0xF1,0x71,0xD8,0x31,0x15,
    0x04,0xC7,0x23,0xC3,0x18,0x96,0x05,0x9A,0x07,0x12,0x80,0xE2,0xEB,0x27,0xB2,0x75,
    0x09,0x83,0x2C,0x1A,0x1B,0x6E,0x5A,0xA0,0x52,0x3B,0xD6,0xB3,0x29,0xE3,0x2F,0x84,
    0x53,0xD1,0x00,0xED,0x20,0xFC,0xB1,0x5B,0x6A,0xCB,0xBE,0x39,0x4A,0x4C,0x58,0xCF,
    0xD0,0xEF,0xAA,0xFB,0x43,0x4D,0x33,0x85,0x45,0xF9,0x02,0x7F,0x50,0x3C,0x9F,0xA8,
    0x51,0xA3,0x40,0x8F,0x92,0x9D,0x38,0xF5,0xBC,0xB6,0xDA,0x21,0x10,0xFF,0xF3,0xD2,
    0xCD,0x0C,0x13,0xEC,0x5F,0x97,0x44,0x17,0xC4,0xA7,0x7E,0x3D,0x64,0x5D,0x19,0x73,
    0x60,0x81,0x4F,0xDC,0x22,0x2A,0x90,0x88,0x46,0xEE,0xB8,0x14,0xDE,0x5E,0x0B,0xDB,
    0xE0,0x32,0x3A,0x0A,0x49,0x06,0x24,0x5C,0xC2,0xD3,0xAC,0x62,0x91,0x95,0xE4,0x79,
    0xE7,0xC8,0x37,0x6D,0x8D,0xD5,0x4E,0xA9,0x6C,0x56,0xF4,0xEA,0x65,0x7A,0xAE,0x08,
    0xBA,0x78,0x25,0x2E,0x1C,0xA6,0xB4,0xC6,0xE8,0xDD,0x74,0x1F,0x4B,0xBD,0x8B,0x8A,
    0x70,0x3E,0xB5,0x66,0x48,0x03,0xF6,0x0E,0x61,0x35,0x57,0xB9,0x86,0xC1,0x1D,0x9E,
    0xE1,0xF8,0x98,0x11,0x69,0xD9,0x8E,0x94,0x9B,0x1E,0x87,0xE9,0xCE,0x55,0x28,0xDF,
    0x8C,0xA1,0x89,0x0D,0xBF,0xE6,0x42,0x68,0x41,0x99,0x2D,0x0F,0xB0,0x54,0xBB,0x16
};
static const uint8_t AES_RCON[11]={0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36};
static void aes_key_schedule(const uint8_t* key,uint32_t* w){
    for(int i=0;i<4;i++) w[i]=*((const uint32_t*)(key+i*4));
    for(int i=4;i<44;i++){
        uint32_t temp=w[i-1];
        if(i%4==0){
            uint8_t s0=AES_SBOX[(temp>>8)&0xFF],s1=AES_SBOX[(temp>>16)&0xFF],s2=AES_SBOX[(temp>>24)&0xFF],s3=AES_SBOX[temp&0xFF];
            temp=(s0<<24)|(s1<<16)|(s2<<8)|s3;
            temp=ROTL32(temp,8)^AES_RCON[i/4];
        }
        w[i]=w[i-4]^temp;
    }
}
static void aes_128_encrypt_block(const uint8_t* key,uint8_t* block){
    uint32_t w[44];
    aes_key_schedule(key,w);
    uint32_t s[4];
    for(int i=0;i<4;i++) s[i]=*((const uint32_t*)(block+i*4));
    for(int round=1;round<=10;round++){
        for(int i=0;i<4;i++) s[i]=AES_SBOX[(s[i]>>24)&0xFF]|(AES_SBOX[(s[i]>>16)&0xFF]<<8)|(AES_SBOX[(s[i]>>8)&0xFF]<<16)|(AES_SBOX[s[i]&0xFF]<<24);
        s[1]=ROTL32(s[1],8);s[2]=ROTL32(s[2],8);s[3]=ROTL32(s[3],8);
        for(int i=0;i<4;i++) s[i]^=w[round*4+i];
    }
    s[1]=ROTL32(s[1],8);s[2]=ROTL32(s[2],8);s[3]=ROTL32(s[3],8);
    for(int i=0;i<4;i++) s[i]=AES_SBOX[(s[i]>>24)&0xFF]|(AES_SBOX[(s[i]>>16)&0xFF]<<8)|(AES_SBOX[(s[i]>>8)&0xFF]<<16)|(AES_SBOX[s[i]&0xFF]<<24);
    for(int i=0;i<4;i++) s[i]^=w[40+i];
    for(int i=0;i<4;i++) *((uint32_t*)(block+i*4))=s[i];
}

static int b62v[256];
static void init_decoder(void){
    const char* cs="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for(int i=0;i<256;i++) b62v[i]=-1;
    for(int i=0;i<62;i++) b62v[(unsigned char)cs[i]]=i;
}
static void decode_blob(const char* in,uint8_t* out,int len){
    // Decode Base62 using big integer arithmetic
    memset(out,0,len);
    for(;*in;in++){
        int c=b62v[(unsigned char)*in];
        if(c<0) continue;
        // Multiply by 62 (shift base)
        int carry=c;
        for(int i=len-1;i>=0;i--){
            int t=out[i]*62+carry;
            out[i]=t&0xFF;
            carry=t>>8;
        }
    }
}

// Base62 encoding - flag is computed at runtime from verified blob
static const char* B62_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

// Helper: append character to buffer
static void b62_append(char* buf, int* pos, char c) {
    buf[(*pos)++] = c;
}

// Helper: integer to string conversion
static void int_to_str(int val, char* buf, int* len) {
    if (val == 0) {
        buf[0] = '0';
        *len = 1;
        return;
    }
    char temp[16];
    int tpos = 0;
    while (val > 0) {
        temp[tpos++] = '0' + (val % 10);
        val /= 10;
    }
    for (int i = tpos - 1; i >= 0; i--) {
        buf[(*len)++] = temp[i];
    }
}

// Convert big-endian byte array to base62 string
// Input: data pointer, length (typically 15 bytes for flag generation)
// Output: base62 encoded string (NOT padded to 25 chars - padding is done separately)
static void bigint_to_b62(const uint8_t* data, int data_len, char* output) {
    char temp[32];
    int tpos = 31;
    temp[tpos--] = '\0';

    // Work on a copy
    uint8_t work[16];
    int wlen = data_len;

    // Skip leading zeros
    int first_nonzero = 0;
    while (first_nonzero < data_len && data[first_nonzero] == 0) {
        first_nonzero++;
    }

    if (first_nonzero >= data_len) {
        output[0] = '0';
        output[1] = '\0';
        return;
    }

    // Copy non-zero part
    wlen = data_len - first_nonzero;
    for (int i = first_nonzero; i < data_len; i++) {
        work[i - first_nonzero] = data[i];
    }

    int done = 0;
    while (!done) {
        done = 1;
        for (int i = 0; i < wlen; i++) {
            if (work[i] != 0) { done = 0; break; }
        }

        if (!done) {
            uint64_t carry = 0;
            for (int i = 0; i < wlen; i++) {
                uint64_t val = (carry << 8) | work[i];
                work[i] = val / 62;
                carry = val % 62;
            }
            temp[tpos--] = B62_ALPHABET[carry];
        }
    }

    int opos = 0;
    for (int i = tpos + 1; temp[i] != '\0'; i++) {
        output[opos++] = temp[i];
    }
    output[opos] = '\0';
}

// Pad base62 token to exactly 25 characters using deterministic expansion
// The padding is computed based on the input, making the flag runtime-derived
static void b62_pad_to_25(const char* input, char* output) {
    int len = strlen(input);
    if (len >= 25) {
        strncpy(output, input, 25);
        output[25] = '\0';
        return;
    }

    // Simple deterministic padding: use a formula based on the input
    // to generate padding characters (no SHA256 needed)
    char temp[32];
    strncpy(temp, input, sizeof(temp) - 1);
    temp[sizeof(temp) - 1] = '\0';

    int current_len = len;
    while (current_len < 25) {
        // Generate padding character based on current content
        uint32_t hash = 0;
        for (int i = 0; i < current_len; i++) {
            hash = hash * 31 + (unsigned char)temp[i];
        }
        hash += current_len * 17;  // Mix in the length

        // Use hash to select character from alphabet
        int idx = hash % 62;
        char pad_char = B62_ALPHABET[idx];

        // Prepend: shift everything right
        for (int i = current_len; i >= 0; i--) {
            temp[i + 1] = temp[i];
        }
        temp[0] = pad_char;
        current_len++;
    }

    strncpy(output, temp, 25);
    output[25] = '\0';
}

// Generate flag from verified blob (computed at runtime, NOT hardcoded)
static void generate_flag(const uint8_t* blob, int blob_len, char* output) {
    // Use first blob_len bytes (typically 15) for base62 encoding
    char b62_unpadded[32];
    bigint_to_b62(blob, blob_len, b62_unpadded);

    char b62_token[32];
    b62_pad_to_25(b62_unpadded, b62_token);

    // Format as flag{XXXXX-XXXXX-XXXXX-XXXXX-XXXXX}
    int opos = 0;
    output[opos++] = 'f';
    output[opos++] = 'l';
    output[opos++] = 'a';
    output[opos++] = 'g';
    output[opos++] = '{';

    for (int group = 0; group < 5; group++) {
        if (group > 0) output[opos++] = '-';
        for (int i = 0; i < 5; i++) {
            output[opos++] = b62_token[group * 5 + i];
        }
    }

    output[opos++] = '}';
    output[opos++] = '\0';
}



// A5 V5.2 Constants (RSA-1024, Wiener-weak: d < n^(1/4)/3)
static const uint32_t A5_MAGIC=0x4C4E5335u;
static const uint16_t A5_VERSION=6u;
static const uint32_t A5_PRODUCT_ID=3471u;
static const uint8_t RSA_N[128]={0xCC, 0xB7, 0xF9, 0xB3, 0x13, 0xAD, 0x56, 0x08, 0xDE, 0x5F, 0x1A, 0x13, 0x3D, 0x40, 0x86, 0x37, 0x84, 0x93, 0xE8, 0x17, 0x66, 0xFD, 0x0C, 0xD6, 0x06, 0x90, 0xBB, 0xC0, 0xB8, 0x8F, 0x7E, 0xCA, 0x81, 0x6A, 0xF2, 0xB4, 0x95, 0x3D, 0x35, 0x8B, 0xCD, 0xB2, 0x32, 0xDA, 0xC1, 0x8D, 0xC5, 0xDE, 0xDC, 0x9B, 0xB0, 0x13, 0x0A, 0x2B, 0xD6, 0x8E, 0xF7, 0xA1, 0x93, 0x4C, 0xDD, 0x4E, 0xDF, 0xFB, 0x48, 0x8C, 0x78, 0x74, 0xC1, 0xF4, 0xC8, 0xCF, 0x5C, 0x9E, 0xBE, 0x41, 0x64, 0xF1, 0x52, 0xD7, 0x59, 0x5F, 0x61, 0xB5, 0xB8, 0x41, 0x66, 0xDF, 0xC8, 0x0A, 0xF2, 0xFF, 0xCD, 0xEF, 0xE1, 0x4F, 0x05, 0xC1, 0xB1, 0xC5, 0x67, 0xCC, 0x2F, 0x25, 0x3E, 0xFB, 0xB7, 0xCA, 0xBA, 0x4D, 0x18, 0x1C, 0xD9, 0xC6, 0x21, 0xD5, 0xB7, 0xD5, 0x6D, 0xDE, 0xD9, 0xB8, 0x69, 0x80, 0x5A, 0x54, 0x00, 0xC5};
static const uint8_t RSA_E[128]={0x72, 0xF0, 0xE1, 0xD4, 0xD3, 0x06, 0x50, 0xCB, 0x3C, 0xAB, 0xBB, 0x79, 0x6F, 0x0C, 0x14, 0xDF, 0x51, 0x73, 0x6B, 0x2F, 0x41, 0x22, 0x73, 0xF5, 0x80, 0xD5, 0x49, 0x44, 0x67, 0xAD, 0x6B, 0xA3, 0xDD, 0x4A, 0x27, 0x38, 0x1E, 0xA2, 0x90, 0x24, 0xB7, 0x96, 0x30, 0x10, 0x10, 0xAB, 0x36, 0xB3, 0x5E, 0xDF, 0xE7, 0xFA, 0x18, 0x27, 0x3F, 0x30, 0x68, 0x8D, 0x25, 0x39, 0xAF, 0x7A, 0x60, 0xF8, 0x60, 0x97, 0x57, 0x73, 0x7C, 0x90, 0xA0, 0x74, 0x33, 0x7A, 0xD6, 0x08, 0x8A, 0x04, 0x65, 0xB3, 0xCF, 0x02, 0x36, 0xD6, 0xD6, 0xCD, 0xB2, 0x9A, 0xCD, 0x53, 0x9D, 0x4A, 0xAD, 0x38, 0xFF, 0x76, 0xAD, 0xFD, 0x98, 0xD2, 0x4B, 0xAD, 0xFC, 0x11, 0x77, 0x71, 0x3D, 0xA7, 0x69, 0x12, 0xBA, 0xF5, 0x7C, 0x14, 0x0B, 0xD7, 0x54, 0x0E, 0xD5, 0xA7, 0xD3, 0x41, 0xC1, 0x7A, 0x8A, 0x82, 0x09, 0x53};

// ---- big-endian modular exponentiation (textbook RSA verify) ----
// lane size `len` bytes, len <= 256
static void bn_mul(uint8_t* out, const uint8_t* a, const uint8_t* b, int len) {
    uint32_t acc[512];
    memset(acc, 0, sizeof(acc));
    for (int i = 0; i < len; i++) {
        uint8_t ai = a[i];
        if (!ai) continue;
        int wi = len - 1 - i;
        uint32_t carry = 0;
        // iterate b from LSB (j = len-1) to MSB (j = 0) so the carry
        // propagates toward higher weights as we go
        for (int j = len - 1; j >= 0; j--) {
            int wj = len - 1 - j;
            uint32_t t = (uint32_t)ai * b[j] + acc[wi + wj] + carry;
            acc[wi + wj] = t & 0xFFu;
            carry = t >> 8;
        }
        int w = wi + len;
        while (carry && w < 2 * len) {
            uint32_t t = acc[w] + carry;
            acc[w] = t & 0xFFu;
            carry = t >> 8;
            w++;
        }
    }
    for (int k = 0; k < 2 * len; k++) out[k] = (uint8_t)acc[2 * len - 1 - k];
}

static int bn_cmp(const uint8_t* a, const uint8_t* b, int len) {
    for (int k = 0; k < len; k++) {
        if (a[k] != b[k]) return a[k] > b[k] ? 1 : -1;
    }
    return 0;
}

static void bn_mod(uint8_t* out, const uint8_t* x, int xlen, const uint8_t* n, int nlen) {
    uint8_t rem[256];
    memset(rem, 0, sizeof(rem));
    for (int i = 0; i < xlen; i++) {
        for (int bit = 7; bit >= 0; bit--) {
            unsigned carry = (x[i] >> bit) & 1u;
            for (int k = nlen - 1; k >= 0; k--) {
                unsigned nc = rem[k] >> 7;
                rem[k] = (uint8_t)((rem[k] << 1) | carry);
                carry = nc;
            }
            // `carry` is the bit shifted out of the top of rem — the value
            // is carry*2^(8*nlen) + rem, which is < 2n, so ONE subtraction
            // of n restores rem < n.
            if (carry || bn_cmp(rem, n, nlen) >= 0) {
                int borrow = 0;
                for (int k = nlen - 1; k >= 0; k--) {
                    int t = (int)rem[k] - (int)n[k] - borrow;
                    borrow = t < 0 ? 1 : 0;
                    rem[k] = (uint8_t)(t & 0xFF);
                }
            }
        }
    }
    memcpy(out, rem, nlen);
}

// out = base^expn mod n, all big-endian `len`-byte arrays (len <= 256)
static void modexp_bn(const uint8_t* base, const uint8_t* expn, const uint8_t* n, uint8_t* out, int len) {
    uint8_t result[256], b[256], prod[512];
    memset(result, 0, sizeof(result));
    result[len - 1] = 1;
    memcpy(b, base, len);
    for (int byte = 0; byte < len; byte++) {
        for (int bit = 7; bit >= 0; bit--) {
            bn_mul(prod, result, result, len);
            bn_mod(result, prod, 2 * len, n, len);
            if ((expn[byte] >> bit) & 1u) {
                bn_mul(prod, result, b, len);
                bn_mod(result, prod, 2 * len, n, len);
            }
        }
    }
    memcpy(out, result, len);
}

// 512-bit convenience wrapper
static void modexp_512(const uint8_t* base, const uint8_t* expn, const uint8_t* n, uint8_t* out) {
    modexp_bn(base, expn, n, out, 64);
}


void __attribute__((noinline)) stage_probe_1(void) { volatile int x = 0; (void)x; }
void __attribute__((noinline)) stage_probe_2(void) { volatile int x = 0; (void)x; }
void __attribute__((noinline)) stage_probe_3(void) { volatile int x = 0; (void)x; }

void stage_probe_1(void);
void stage_probe_2(void);
void stage_probe_3(void);

int validate_input(const char* input) {
    uint8_t blob[128];
    (void)blob;  /* variant bodies that decode inline leave it untouched */
    init_decoder();

    // Stage probe 1
    int valid=1;
    size_t len=strlen(input); if(len<329||len>349) valid=0;
    if(!(valid)) { printf("Invalid key\n"); fflush(stdout); return 1; }
    stage_probe_1();

    // Stage probe 2
    uint8_t raw[248];
    decode_blob(input,raw,248);
    uint32_t mag=*(uint32_t*)raw;
    if(!(mag==0x4C4E5335)) { printf("Invalid key\n"); fflush(stdout); return 1; }
    stage_probe_2();

    // Stage probe 3
    uint8_t md[20];uint8_t expect[128];uint8_t calc[128];
    sha1_hash(raw,120,md);
    memset(expect,0,128);memcpy(expect+108,md,20);
    modexp_bn(raw+120,RSA_E,RSA_N,calc,128);
    int rsa_ok=(bn_cmp(calc,expect,128)==0);
    if(!(rsa_ok)) { printf("Invalid key\n"); fflush(stdout); return 1; }
    stage_probe_3();

    // Success - generate flag from verified blob (computed at runtime)
    char flag[32];
    generate_flag(raw, 15, flag);
    printf("%s\n", flag);
    fflush(stdout);
    return 0;
}
